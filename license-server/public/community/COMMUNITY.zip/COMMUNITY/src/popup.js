// ═══════════════════════════════════════════
// Irishka Group Master by SBS — popup.js (CSP compliant)
// ═══════════════════════════════════════════

'use strict';

let groups = [];
let images = [];
let isRunning = false;
let cdInterval = null;
const TIMER_MIN_MINUTES = 5;
const TIMER_MAX_MINUTES = 900;

function formatTimerMinutesForDisplay(minutes) {
  const m = Math.max(0, Math.floor(Number(minutes) || 0));
  if (m <= 60) return m + '\u00a0' + t('abbr_minute_short');
  const h = Math.floor(m / 60);
  const rem = m % 60;
  if (rem) return tfmt('timer_label_hours_mins', { h, m: rem });
  return tfmt('timer_label_hours_only', { h });
}

function formatCountdownSecondsForDisplay(totalSec) {
  const sec = Math.max(0, Math.floor(Number(totalSec) || 0));
  const h = Math.floor(sec / 3600);
  const mi = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (h > 0) parts.push(h + '\u00a0' + t('abbr_hour_short'));
  if (mi > 0) parts.push(mi + '\u00a0' + t('abbr_minute_short'));
  if (s > 0 || parts.length === 0) parts.push(s + '\u00a0' + t('abbr_second_short'));
  return parts.join(' ');
}
let spPreviewOpen = false;
let checkTimer = null;

// ─── INIT ────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initLang();
  bindAll();
  loadGroups();
  initTimerSliders();
  updateTimerUI();
  checkFB();
  checkTimer = setInterval(checkFB, 6000);

  chrome.storage.local.get(['posterRunning', 'posterConfig', 'posterResults'], d => {
    if (d.posterRunning && d.posterConfig) {
      setRunning(true);
      initSteps(d.posterConfig.groups);
      if (d.posterResults?.length) updateProgress(d.posterResults, d.posterConfig.groups.length, 0);
    }
  });
});

// ─── BIND ALL EVENT LISTENERS ────────────────
function bindAll() {
  // Tabs
  document.querySelectorAll('.tab').forEach(t =>
    t.addEventListener('click', () => goTab(t.dataset.tab))
  );

  // Toolbar buttons
  document.getElementById('tb-bold').addEventListener('click', () => execCmd('bold'));
  document.getElementById('tb-italic').addEventListener('click', () => execCmd('italic'));
  document.getElementById('tb-underline').addEventListener('click', () => execCmd('underline'));
  document.getElementById('tb-ul').addEventListener('click', () => execCmd('insertUnorderedList'));
  document.getElementById('tb-ol').addEventListener('click', () => execCmd('insertOrderedList'));
  document.getElementById('tb-center').addEventListener('click', () => execCmd('justifyCenter'));
  document.getElementById('tb-link').addEventListener('click', insertLink);
  document.getElementById('tb-clear').addEventListener('click', () => execCmd('removeFormat'));

  // Emoji buttons — delegate via data-emoji
  document.querySelectorAll('.emoji-btn').forEach(btn => {
    btn.addEventListener('click', () => insertEmoji(btn.dataset.emoji));
  });

  // Spintax buttons
  document.getElementById('spInsert').addEventListener('click', spInsertTemplate);
  document.getElementById('spPreview').addEventListener('click', toggleSpPreview);
  document.getElementById('spRespin').addEventListener('click', refreshSpPreview);

  // Image upload area
  document.getElementById('imgUploadArea').addEventListener('click', () => {
    document.getElementById('imgInput').click();
  });
  document.getElementById('imgInput').addEventListener('change', handleImages);

  // Editor char count
  document.getElementById('editor').addEventListener('input', () => {
    updateCC();
    if (spPreviewOpen) refreshSpPreview();
  });

  // Groups tab — open FB
  document.getElementById('btnOpenFb').addEventListener('click', openFacebook);

  // Scan button
  document.getElementById('btnScan').addEventListener('click', scanGroups);

  // Groups controls
  document.getElementById('btnSelectAll').addEventListener('click', selectAll);
  document.getElementById('btnDeselectAll').addEventListener('click', deselectAll);
  document.getElementById('btnClearAll').addEventListener('click', clearAll);
  document.getElementById('btnAddGroup').addEventListener('click', addGroup);
  document.getElementById('groupUrl').addEventListener('keydown', e => { if (e.key === 'Enter') addGroup(); });

  // Timer
  document.getElementById('timerSec').addEventListener('input', updateTimerUI);
  document.getElementById('timerVar').addEventListener('input', updateTimerUI);

  // Footer
  document.getElementById('btnReset').addEventListener('click', resetAll);
  document.getElementById('btnStart').addEventListener('click', startPosting);
  document.getElementById('btnStop').addEventListener('click', stopPosting);
}

// ─── TABS ─────────────────────────────────────
function goTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-' + name));
}

// ─── FB CONNECTION CHECK ──────────────────────
async function checkFB() {
  setPill('checking', t('verifying'));

  const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);

  if (!tabs.length) {
    setPill('offline', t('no_connection'));
    showConnected(false);
    return;
  }

  const tab = await pickBestFacebookTab(tabs);

  let loginInfo = null;
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: detectFBLogin
    });
    loginInfo = res?.[0]?.result;
  } catch (err) {
    setPill('offline', t('popup_verify_failed'));
    showConnected(false);
    return;
  }

  if (loginInfo && loginInfo.loggedIn) {
    const name = loginInfo.name || t('facebook_user_fallback');
    setPill('online', name);
    document.getElementById('fbUserName').textContent = name;
    const host = tab.url.split('/')[2] || '';
    document.getElementById('fbUserSub').textContent = host ? host : '—';
    showConnected(true);
  } else {
    setPill('offline', loginInfo?.reason || t('not_logged_in'));
    showConnected(false);
  }
}

// Runs INSIDE the Facebook page — must be self-contained, no closures
function detectFBLogin() {
  try {
    // If login form exists → not logged in
    if (document.querySelector('#email, input[name="email"], [data-testid="royal_email"]')) {
      return { loggedIn: false, reason: 'Formulario de login visible' };
    }
    if (window.location.pathname.startsWith('/login')) {
      return { loggedIn: false, reason: 'Página de login' };
    }

    var UI_LABEL_DENY = {
      'editar perfil': 1, 'edit profile': 1, 'editar tu perfil': 1, 'modifier le profil': 1,
      'modifier votre profil': 1, 'profil bearbeiten': 1, 'modifica profilo': 1,
      'редактировать профиль': 1, 'profiel bewerken': 1, 'edytuj profil': 1, 'profili düzenle': 1,
      'ver perfil': 1, 'view profile': 1, 'voir le profil': 1, 'mi perfil': 1, 'your profile': 1,
      'tu perfil': 1, 'mon profil': 1, 'verified': 1, 'verificado': 1, 'verificada': 1,
      'account': 1, 'cuenta': 1
    };
    function cleanText(t) {
      if (!t) return false;
      var s = t.trim();
      if (s.length < 2 || s.length >= 60) return false;
      var low = s.toLowerCase();
      if (UI_LABEL_DENY[low]) return false;
      if (s.indexOf('Facebook') !== -1 || /^\d/.test(s) || s.indexOf('·') !== -1) return false;
      low = s.toLowerCase();
      if (low.indexOf('search') !== -1 || low.indexOf('buscar') !== -1) return false;
      return true;
    }
    function nameFromProfileLinks() {
      var selList = ['a[href*="/me"]', 'a[href*="profile.php"]', 'a[href^="/profile/"]', 'a[href*="/profile/"]'];
      for (var li = 0; li < selList.length; li++) {
        var anchors = document.querySelectorAll(selList[li]);
        for (var ai = 0; ai < anchors.length; ai++) {
          var spans = anchors[ai].querySelectorAll('span');
          for (var si = 0; si < spans.length; si++) {
            var raw = spans[si].textContent && spans[si].textContent.trim();
            if (raw && cleanText(raw)) return raw;
          }
          var imgAlt = anchors[ai].querySelector('img[alt]');
          if (imgAlt) {
            var altT = imgAlt.getAttribute('alt') && imgAlt.getAttribute('alt').trim();
            if (altT && cleanText(altT)) return altT;
          }
        }
      }
      return null;
    }
    var fromMe = nameFromProfileLinks();
    if (fromMe) return { loggedIn: true, name: fromMe };
    var blueBar = document.querySelector('[data-testid="blue_bar_profile_link"]');
    if (blueBar) {
      var bs = blueBar.querySelectorAll('span');
      for (var bi = 0; bi < bs.length; bi++) {
        var br = bs[bi].textContent && bs[bi].textContent.trim();
        if (br && cleanText(br)) return { loggedIn: true, name: br };
      }
    }

    const profileSels = [
      'a[aria-label*="perfil"] span', 'a[aria-label*="profile"] span', 'a[aria-label*="cuenta"] span'
    ];
    for (const sel of profileSels) {
      const el = document.querySelector(sel);
      if (el && cleanText(el.textContent)) return { loggedIn: true, name: el.textContent.trim() };
    }

    // Method 2: scan banner / nav for a name-like span
    const nav = document.querySelector('[role="banner"], [data-pagelet="NavBar"], header');
    if (nav) {
      const spans = nav.querySelectorAll('span');
      for (const s of spans) {
        const t = s.textContent?.trim();
        if (cleanText(t) && t.split(' ').length >= 1 && t.split(' ').length <= 5) {
          return { loggedIn: true, name: t };
        }
      }
    }

    // Method 3: page has main content → user is logged in (can't read name)
    const hasMain = document.querySelector(
      '[role="main"], [data-pagelet="GroupFeed"], [data-pagelet="ProfileTimeline"], [data-pagelet="Feed"]'
    );
    if (hasMain) return { loggedIn: true, name: null };

    // Method 4: cookies contain c_user (Facebook user ID cookie)
    if (document.cookie.includes('c_user=')) return { loggedIn: true, name: null };

    return { loggedIn: false, reason: 'Sin sesión detectada' };
  } catch (e) {
    return { loggedIn: false, reason: e.message };
  }
}

// Runs INSIDE the Facebook page — extracts group links
function extractGroupLinks() {
  const results = [];
  const seen = new Set();
  const EXCLUDED = new Set([
    'feed','discover','create','search','joins','highlights',
    'videos','photos','members','events','files','store',
    'about','rooms','bookmark','notifications','invite'
  ]);

  document.querySelectorAll('a[href*="/groups/"]').forEach(link => {
    const href = link.href || '';
    const m = href.match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
    if (!m) return;
    const id = m[1];
    if (EXCLUDED.has(id.toLowerCase()) || /^\d{0,3}$/.test(id) || seen.has(id)) return;
    seen.add(id);

    let name = '';
    link.querySelectorAll('span').forEach(s => {
      const t = s.textContent?.trim();
      if (!name && t && t.length > 2 && t.length < 80 && !t.match(/^\d+[KkMm]?$/) && !t.includes('·')) name = t;
    });
    if (!name) name = link.getAttribute('aria-label') || link.textContent?.trim() || '';
    if (!name || name.length < 2) name = id.replace(/[-_]/g, ' ');

    results.push({ url: 'https://www.facebook.com/groups/' + id, name: name.substring(0, 80).trim() });
  });

  return results;
}

function scrollScanPageForMoreGroups() {
  try {
    const anchors = document.querySelectorAll('a[href*="/groups/"]');
    for (let i = anchors.length - 1; i >= 0; i--) {
      const href = anchors[i].href || '';
      const m = href.match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
      if (!m) continue;
      const id = m[1].toLowerCase();
      if (['joins', 'feed', 'discover', 'create', 'search'].includes(id)) continue;
      anchors[i].scrollIntoView({ block: 'end', behavior: 'auto' });
      break;
    }
    document.querySelectorAll('[role="main"]').forEach((main) => {
      const sh = main.scrollHeight;
      const ch = main.clientHeight;
      if (sh > ch + 40) {
        main.scrollTop = Math.min(main.scrollTop + Math.floor(ch * 0.88), sh);
      }
    });
    const step = Math.max(300, Math.floor(window.innerHeight * 0.88));
    window.scrollBy(0, step);
    const docH = Math.max(
      document.body ? document.body.scrollHeight : 0,
      document.documentElement ? document.documentElement.scrollHeight : 0
    );
    window.scrollTo(0, docH);
  } catch (e) {}
}

async function focusScanFacebookTab(tab) {
  if (!tab?.id) return;
  try {
    await chrome.tabs.update(tab.id, { active: true });
  } catch (e) {}
  try {
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } catch (e) {}
}

async function restoreTabFocus(tabId) {
  if (tabId == null) return;
  try {
    const t = await chrome.tabs.get(tabId);
    await chrome.windows.update(t.windowId, { focused: true });
    await chrome.tabs.update(tabId, { active: true });
  } catch (e) {}
}

function groupUrlKey(url) {
  const m = String(url || '').match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
  return m ? String(m[1]).toLowerCase() : '';
}

function mergeGroupsFromFacebookScan(found) {
  const before = groups.length;
  const oldByKey = new Map();
  groups.forEach(g => {
    const k = groupUrlKey(g.url);
    if (k) oldByKey.set(k, g);
  });
  const merged = [];
  let added = 0;
  for (const g of found) {
    const k = groupUrlKey(g.url);
    if (!k) continue;
    const old = oldByKey.get(k);
    if (old) {
      merged.push({ ...old, name: g.name });
    } else {
      merged.push({
        url: g.url,
        name: g.name,
        selected: true,
        canPost: null,
        postabilityCheckedAt: null,
        postStatus: null,
        postError: '',
        pendingPostsCount: 0,
        moderationStats: { pending: 0, approved: 0, rejected: 0, deleted: 0 }
      });
      added++;
    }
  }
  const removed = Math.max(0, before + added - merged.length);
  groups = merged;
  return { added, removed };
}

// ─── OPEN FACEBOOK ────────────────────────────
function openFacebook() {
  chrome.tabs.create({ url: 'https://www.facebook.com/', active: true }, () => {
    setPill('checking', t('opening_fb'));
    setTimeout(checkFB, 4000);
  });
}

// ─── SCAN GROUPS ─────────────────────────────
const SCAN_GROUPS_MAX_MS = 90000;
const SCAN_TAB_LOAD_MAX_MS = 12000;
const SCAN_OVERLAY_COUNTDOWN_MS = 20000;

function createTabAndWait(url, active, maxWaitMs = 15000) {
  return new Promise(resolve => {
    chrome.tabs.create({ url, active: !!active }, (tab) => {
      const tabId = tab.id;
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        chrome.tabs.onUpdated.removeListener(onUpd);
        resolve(tab);
      };
      const onUpd = (id, info) => {
        if (id === tabId && info.status === 'complete') finish();
      };
      chrome.tabs.onUpdated.addListener(onUpd);
      setTimeout(finish, maxWaitMs);
    });
  });
}

async function scanGroups() {
  const btn = document.getElementById('btnScan');
  const icon = document.getElementById('scanIcon');
  const txt = document.getElementById('scanTxt');
  const logEl = document.getElementById('scanLog');
  let scanTab = null;
  let returnToTabId = null;

  btn.disabled = true;
  icon.textContent = '⏳';
  txt.textContent = t('scanning');
  setLog(logEl, 'inf', t('searching_fb_tab'));

  try {
    const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);
    if (!tabs.length) {
      setLog(logEl, 'err', t('open_fb_first'));
      resetScanBtn(btn, icon, txt);
      return;
    }

    const fbTab = await pickBestFacebookTab(tabs);
    setLog(logEl, 'inf', t('opening_groups_page'));

    const scanDeadline = Date.now() + SCAN_GROUPS_MAX_MS;

    const prevActive = await chrome.tabs.query({ active: true, currentWindow: true });
    returnToTabId = prevActive[0]?.id ?? null;

    const isWeb = (fbTab.url || '').includes('web.facebook.com');
    const targetUrl = isWeb
      ? 'https://web.facebook.com/groups/joins/?nav_source=tab'
      : 'https://www.facebook.com/groups/joins/?nav_source=tab';
    scanTab = await createTabAndWait(targetUrl, true, SCAN_TAB_LOAD_MAX_MS);
    await focusScanFacebookTab(scanTab);

    if (Date.now() >= scanDeadline) {
      try { chrome.tabs.remove(scanTab.id); } catch (e) {}
      await restoreTabFocus(returnToTabId);
      setLog(logEl, 'err', tfmt('scan_time_exceeded', { sec: Math.round(SCAN_GROUPS_MAX_MS / 1000) }));
      resetScanBtn(btn, icon, txt);
      return;
    }

    await sleep(Math.min(1500, Math.max(0, scanDeadline - Date.now())));
    if (Date.now() >= scanDeadline) {
      try { chrome.tabs.remove(scanTab.id); } catch (e) {}
      await restoreTabFocus(returnToTabId);
      setLog(logEl, 'err', tfmt('scan_time_exceeded', { sec: Math.round(SCAN_GROUPS_MAX_MS / 1000) }));
      resetScanBtn(btn, icon, txt);
      return;
    }

    setLog(logEl, 'inf', t('reading_all_groups'));
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      files: ['src/scan-overlay-inject.js']
    });
    const overlayCountdownEnd = Date.now() + SCAN_OVERLAY_COUNTDOWN_MS;
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      args: [t('scan_overlay_please_wait'), t('scan_overlay_detected_label'), t('scan_overlay_time_label'), overlayCountdownEnd],
      func: (pleaseWait, detLab, timeLab, deadlineMs) => {
        window.fartmilyScanOverlayInit?.(pleaseWait, detLab, timeLab, deadlineMs);
      }
    });

    await focusScanFacebookTab(scanTab);

    const foundMap = new Map();
    let noGrowth = 0;
    for (let i = 0; i < 200; i++) {
      await focusScanFacebookTab(scanTab);
      const res = await chrome.scripting.executeScript({ target: { tabId: scanTab.id }, func: extractGroupLinks });
      const pageFound = res?.[0]?.result || [];
      const prevCount = foundMap.size;
      pageFound.forEach(g => foundMap.set(g.url, g));
      const growth = foundMap.size - prevCount;
      setLog(logEl, 'inf', foundMap.size + ' ' + t('groups_detected'));
      await chrome.scripting.executeScript({
        target: { tabId: scanTab.id },
        args: [foundMap.size, t('scan_overlay_detected_label')],
        func: (count, detLab) => {
          window.fartmilyScanOverlayUpdateDetected?.(count, detLab);
        }
      });
      if (Date.now() >= scanDeadline) break;
      if (growth === 0) noGrowth++;
      else noGrowth = 0;
      if (noGrowth >= 14) break;
      await chrome.scripting.executeScript({
        target: { tabId: scanTab.id },
        func: scrollScanPageForMoreGroups
      });
      const baseWait = growth > 0 ? 750 : 1900;
      const sleepMs = Math.min(baseWait, Math.max(0, scanDeadline - Date.now()));
      if (sleepMs < 80) break;
      await sleep(sleepMs);
    }

    const found = Array.from(foundMap.values());
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      func: () => {
        window.fartmilyScanOverlayRemove?.();
        const old = document.getElementById('igs-scan-timer');
        if (old) old.remove();
      }
    });
    try { chrome.tabs.remove(scanTab.id); } catch (e) {}
    scanTab = null;
    await restoreTabFocus(returnToTabId);

    if (!found.length) {
      setLog(logEl, 'err', t('no_results_scan'));
    } else {
      const { added, removed } = mergeGroupsFromFacebookScan(found);
      saveGroups();
      renderGroups();
      setLog(logEl, 'ok', tfmt('log_scan_sync_ok', { total: found.length, added, removed }));
    }
  } catch (e) {
    setLog(logEl, 'err', t('error_label') + ': ' + (e.message || t('unknown')));
    try {
      if (scanTab?.id) {
        await chrome.scripting.executeScript({
          target: { tabId: scanTab.id },
          func: () => {
            window.fartmilyScanOverlayRemove?.();
            const old = document.getElementById('igs-scan-timer');
            if (old) old.remove();
          }
        });
      }
    } catch (_) {}
    try {
      if (scanTab?.id) chrome.tabs.remove(scanTab.id);
    } catch (_) {}
    scanTab = null;
    await restoreTabFocus(returnToTabId);
  }

  resetScanBtn(btn, icon, txt);
}

function resetScanBtn(btn, icon, txt) {
  btn.disabled = false;
  icon.textContent = '🔍';
  txt.textContent = t('btn_scan');
}

function setLog(el, cls, msg) { el.className = 'scan-log ' + cls; el.textContent = msg; }

// ─── GROUPS CRUD ──────────────────────────────
function loadGroups() {
  chrome.storage.local.get('fbGroups', d => { groups = d.fbGroups || []; renderGroups(); });
}
function saveGroups() { chrome.storage.local.set({ fbGroups: groups }); }

function addGroup() {
  const inp = document.getElementById('groupUrl');
  let url = inp.value.trim();
  if (!url) return;
  if (!url.startsWith('http')) url = 'https://' + url;
  if (!url.includes('facebook.com/groups/')) {
    alert(t('alert_group_url_invalid')); return;
  }
  const m = url.match(/groups\/([^/?#\s]+)/);
  if (!m) { alert(t('alert_group_id_failed')); return; }
  const cleanUrl = 'https://www.facebook.com/groups/' + m[1];
  if (groups.find(g => g.url === cleanUrl)) { alert(t('alert_group_duplicate')); return; }
  groups.push({ url: cleanUrl, name: m[1].replace(/[-_]/g, ' '), selected: true });
  saveGroups(); renderGroups(); inp.value = '';
}

function removeGroup(i) { groups.splice(i, 1); saveGroups(); renderGroups(); }
function toggleGroup(i) { groups[i].selected = !groups[i].selected; saveGroups(); }
function selectAll() { groups.forEach(g => g.selected = true); saveGroups(); renderGroups(); }
function deselectAll() { groups.forEach(g => g.selected = false); saveGroups(); renderGroups(); }
function clearAll() {
  if (!groups.length || !confirm(t('confirm_delete_all_groups'))) return;
  groups = []; saveGroups(); renderGroups();
}

function renderGroups() {
  const list = document.getElementById('groupsList');
  document.getElementById('groupCount').textContent = groups.length;
  if (!groups.length) {
    list.innerHTML = '<div class="empty-note">' + t('groups_empty') + '</div>';
    return;
  }
  list.innerHTML = '';
  groups.forEach((g, i) => {
    // Build DOM safely — no inline handlers
    const item = document.createElement('div');
    item.className = 'group-item';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = g.selected;
    cb.addEventListener('change', () => toggleGroup(i));

    const info = document.createElement('div');
    info.className = 'group-info';

    const nameEl = document.createElement('div');
    nameEl.className = 'group-name';
    nameEl.textContent = g.name;

    const urlEl = document.createElement('div');
    urlEl.className = 'group-url-txt';
    urlEl.textContent = g.url;

    info.appendChild(nameEl);
    info.appendChild(urlEl);

    const delBtn = document.createElement('button');
    delBtn.className = 'icon-btn';
    delBtn.title = t('group_btn_remove_title');
    delBtn.textContent = '✕';
    delBtn.addEventListener('click', () => removeGroup(i));

    item.appendChild(cb);
    item.appendChild(info);
    item.appendChild(delBtn);
    list.appendChild(item);
  });
}

// ─── EDITOR ───────────────────────────────────
function execCmd(cmd, v = null) {
  document.getElementById('editor').focus();
  document.execCommand(cmd, false, v);
  updateCC();
}
function insertLink() {
  const u = prompt(t('prompt_link_url'));
  if (u) execCmd('createLink', u);
}
function insertEmoji(e) {
  document.getElementById('editor').focus();
  document.execCommand('insertText', false, e);
  updateCC();
}
function updateCC() {
  const n = (document.getElementById('editor').innerText || '').length;
  const el = document.getElementById('charCount');
  el.textContent = tfmt('char_count_label', { n });
  el.className = 'char-count' + (n > 60000 ? ' over' : n > 50000 ? ' warn' : '');
}

// ─── IMAGES ───────────────────────────────────
function handleImages(ev) {
  Array.from(ev.target.files).slice(0, 5 - images.length).forEach(f => {
    const r = new FileReader();
    r.onload = e => { images.push({ dataUrl: e.target.result, name: f.name, type: f.type }); renderImgs(); };
    r.readAsDataURL(f);
  });
  ev.target.value = '';
}
function removeImage(i) { images.splice(i, 1); renderImgs(); }
function renderImgs() {
  const p = document.getElementById('imgPreview');
  p.innerHTML = '';
  images.forEach((img, i) => {
    const wrap = document.createElement('div');
    wrap.className = 'img-thumb';

    const im = document.createElement('img');
    im.src = img.dataUrl;
    im.alt = img.name;

    const rm = document.createElement('button');
    rm.className = 'remove-img';
    rm.textContent = '✕';
    rm.addEventListener('click', () => removeImage(i));

    wrap.appendChild(im);
    wrap.appendChild(rm);
    p.appendChild(wrap);
  });
}

// ─── TIMER UI ─────────────────────────────────
function initTimerSliders() {
  const slider = document.getElementById('timerSec');
  const varSlider = document.getElementById('timerVar');
  if (slider) {
    slider.min = String(TIMER_MIN_MINUTES);
    slider.max = String(TIMER_MAX_MINUTES);
    let v = +slider.value;
    if (!Number.isFinite(v)) v = TIMER_MIN_MINUTES;
    if (v < TIMER_MIN_MINUTES) slider.value = String(TIMER_MIN_MINUTES);
    else if (v > TIMER_MAX_MINUTES) slider.value = String(TIMER_MAX_MINUTES);
  }
  if (varSlider) {
    varSlider.min = '0';
    varSlider.max = '30';
  }
}

function updateTimerUI() {
  const val = +document.getElementById('timerSec').value;
  const v = +document.getElementById('timerVar').value;

  document.getElementById('timerSecVal').textContent = formatTimerMinutesForDisplay(val);
  document.getElementById('timerVarVal').textContent = '±' + formatTimerMinutesForDisplay(v);

  const minVal = Math.max(0, val - v);
  const maxVal = val + v;
  document.getElementById('tMin').textContent = formatTimerMinutesForDisplay(minVal);
  document.getElementById('tMax').textContent = formatTimerMinutesForDisplay(maxVal);

  document.getElementById('tMinLbl').textContent = t('lbl_min');
  document.getElementById('tMaxLbl').textContent = t('lbl_max');
}

// ─── START / STOP ─────────────────────────────
async function startPosting() {
  const text = document.getElementById('editor').innerText.trim();
  if (!text) { alert(t('alert_message_required')); return; }
  const sel = groups.filter(g => g.selected);
  if (!sel.length) { alert(t('alert_select_one_group')); return; }

  const config = {
    // Apply spintax — each group gets a unique spin
    _rawText: document.getElementById('editor').innerText,
    _rawHtml: document.getElementById('editor').innerHTML,
    html: document.getElementById('editor').innerHTML,
    text,           // will be re-spun per group in background
    useSpintax: countSpinGroups(document.getElementById('editor').innerText) > 0,
    images,
    groups: sel,
    timerEnabled: true,
    timerSeconds: (() => {
      const raw = +document.getElementById('timerSec').value;
      const min = Math.min(TIMER_MAX_MINUTES, Math.max(TIMER_MIN_MINUTES, Number.isFinite(raw) ? raw : TIMER_MIN_MINUTES));
      return min * 60;
    })(),
    timerVariation: (+document.getElementById('timerVar').value || 0) * 60,
    notifyEnd: document.getElementById('notifyEnd').checked,
    pauseOnFailedPublication: true
  };

  const sessionWrite = await new Promise((resolve) => {
    writePosterImagesSessionThenSlim(config, resolve);
  });
  if (!sessionWrite.ok) {
    try {
      console.warn('[Irishka] Capas de imagen no persistidas del todo; se inicia igual.', sessionWrite.error || '');
    } catch (e) {}
    if (!sessionWrite.slim) {
      if (sessionWrite.error === 'session_storage_unavailable') {
        alert(t('alert_session_storage_missing'));
      } else {
        alert(t('alert_storage_session_images_failed') + '\n' + (sessionWrite.error || ''));
      }
      return;
    }
  }
  const slimPoster = sessionWrite.slim;

  let posterStorageOk = false;
  await new Promise((resolve) => {
    chrome.storage.local.set({
      fbGroups: groups,
      posterConfig: slimPoster,
      posterRunning: true,
      posterResults: []
    }, () => {
      if (chrome.runtime.lastError) {
        alert(t('alert_storage_post_failed') + '\n' + chrome.runtime.lastError.message);
        resolve();
        return;
      }
      posterStorageOk = true;
      resolve();
    });
  });
  if (!posterStorageOk) return;
  setRunning(true);
  goTab('progress');
  initSteps(sel);
  const groupsSnapshot = sel.map((g) => ({
    url: g.url,
    name: g.name,
    selected: true,
    canPost: typeof g.canPost === 'boolean' ? g.canPost : null,
    postStatus: g.postStatus || null,
    postError: g.postError || '',
    postabilityCheckedAt: g.postabilityCheckedAt || null,
    pendingPostsCount: g.pendingPostsCount || 0
  }));
  chrome.runtime.sendMessage({ action: 'startPosting', groupsSnapshot });
}

function stopPosting() {
  chrome.runtime.sendMessage({ action: 'stopPosting' });
}

function setRunning(on) {
  isRunning = on;
  document.getElementById('btnStart').style.display = on ? 'none' : 'flex';
  document.getElementById('btnStop').style.display = on ? 'flex' : 'none';
  const bar = document.getElementById('runBar');
  if (bar) bar.className = 'run-bar' + (on ? ' show' : '');
  if (!on) {
    const cd = document.getElementById('cdBox');
    if (cd) cd.style.display = 'none';
    if (cdInterval) { clearInterval(cdInterval); cdInterval = null; }
  }
}

function resetAll() {
  if (isRunning && !confirm(t('confirm_stop_process'))) return;
  stopPosting();
  document.getElementById('editor').innerHTML = '';
  images = []; renderImgs(); updateCC(); initSteps([]);
}

// ─── PROGRESS ─────────────────────────────────
function initSteps(grps) {
  const el = document.getElementById('progSteps');
  document.getElementById('progLabel').textContent = grps.length ? t('in_progress') : t('prog_not_started');
  document.getElementById('progFrac').textContent = `0/${grps.length}`;
  document.getElementById('progBar').style.width = '0%';
  if (!grps.length) {
    el.innerHTML = '<div class="empty-note">' + t('prog_empty') + '</div>';
    return;
  }
  el.innerHTML = '';
  grps.forEach((g, i) => {
    const d = document.createElement('div');
    d.className = 'step-item pending';
    d.id = 'step-' + i;
    const icon = document.createElement('span'); icon.textContent = '⏳';
    const name = document.createElement('span'); name.textContent = g.name;
    d.appendChild(icon); d.appendChild(name);
    el.appendChild(d);
  });
}

function updateProgress(results, total, countdown) {
  const done = results.length;
  const pct = total ? Math.round(done / total * 100) : 0;
  document.getElementById('progFrac').textContent = `${done}/${total}`;
  document.getElementById('progBar').style.width = pct + '%';
  const cd = Math.max(0, Number(countdown || 0));
  if (cd > 0 && done < total) {
    document.getElementById('progLabel').textContent = tfmt('wait_next_post', { time: formatCountdownSecondsForDisplay(cd) });
  } else {
    document.getElementById('progLabel').textContent = (done === total && total) ? t('all_published') : (t('publishing') + ' ' + pct + '%');
  }
  const rb = document.getElementById('runBarText');
  if (rb) {
    if (cd > 0 && done < total) rb.textContent = tfmt('wait_next_post', { time: formatCountdownSecondsForDisplay(cd) });
    else rb.textContent = tfmt('posting_group_of', { current: Math.min(done + 1, total), total });
  }

  results.forEach((r, i) => {
    const el = document.getElementById('step-' + i);
    if (!el) return;
    el.className = 'step-item ' + (r.success ? 'done' : 'error');
    el.innerHTML = '';
    const icon = document.createElement('span'); icon.textContent = r.success ? t('progress_row_ok') : t('progress_row_err');
    const txt = document.createElement('span'); txt.textContent = r.name + ' — ' + (r.success ? t('progress_published') : (r.error || t('error_label')));
    el.appendChild(icon); el.appendChild(txt);
  });

  if (done < total) {
    const cur = document.getElementById('step-' + done);
    if (cur) {
      const prevName = cur.querySelector('span:last-child')?.textContent || '';
      const baseName = (prevName.split(' — ')[0] || prevName).trim();
      cur.className = 'step-item current';
      cur.innerHTML = '';
      const i2 = document.createElement('span'); i2.textContent = '⏳';
      const t2 = document.createElement('span'); t2.textContent = baseName + ' — ' + t('publishing');
      cur.appendChild(i2); cur.appendChild(t2);
    }
  }

  const cdBox = document.getElementById('cdBox');
  if (countdown > 0 && done < total) {
    cdBox.style.display = 'block';
    startCD(countdown);
  } else {
    cdBox.style.display = 'none';
  }
}

function startCD(sec) {
  if (cdInterval) clearInterval(cdInterval);
  let r = sec;
  document.getElementById('cdNum').textContent = formatCountdownSecondsForDisplay(r);
  cdInterval = setInterval(() => {
    r--;
    document.getElementById('cdNum').textContent = formatCountdownSecondsForDisplay(r);
    if (r <= 0) {
      clearInterval(cdInterval); cdInterval = null;
      document.getElementById('cdBox').style.display = 'none';
    }
  }, 1000);
}

// ─── MESSAGES FROM BACKGROUND ─────────────────
chrome.runtime.onMessage.addListener(msg => {
  if (msg.action === 'progressUpdate') updateProgress(msg.results, msg.total, msg.countdown || 0);
  if (msg.action === 'postingFinished') {
    setRunning(false);
    updateProgress(msg.results, msg.total, 0);
    document.getElementById('progLabel').textContent = t('all_published');
  }
  if (msg.action === 'postingStopped') {
    const wasRunning = isRunning;
    setRunning(false);
    const rawReason = msg.stopReason;
    const reason = (rawReason != null && rawReason !== '')
      ? rawReason
      : (wasRunning ? 'session_interrupted' : 'unknown');
    if (reason === 'bad_config') alert(t('log_stop_bad_config'));
    else if (reason === 'no_groups') alert(t('log_stop_no_groups'));
    if (reason === 'post_failure_pause') {
      const pd = msg.pauseDetail || { groupName: '', groupUrl: '', error: '' };
      const pl = document.getElementById('progLabel');
      if (pl) pl.textContent = t('failure_pause_title');
      const detail = tfmt('failure_pause_detail', {
        group: pd.groupName || '—',
        error: pd.error || '—'
      });
      const ok = confirm(detail + '\n\n' + t('failure_pause_continue') + ' = OK, ' + t('failure_pause_stop') + ' = Cancel');
      if (ok) {
        chrome.runtime.sendMessage({ action: 'resumePostingAfterPause' }, (r) => {
          if (chrome.runtime.lastError || !r || !r.ok) {
            alert(t('failure_resume_failed'));
            return;
          }
          setRunning(true);
        });
      } else {
        stopPosting();
      }
    } else {
      let idleMsg = t('prog_not_started');
      if (reason === 'user_stop') idleMsg = t('prog_stopped_by_user');
      else if (reason === 'session_interrupted') idleMsg = t('prog_session_interrupted');
      else if (reason === 'daily_limit') idleMsg = t('prog_stopped_daily_limit');
      else if (reason === 'unknown') idleMsg = t('prog_not_started');
      const pl = document.getElementById('progLabel');
      if (pl) pl.textContent = idleMsg;
      const rb = document.getElementById('runBarText');
      if (rb) rb.textContent = idleMsg;
    }
  }
});


// ─── SPINTAX ENGINE ───────────────────────────

function spinText(text) {
  let result = text;
  let maxPasses = 20;
  while (maxPasses-- > 0) {
    const prev = result;
    result = result.replace(/\{([^{}]+)\}/g, (match, inner) => {
      const options = inner.split('|');
      return options[Math.floor(Math.random() * options.length)];
    });
    if (result === prev) break;
  }
  return result;
}

function countSpinGroups(text) {
  const matches = text.match(/\{[^{}]*\|[^{}]*\}/g);
  return matches ? matches.length : 0;
}

function spInsertTemplate() {
  const editor = document.getElementById('editor');
  editor.focus();
  document.execCommand('insertText', false, t('spintax_template_example'));
  updateCC();
  if (spPreviewOpen) refreshSpPreview();
}

function syncSpPreviewForLang() {
  const btn = document.getElementById('spPreview');
  if (!btn) return;
  btn.textContent = spPreviewOpen ? t('spintax_close_view') : t('spintax_preview_btn_alt');
  if (spPreviewOpen) refreshSpPreview();
}

function toggleSpPreview() {
  spPreviewOpen = !spPreviewOpen;
  const wrap = document.getElementById('spintaxPreviewWrap');
  const hint = document.getElementById('spHint');
  const btn = document.getElementById('spPreview');
  wrap.style.display = spPreviewOpen ? 'block' : 'none';
  hint.style.display = spPreviewOpen ? 'none' : 'block';
  btn.classList.toggle('sp-highlight', spPreviewOpen);
  btn.textContent = spPreviewOpen ? t('spintax_close_view') : t('spintax_preview_btn_alt');
  if (spPreviewOpen) refreshSpPreview();
}

function refreshSpPreview() {
  const raw = document.getElementById('editor').innerText || '';
  const body = document.getElementById('spintaxPreviewBody');
  const label = document.getElementById('spVariantLabel');
  if (!raw.trim()) {
    body.innerHTML = '';
    const span = document.createElement('span');
    span.style.color = 'var(--muted)';
    span.textContent = t('editor_empty');
    body.appendChild(span);
    label.textContent = '';
    return;
  }
  const spinCount = countSpinGroups(raw);
  label.textContent = spinCount > 0 ? tfmt('spintax_variations', { n: spinCount }) : t('spintax_none');
  if (spinCount === 0) {
    body.textContent = raw;
    return;
  }
  // Apply spin with highlights
  let preview = escHtml(raw);
  let passes = 20;
  while (passes-- > 0) {
    const prev = preview;
    preview = preview.replace(/\{([^{}]+)\}/g, (match, inner) => {
      const options = inner.split('|');
      const chosen = options[Math.floor(Math.random() * options.length)];
      return '<span class="sp-chosen">' + chosen + '</span>';
    });
    if (preview === prev) break;
  }
  body.innerHTML = preview;
}

// ─── HELPERS ──────────────────────────────────
function qTabs(patterns) { return new Promise(r => chrome.tabs.query({ url: patterns }, r)); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function showConnected(on) {
  document.getElementById('stateOff').style.display = on ? 'none' : 'block';
  document.getElementById('stateOn').style.display = on ? 'block' : 'none';
}
function setPill(cls, name) {
  document.getElementById('connPill').className = 'conn-pill ' + cls;
  document.getElementById('connName').textContent = name;
}
