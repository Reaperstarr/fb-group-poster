// ============================================================
// Irishka Fleet Hub client (Community — service worker helper)
// ============================================================
(function () {
  'use strict';

  const FLEET_ALARM = 'irishka_fleet_sync';
  const FLEET_FAST_ALARM = 'irishka_fleet_fast';
  const FLEET_FAST_MS = 5000;
  const DEFAULT_BASE = 'https://fb-group-poster-production.up.railway.app';
  const INSTALL_KEY = 'installDeviceId';

  let _config = {
    enabled: false,
    secret: '',
    baseUrl: DEFAULT_BASE,
    instanceName: 'Irishka',
  };
  let _lastCommandResult = null;
  let _commandHandler = null;
  let _storage = null;

  async function processOneCommand(cmd) {
    if (!cmd?.command || !_commandHandler) return;
    const result = await _commandHandler(cmd);
    _lastCommandResult = {
      id: cmd.id,
      command: cmd.command,
      ok: !!result?.ok,
      message: String(result?.message || '').slice(0, 180),
      at: new Date().toISOString(),
    };
  }

  function alarmName() {
    return FLEET_ALARM;
  }

  function fastAlarmName() {
    return FLEET_FAST_ALARM;
  }

  async function scheduleFastPoll(alarms) {
    if (!isEnabled()) {
      await alarms.clear(FLEET_FAST_ALARM);
      return;
    }
    await alarms.clear(FLEET_FAST_ALARM);
    alarms.create(FLEET_FAST_ALARM, { when: Date.now() + FLEET_FAST_MS });
  }

  function isEnabled() {
    return !!_config.enabled && !!_config.secret && !!_config.baseUrl;
  }

  async function init(storage) {
    _storage = storage;
    const d = await storage.get(['settings', INSTALL_KEY]);
    const s = d.settings || {};
    _config = {
      enabled: !!s.fleetHubEnabled,
      secret: String(s.fleetHubSecret || '').trim(),
      baseUrl: String(s.fleetHubBaseUrl || DEFAULT_BASE).trim().replace(/\/$/, '') || DEFAULT_BASE,
      instanceName: String(s.tgInstanceName || s.fleetInstanceName || '').trim() || 'Irishka',
      deviceId: String(d[INSTALL_KEY] || '').trim(),
    };
  }

  function onCommand(handler) {
    _commandHandler = typeof handler === 'function' ? handler : null;
  }

  async function ensureDeviceId(storage) {
    if (_config.deviceId) return _config.deviceId;
    const d = await storage.get([INSTALL_KEY]);
    let id = String(d[INSTALL_KEY] || '').trim();
    if (!id) {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      id = Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
      await storage.set({ [INSTALL_KEY]: id });
    }
    _config.deviceId = id;
    return id;
  }

  async function startSync(alarms) {
    if (!isEnabled()) {
      await stopSync(alarms);
      return;
    }
    await alarms.clear(FLEET_ALARM);
    alarms.create(FLEET_ALARM, { periodInMinutes: 1 });
    await scheduleFastPoll(alarms);
  }

  async function stopSync(alarms) {
    await alarms.clear(FLEET_ALARM);
    await alarms.clear(FLEET_FAST_ALARM);
  }

  async function fleetFetch(path, options) {
    const url = `${_config.baseUrl}${path}`;
    const res = await fetch(url, {
      ...options,
      headers: {
        Authorization: `Bearer ${_config.secret}`,
        'Content-Type': 'application/json',
        ...(options?.headers || {}),
      },
      cache: 'no-store',
    });
    return res;
  }

  async function collectStatus(storage, runStateKey) {
    const d = await storage.get(['posterRunning', runStateKey, 'posterResults']);
    const running = !!d.posterRunning;
    const rs = d[runStateKey] || null;
    const results = d.posterResults || rs?.results || [];
    const total = rs?.config?.groups?.length || 0;
    const done = results.length;
    const ok = results.filter((r) => r.success).length;
    let currentGroup = '';
    if (running && rs && typeof rs.index === 'number' && rs.config?.groups) {
      const g = rs.config.groups[rs.index];
      currentGroup = g?.name || g?.url || '';
    }
    let facebookConnected = false;
    let facebookUserName = '';
    let facebookTabCount = 0;
    let facebookReason = '';
    if (typeof probeFacebookForFleet === 'function') {
      try {
        const fb = await probeFacebookForFleet();
        facebookConnected = !!fb.connected;
        facebookUserName = String(fb.userName || '').slice(0, 80);
        facebookTabCount = Number(fb.tabCount) || 0;
        facebookReason = String(fb.reason || '').slice(0, 120);
      } catch (_) {}
    }
    return {
      posterRunning: running,
      hasRunState: !!rs,
      stopReason: running ? null : (rs?.stopReason || null),
      progress: { done, total, ok, currentGroup },
      facebookConnected,
      facebookUserName,
      facebookTabCount,
      facebookReason,
    };
  }

  async function sendHeartbeat(storage, runStateKey, manifestVersion) {
    if (!isEnabled()) return { ok: false, error: 'Fleet Hub disabled or missing secret' };
    await ensureDeviceId(storage);
    const status = await collectStatus(storage, runStateKey);
    try {
      const res = await fleetFetch('/api/fleet/heartbeat', {
        method: 'POST',
        body: JSON.stringify({
          deviceId: _config.deviceId,
          instanceName: _config.instanceName,
          extensionVersion: manifestVersion || '',
          lastCommandResult: _lastCommandResult,
          ...status,
        }),
      });
      let payload = {};
      try {
        payload = await res.json();
      } catch (_) {}
      if (!res.ok) return { ok: false };

      _lastCommandResult = null;
      const cmds = Array.isArray(payload.commands) ? payload.commands : [];
      for (const cmd of cmds) {
        await processOneCommand(cmd);
      }

      if (cmds.length && _lastCommandResult) {
        const res2 = await fleetFetch('/api/fleet/heartbeat', {
          method: 'POST',
          body: JSON.stringify({
            deviceId: _config.deviceId,
            instanceName: _config.instanceName,
            extensionVersion: manifestVersion || '',
            lastCommandResult: _lastCommandResult,
            ...status,
          }),
        });
        if (res2.ok) _lastCommandResult = null;
      }

      return { ok: true, commandsProcessed: cmds.length };
    } catch {
      return { ok: false };
    }
  }

  async function pollCommands(storage, runStateKey, manifestVersion) {
    if (!isEnabled()) return;
    const st = storage || _storage;
    if (st) await ensureDeviceId(st);
    if (!_config.deviceId) return;
    let gotCmd = false;
    try {
      for (let n = 0; n < 8; n++) {
        const res = await fleetFetch(`/api/fleet/poll?deviceId=${encodeURIComponent(_config.deviceId)}`, {
          method: 'GET',
        });
        if (res.status === 204) break;
        if (!res.ok) break;
        const cmd = await res.json();
        await processOneCommand(cmd);
        gotCmd = true;
      }
      if (gotCmd && st && _lastCommandResult) {
        await sendHeartbeat(st, runStateKey, manifestVersion).catch(() => {});
      }
    } catch (_) {}
  }

  async function uploadScreenshot(imageBase64, meta) {
    if (!isEnabled() || !_config.deviceId || !imageBase64) {
      return { ok: false, message: 'missing screenshot data' };
    }
    const payload = {
      deviceId: _config.deviceId,
      imageBase64,
    };
    if (meta && typeof meta === 'object') {
      if (meta.visionGuard) payload.visionGuard = true;
      if (meta.pauseContext) payload.pauseContext = meta.pauseContext;
    }
    try {
      const res = await fleetFetch('/api/fleet/screenshot', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      let payload = {};
      try {
        payload = await res.json();
      } catch (_) {}
      return {
        ok: !!res.ok && payload.ok !== false,
        message: payload.message || (res.ok ? '' : `HTTP ${res.status}`),
      };
    } catch (e) {
      return { ok: false, message: String(e?.message || e).slice(0, 80) };
    }
  }

  async function syncNow(storage, runStateKey, manifestVersion) {
    if (!isEnabled()) return;
    await sendHeartbeat(storage, runStateKey, manifestVersion);
    await pollCommands(storage, runStateKey, manifestVersion);
  }

  async function tickFast(storage, runStateKey, manifestVersion, alarms) {
    if (!isEnabled()) return;
    await pollCommands(storage, runStateKey, manifestVersion);
    await sendHeartbeat(storage, runStateKey, manifestVersion);
    await scheduleFastPoll(alarms);
  }

  self.FLEET = {
    init,
    onCommand,
    startSync,
    stopSync,
    syncNow,
    tickFast,
    scheduleFastPoll,
    sendHeartbeat,
    pollCommands,
    uploadScreenshot,
    alarmName,
    fastAlarmName,
    isEnabled,
    config: () => ({ ..._config }),
  };
})();
