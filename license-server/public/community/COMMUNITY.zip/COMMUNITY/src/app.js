'use strict';

let groups = [];
let joinCandidates = [];
/** One images array per `.post-block` (max 2 images each). */
let postImages = [[]];
let lastFocusedPostIdx = 0;
const MAX_IMAGES_PER_POST = 3;
let isRunning = false;
let isPausedByUser = false;
let runningPostsSyncTimer = null;
let composeImagesPersistTimer = null;
let cdInterval = null;
/** Timer siempre en minutos (UI sin modo segundos). */
const TIMER_MIN_MINUTES = 5;
const TIMER_MAX_MINUTES = 900;
const TIMER_PRESET_MINUTES = [5, 10, 20];

/** Etiqueta de minutos en la pestaña Timer: ≤60 como "N min", si no "1 h 20 min". */
function formatTimerMinutesForDisplay(minutes) {
  const m = Math.max(0, Math.floor(Number(minutes) || 0));
  if (m <= 60) return m + '\u00a0' + t('abbr_minute_short');
  const h = Math.floor(m / 60);
  const rem = m % 60;
  if (rem) return tfmt('timer_label_hours_mins', { h, m: rem });
  return tfmt('timer_label_hours_only', { h });
}

/** Cuenta atrás en barra de estado / caja: horas, minutos, segundos abreviados. */
function formatCountdownSecondsForDisplay(totalSec) {
  const sec = Math.max(0, Math.floor(Number(totalSec) || 0));
  const h = Math.floor(sec / 3600);
  const mi = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const parts = [];
  if (h > 0) parts.push(h + '\u00a0' + t('abbr_hour_short'));
  if (mi > 0) parts.push(mi + '\u00a0' + t('abbr_minute_short'));
  if (s > 0 || parts.length === 0) parts.push(s + '\u00a0' + t('abbr_second_short'));
  return parts.join(' ');
}
let checkTimer = null;
let activePostingGroupUrls = null;
let lastGroupStatusRenderAt = 0;
let waitCountdownSec = 0;
/** Snapshot for Estado tab flow diagram (posts / groups / loop). */
let lastProgressFlowMeta = { postIndex: 0, totalPosts: 1, totalGroups: 0, resultsDone: 0 };
/** Detalle del último `post_failure_pause` para el banner y para refrescar textos al cambiar idioma. */
let lastFailurePauseDetail = null;
let isProLicenseValid = false;
let licenseRecheckInterval = null;
let posterImageLayersCache = null;
let posterImageLayersLoading = false;
let posterImageLayersPendingCbs = [];
let bridgePostIndexById = {};

function isCommunityFreeBuild() {
  if (typeof IGM_COMMUNITY_FREE !== 'undefined') return !!IGM_COMMUNITY_FREE;
  try {
    return document.documentElement.getAttribute('data-irishka-edition') === 'community';
  } catch (e) {
    return false;
  }
}

function isCommunityProfileFirstEnabled() {
  if (!isCommunityFreeBuild()) return false;
  const cb = document.getElementById('communityProfileFirstEnabled');
  if (!cb) return true;
  return cb.checked;
}

/** Header badge + footer hint: community build without license. */
function refreshCommunityEditionBadge() {
  const badge = document.getElementById('communityEditionBadge');
  const hint = document.getElementById('communityPostOrderHint');
  const wrap = document.getElementById('communityProfileFirstWrap');
  const pfLbl = document.getElementById('communityProfileFirstLabel');
  if (isCommunityFreeBuild()) {
    if (badge) {
      badge.hidden = false;
      badge.textContent = t('community_edition_badge');
    }
    if (wrap) wrap.hidden = false;
    if (pfLbl) pfLbl.textContent = t('community_profile_first_checkbox');
    if (hint) {
      hint.hidden = false;
      hint.textContent = isCommunityProfileFirstEnabled()
        ? t('community_post_order_hint')
        : t('community_post_order_hint_off');
    }
  } else {
    if (badge) badge.hidden = true;
    if (hint) {
      hint.hidden = true;
      hint.remove();
    }
    if (wrap) {
      wrap.hidden = true;
      wrap.remove();
    }
  }
}

/** Pro paid license or community build (full local tools + daily limit UI, no server). */
function hasProTierFeatures() {
  return isProLicenseValid || isCommunityFreeBuild();
}
/** Evita programar varios reload si la UI de licencia se actualiza dos veces seguidas. */
let licenseRevokeReloadScheduled = false;
/** Last FB connection pill state to avoid redundant DOM updates on silent polls. */
let lastConnState = null;
/** Comprobar moderación: mismo botón pasa a Detener; abortar bucle. */
// Moderation check UI removed (requested). Keep internal flags so any
// legacy code paths don't crash if invoked programmatically.
let moderationCheckRunning = false;
let moderationCheckAborted = false;
const HISTORY_KEY = 'fartmily_post_history';
const HISTORY_MAX = 5;
const GROUP_SET_KEY = 'fbGroupSelectionSets';
const JOIN_UI_PREFS_KEY = 'irishka_join_ui_prefs_v1';
const JOIN_CANDIDATES_KEY = 'irishka_join_candidates_v1';
const TEXT_PRESET_KEY = 'fbTextPresets';
const IRISHKA_BRIDGE_CFG_KEY = 'irishkaBridgeConfig';
const IRISHKA_BRIDGE_PENDING_KEY = 'irishkaBridgePendingCompose';
const LICENSE_KEY = 'proLicenseKey';
const LICENSE_STATUS_KEY = 'proLicenseStatus';
const INSTALL_ID_KEY = 'installDeviceId';
/** Production license validation URL (fixed; not shown in UI). */
const LICENSE_VALIDATE_URL = 'https://fb-group-poster-production.up.railway.app/api/license/validate';
const LICENSE_API_ORIGIN = (() => {
  try {
    return new URL(LICENSE_VALIDATE_URL).origin;
  } catch (e) {
    return 'https://fb-group-poster-production.up.railway.app';
  }
})();
const LICENSE_TRANSFER_URL = 'https://fb-group-poster-production.up.railway.app/api/license/transfer-device';
const STRIPE_CHECKOUT_URL = 'https://buy.stripe.com/5kQ6oI4IhcjkeGR8aX4F200';
/** Portal de cliente Stripe (login con correo; Stripe envía enlace al email para gestionar/cancelar). */
const STRIPE_CUSTOMER_PORTAL_LOGIN_URL = 'https://billing.stripe.com/p/login/5kQ6oI4IhcjkeGR8aX4F200';
const THEME_KEY = 'fartmily_theme';
const PENDING_UPDATE_RELOAD_KEY = 'fartmily_pending_update_reload';
const UPDATE_FROM_VER_KEY = 'fartmily_update_from_version';
const UPDATE_TO_VER_KEY = 'fartmily_update_to_version';
/** Pro: { enabled: boolean, limit: number } — límite diario opcional guardado en el cliente. */
const DAILY_LIMIT_PREFS_KEY = 'fartmily_daily_limit_prefs';
/** Misma clave que RUNSTATE_KEY en background — cola pausada (límite diario / alarma perdida). */
const POSTER_RUN_STATE_KEY = 'poster_run_state';
/** Misma clave que JOIN_QUEUE_KEY en background — cola auto-unirse a grupos. */
const JOIN_QUEUE_STORAGE_KEY = 'irishka_join_queue_v1';
/** Community: publicar primero en perfil (timeline). false = solo grupos. */
const COMMUNITY_PROFILE_FIRST_KEY = 'fartmily_community_profile_first';
/** Default successful posts/day when Pro user enables the daily limit (no saved prefs yet). */
const PRO_DAILY_LIMIT_DEFAULT = 10;
/** Max duration for "Load groups from Facebook" (tab open + scroll scan). */
const SCAN_GROUPS_MAX_MS = 90000;
const SCAN_TAB_LOAD_MAX_MS = 12000;
const SEARCH_JOIN_MAX_MS = 60000;
/** Cuenta atrás mostrada en el overlay de escaneo (segundos reales 15 → 0). */
const SCAN_OVERLAY_COUNTDOWN_MS = 20000;

const APP_LANG_CODES = [
  'en', 'es', 'pt', 'fr', 'de', 'it', 'ru', 'nl', 'pl', 'tr',
  'hi', 'tl', 'ur', 'bn', 'id', 'ha', 'ar', 'vi', 'ro'
];

function normalizeFartmilyLangCode(raw) {
  const c = String(raw || '').toLowerCase();
  if (APP_LANG_CODES.indexOf(c) !== -1) return c;
  return 'en';
}

/** Normalize unknown locale codes to English (e.g. after reinstall or typos). */
function migrateStoredLanguage() {
  const key = 'fartmily_lang';
  try {
    const s = localStorage.getItem(key);
    const n = normalizeFartmilyLangCode(s);
    if (s !== n) localStorage.setItem(key, n);
  } catch (e) {}
  try {
    chrome.storage.local.get([key], (d) => {
      const x = d && d[key];
      const n = normalizeFartmilyLangCode(x);
      if (x !== n) chrome.storage.local.set({ [key]: n });
    });
  } catch (e) {}
}

function applyTheme(theme) {
  const t = theme === 'light' ? 'light' : 'dark';
  if (t === 'light') document.documentElement.setAttribute('data-theme', 'light');
  else document.documentElement.removeAttribute('data-theme');
  try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
  try { chrome.storage.local.set({ [THEME_KEY]: t }); } catch (e) {}
  const cb = document.getElementById('themeLight');
  if (cb) {
    cb.checked = t === 'light';
    cb.setAttribute('aria-checked', t === 'light' ? 'true' : 'false');
  }
  syncThemeLabelStyles();
}

function syncThemeLabelStyles() {
  const light = document.getElementById('themeLight')?.checked;
  document.getElementById('themeLabelDark')?.classList.toggle('theme-toggle-active', !light);
  document.getElementById('themeLabelLight')?.classList.toggle('theme-toggle-active', !!light);
}

function initTheme() {
  let t = 'light';
  try { t = localStorage.getItem(THEME_KEY) || 'light'; } catch (e) {}
  applyTheme(t);
}

function clearUpdateReloadNotice() {
  chrome.storage.local.remove([PENDING_UPDATE_RELOAD_KEY, UPDATE_FROM_VER_KEY, UPDATE_TO_VER_KEY]);
}

function refreshUpdateReloadBannerText() {
  const banner = document.getElementById('updateReloadBanner');
  const textEl = document.getElementById('updateReloadText');
  if (!banner || !textEl || !banner.classList.contains('show')) return;
  chrome.storage.local.get([UPDATE_FROM_VER_KEY, UPDATE_TO_VER_KEY], (data) => {
    const from = data[UPDATE_FROM_VER_KEY] || '?';
    const to = String(data[UPDATE_TO_VER_KEY] || chrome.runtime.getManifest().version);
    const raw = t('update_reload_message');
    textEl.textContent = raw.replace(/\{from\}/g, from).replace(/\{to\}/g, to);
  });
}

function maybeShowUpdateReloadBanner() {
  const banner = document.getElementById('updateReloadBanner');
  if (!banner) return;
  chrome.storage.local.get([PENDING_UPDATE_RELOAD_KEY], (data) => {
    if (!data[PENDING_UPDATE_RELOAD_KEY]) return;
    banner.classList.add('show');
    refreshUpdateReloadBannerText();
  });
}

function hasProgrammedResumeAvailable(saved) {
  if (!saved || typeof saved !== 'object') return false;
  if (saved.resumeHint === 'daily_limit') return true;
  if (saved.resumeHint === 'scheduled_start') return true;
  if (typeof saved.plannedStartAt === 'number' && saved.plannedStartAt > 0) return true;
  return false;
}

function updateResumeProgrammedPostingUI() {
  const wrap = document.getElementById('footerResumeProgrammedWrap');
  if (!wrap) return;
  const failureEl = document.getElementById('failurePauseBanner');
  const failureBlocking = !!(failureEl && !failureEl.hasAttribute('hidden'));
  chrome.storage.local.get([POSTER_RUN_STATE_KEY, 'posterRunning'], (d) => {
    const saved = d[POSTER_RUN_STATE_KEY];
    const show =
      !isRunning &&
      !isPausedByUser &&
      !d.posterRunning &&
      !!saved &&
      !!saved.config &&
      hasProgrammedResumeAvailable(saved) &&
      !failureBlocking;
    wrap.hidden = !show;
  });
}

function refreshPauseButtonUI() {
  const btnPause = document.getElementById('btnPause');
  if (!btnPause) return;
  if (isPausedByUser) {
    btnPause.textContent = t('btn_resume') || '▶ Resume';
    btnPause.disabled = false;
  } else {
    btnPause.textContent = t('btn_pause') || '⏸ Pause';
    btnPause.disabled = !isRunning;
  }
}

window.refreshPauseButtonUI = refreshPauseButtonUI;

function setUserPaused(paused) {
  isPausedByUser = !!paused;
  const btnStart = document.getElementById('btnStart');
  const btnStop = document.getElementById('btnStop');
  const bar = document.getElementById('runBar');
  if (btnStart) btnStart.disabled = !!isRunning || isPausedByUser;
  if (btnStop) btnStop.disabled = !isRunning && !isPausedByUser;
  if (bar) bar.className = 'run-bar' + ((isRunning || isPausedByUser) ? ' show' : '');
  refreshPauseButtonUI();
}

function detectUserPausedSessionOnLoad() {
  if (isRunning || isPausedByUser) return;
  chrome.storage.local.get([POSTER_RUN_STATE_KEY, 'posterRunning', 'posterResults', 'posterConfig'], (d) => {
    if (d.posterRunning) return;
    const saved = d[POSTER_RUN_STATE_KEY];
    if (!saved || !saved.config || saved.resumeHint !== 'user_pause') return;
    const r = d.posterResults || [];
    const total = (d.posterConfig && d.posterConfig.groups && d.posterConfig.groups.length)
      ? d.posterConfig.groups.length
      : Math.max(r.length, saved.config.groups?.length || 0, 1);
    const meta = {
      postIndex: typeof saved.postIndex === 'number' ? saved.postIndex : lastProgressFlowMeta.postIndex,
      totalPosts: saved.config.posts ? saved.config.posts.length : lastProgressFlowMeta.totalPosts
    };
    updateProgress(r, total, 0, meta);
    const pausedMsg = t('prog_paused_by_user') || 'Paused';
    const pl = document.getElementById('progLabel');
    if (pl) pl.textContent = pausedMsg;
    const rb = document.getElementById('runBarText');
    if (rb) rb.textContent = pausedMsg;
    setUserPaused(true);
    refreshProgressFlowGuide();
  });
}

function pausePosting() {
  chrome.runtime.sendMessage({
    action: 'stopPosting',
    stopReason: 'user_pause'
  });
}

function resumeAfterUserPause() {
  chrome.runtime.sendMessage({ action: 'resumePostingAfterPause' }, (r) => {
    if (chrome.runtime.lastError || !r || !r.ok) {
      alert(t('failure_resume_failed'));
      return;
    }
    isPausedByUser = false;
    setRunning(true);
    goTab('progress');
  });
}

function initGroupScheduleDatetimeLocal() {
  const inp = document.getElementById('groupScheduleStartAt');
  if (!inp || inp.value) return;
  const d = new Date(Date.now() + 60 * 60 * 1000);
  d.setMinutes(Math.ceil(d.getMinutes() / 15) * 15);
  if (d.getMinutes() >= 60) {
    d.setHours(d.getHours() + 1);
    d.setMinutes(0);
  }
  const pad = (n) => String(n).padStart(2, '0');
  inp.value = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function updateGroupSchedulePostingHint() {
  const hint = document.getElementById('groupSchedulePostingHint');
  const lbl = document.getElementById('groupSchedulePostingLabel');
  const btnSch = document.getElementById('btnSchedulePostingStart');
  const btnCan = document.getElementById('btnCancelSchedulePosting');
  if (lbl) lbl.textContent = t('group_schedule_posting_label');
  if (btnSch) btnSch.textContent = t('btn_schedule_posting');
  if (btnCan) btnCan.textContent = t('btn_cancel_schedule_posting');
  if (!hint) return;
  chrome.storage.local.get([POSTER_RUN_STATE_KEY], (d) => {
    const saved = d[POSTER_RUN_STATE_KEY];
    if (saved && saved.resumeHint === 'scheduled_start' && typeof saved.plannedStartAt === 'number' && saved.plannedStartAt > 0) {
      const when = new Date(saved.plannedStartAt).toLocaleString();
      hint.textContent = tfmt('group_schedule_posting_hint_active', { when });
    } else {
      hint.textContent = t('group_schedule_posting_hint_idle');
    }
  });
}

function onProgressFlowCardClick(e) {
  const oc = e.target.closest('#flowStepOutcome');
  if (!oc || !isRunning || !oc.classList.contains('flow-outcome-clickable')) return;
  e.preventDefault();
  chrome.storage.local.get(['posterConfig'], (d) => {
    const cur = !!(d.posterConfig && d.posterConfig.loopInfinite);
    chrome.runtime.sendMessage({ action: 'setPosterLoopInfinite', loopInfinite: !cur });
  });
}

function appendEditorPostToRunningLoop(postIdx) {
  if (!isRunning) {
    alert(t('alert_append_loop_not_running'));
    return;
  }
  const posts = collectPostsForConfig();
  const post = posts[postIdx];
  if (!post || !String(post.text || '').trim()) {
    alert(t('alert_message_required'));
    return;
  }
  chrome.runtime.sendMessage({ action: 'appendPostToRunningLoop', post }, (r) => {
    if (chrome.runtime.lastError || !r || !r.ok) {
      alert(t('alert_append_loop_failed'));
      return;
    }
    alert(t('alert_append_loop_ok'));
  });
}

async function schedulePostingFromUI() {
  if (isRunning) {
    alert(t('alert_schedule_while_running'));
    return;
  }
  const inp = document.getElementById('groupScheduleStartAt');
  const rawDt = String(inp?.value || '').trim();
  let atMs = NaN;
  if (rawDt) {
    const m = rawDt.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/);
    if (m) {
      const y = Number(m[1]);
      const mo = Number(m[2]) - 1;
      const d = Number(m[3]);
      const h = Number(m[4]);
      const mi = Number(m[5]);
      atMs = new Date(y, mo, d, h, mi, 0, 0).getTime();
    }
  }
  if (!inp || !Number.isFinite(atMs) || atMs <= Date.now()) {
    alert(t('alert_schedule_bad_time'));
    return;
  }
  const posts = collectPostsForConfig();
  if (!posts.some(p => p.text && p.text.trim())) { alert(t('alert_message_required')); return; }
  let selBase = groups.filter(g => g.selected);
  if (!selBase.length) { alert(t('alert_select_one_group')); return; }
  const verifiedOnlyEnabled = document.getElementById('verifiedOnlyEnabled')?.checked;
  const sel = verifiedOnlyEnabled ? selBase.filter(g => g.canPost === true) : selBase;
  if (!sel.length) {
    if (verifiedOnlyEnabled) alert(t('alert_no_verified_groups'));
    else alert(t('alert_select_one_group'));
    return;
  }
  const dailyResumeTime = (document.getElementById('dailyResumeTime')?.value || '09:00').trim();
  if (hasProTierFeatures()) await persistProDailyLimitPrefsAsync();
  const proActive = await readLicenseStatus();
  let dailyLimitEnabled;
  let dailySuccessLimit;
  if (proActive) {
    const prefs = await new Promise((resolve) => {
      chrome.storage.local.get([DAILY_LIMIT_PREFS_KEY], (d) => resolve(d[DAILY_LIMIT_PREFS_KEY]));
    });
    dailyLimitEnabled = prefs?.enabled !== false;
    if (!dailyLimitEnabled) {
      dailySuccessLimit = 0;
    } else {
      let lim = Number(prefs?.limit);
      if (!Number.isFinite(lim) || lim < 1) lim = PRO_DAILY_LIMIT_DEFAULT;
      dailySuccessLimit = lim;
    }
    if (dailyLimitEnabled && (!Number.isFinite(dailySuccessLimit) || dailySuccessLimit < 1)) {
      alert(t('alert_daily_limit_invalid'));
      return;
    }
  } else {
    dailyLimitEnabled = true;
    dailySuccessLimit = 3;
    const dailyLimitInput = document.getElementById('dailySuccessLimit');
    if (dailyLimitInput) dailyLimitInput.value = '3';
    const dailyToggle = document.getElementById('dailyLimitEnabled');
    if (dailyToggle) dailyToggle.checked = true;
    refreshMonetizationUI();
    alert(t('free_daily_limit_forced'));
  }
  if (dailyLimitEnabled && (!Number.isFinite(dailySuccessLimit) || dailySuccessLimit < 1)) {
    alert(t('alert_daily_limit_invalid'));
    return;
  }
  if (dailyLimitEnabled && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(dailyResumeTime)) {
    alert(t('alert_resume_time_invalid'));
    return;
  }
  const hasSpintax = posts.some(p => /\{[^{}]*\|[^{}]*\}/.test(p.text || ''));
  const config = {
    posts,
    text: posts[0].text,
    images: posts[0].images,
    useSpintax: hasSpintax,
    groups: sel,
    timerEnabled: true,
    timerSeconds: (() => {
      const raw = +document.getElementById('timerSec').value;
      const min = Math.min(TIMER_MAX_MINUTES, Math.max(TIMER_MIN_MINUTES, Number.isFinite(raw) ? raw : TIMER_MIN_MINUTES));
      return min * 60;
    })(),
    timerVariation: (+document.getElementById('timerVar').value || 0) * 60,
    dailyLimitEnabled,
    dailySuccessLimit,
    dailyResumeTime,
    bgTabsEnabled: document.getElementById('bgTabsEnabled')?.checked !== false,
    closeTabAfterPost: true,
    notifyEnd: document.getElementById('notifyEnd').checked,
    loopInfinite: document.getElementById('groupLoopInfinite')?.checked === true,
    verifiedOnlyEnabled: document.getElementById('verifiedOnlyEnabled')?.checked === true,
    pauseOnFailedPublication: document.getElementById('pauseOnFailedPublication')?.checked !== false,
    communityProfileFirst: isCommunityFreeBuild() && isCommunityProfileFirstEnabled()
  };
  const sessionWrite = await new Promise((resolve) => {
    posterImageLayersCache = null;
    writePosterImagesSessionThenSlim(config, resolve);
  });
  if (!sessionWrite.ok) {
    try {
      console.warn('[Irishka] Capas de imagen no persistidas del todo; programación sigue (texto en posterConfig).', sessionWrite.error || '');
    } catch (e) {}
    if (!sessionWrite.slim) {
      if (sessionWrite.error === 'session_storage_unavailable') {
        alert(t('alert_session_storage_missing'));
      } else {
        alert(t('alert_storage_session_images_failed') + '\n' + (sessionWrite.error || ''));
      }
      return;
    }
  }
  const slimPoster = sessionWrite.slim;
  await new Promise((resolve) => {
    chrome.storage.local.set({
      fbGroups: groups,
      posterConfig: slimPoster,
      posterRunning: false,
      posterResults: []
    }, () => resolve());
  });
  chrome.runtime.sendMessage({ action: 'schedulePostingAt', atMs }, (r) => {
    if (chrome.runtime.lastError || !r || !r.ok) {
      if (r && r.error === 'already_running') alert(t('alert_resume_programmed_running'));
      else if (r && r.error === 'no_groups') alert(t('alert_select_one_group'));
      else if (r && r.error === 'no_posts') alert(t('alert_message_required'));
      else if (r && r.error === 'bad_time') alert(t('alert_schedule_bad_time'));
      else alert(t('alert_schedule_failed'));
      return;
    }
    lastProgressFlowMeta = {
      postIndex: 0,
      totalPosts: posts.length,
      totalGroups: sel.length,
      resultsDone: 0
    };
    refreshProgressFlowGuide();
    updateResumeProgrammedPostingUI();
    updateGroupSchedulePostingHint();
    goTab('progress');
  });
}

function hideFailurePauseBanner() {
  lastFailurePauseDetail = null;
  document.getElementById('failurePauseBanner')?.setAttribute('hidden', '');
  updateResumeProgrammedPostingUI();
}

function showFailurePauseBanner(pauseDetail) {
  lastFailurePauseDetail = pauseDetail || null;
  const b = document.getElementById('failurePauseBanner');
  if (!b) return;
  const titleEl = document.getElementById('failurePauseBannerTitle');
  const detailEl = document.getElementById('failurePauseBannerDetail');
  if (titleEl) titleEl.textContent = t('failure_pause_title') || '';
  if (detailEl && lastFailurePauseDetail) {
    const g = lastFailurePauseDetail.groupName || '—';
    const err = lastFailurePauseDetail.error || '—';
    detailEl.textContent = tfmt('failure_pause_detail', { group: g, error: err });
  } else if (detailEl) detailEl.textContent = '';
  b.removeAttribute('hidden');
  goTab('progress');
  updateResumeProgrammedPostingUI();
}

/** Llamado desde `applyLang` (i18n): mantiene el texto del banner si sigue visible. */
window.refreshFailurePauseBannerDetail = function refreshFailurePauseBannerDetail() {
  if (!lastFailurePauseDetail) return;
  const detailEl = document.getElementById('failurePauseBannerDetail');
  if (!detailEl) return;
  const g = lastFailurePauseDetail.groupName || '—';
  const err = lastFailurePauseDetail.error || '—';
  detailEl.textContent = tfmt('failure_pause_detail', { group: g, error: err });
};

window.refreshLicenseVersionLabel = function refreshLicenseVersionLabel() {
  const el = document.getElementById('licenseVersionLabel');
  if (!el) return;
  try {
    const v = chrome.runtime.getManifest().version || '—';
    el.textContent = tfmt('license_version_label', { version: v });
  } catch (e) {
    el.textContent = '';
  }
};

const WELCOME_HIDE_KEY = 'fartmily_hide_welcome_v1';

function fillWelcomeModalI18n() {
  const title = document.getElementById('welcomeModalTitle');
  if (!title) return;
  title.textContent = t('welcome_modal_title');
  const bf = document.getElementById('welcomeBadgeFree');
  const bp = document.getElementById('welcomeBadgePro');
  if (bf) bf.textContent = t('welcome_tier_free');
  if (bp) bp.textContent = t('welcome_tier_pro');
  const w1 = t('welcome_step_write');
  const w2 = t('welcome_step_groups');
  const w3 = t('welcome_step_timer');
  const f1 = document.getElementById('welcomeFreeLine1');
  const f2 = document.getElementById('welcomeFreeLine2');
  const f3 = document.getElementById('welcomeFreeLine3');
  const f4 = document.getElementById('welcomeFreeLine4');
  const p1 = document.getElementById('welcomeProLine1');
  const p2 = document.getElementById('welcomeProLine2');
  const p3 = document.getElementById('welcomeProLine3');
  const p4 = document.getElementById('welcomeProLine4');
  if (f1) f1.textContent = w1;
  if (f2) f2.textContent = w2;
  if (f3) f3.textContent = w3;
  if (f4) f4.textContent = isCommunityFreeBuild() ? t('welcome_community_cap') : t('welcome_free_cap');
  if (p1) p1.textContent = w1;
  if (p2) p2.textContent = w2;
  if (p3) p3.textContent = w3;
  if (p4) p4.textContent = t('welcome_pro_cap');
  const dontLbl = document.getElementById('welcomeDontShowLabel');
  if (dontLbl) dontLbl.textContent = t('welcome_dont_show_again');
  const okBtn = document.getElementById('welcomeModalOk');
  if (okBtn) okBtn.textContent = t('welcome_got_it');
}

function welcomeModalOnEscape(ev) {
  if (ev.key === 'Escape') closeWelcomeModal();
}

function closeWelcomeModal() {
  const m = document.getElementById('welcomeModal');
  const cb = document.getElementById('welcomeDontShowAgain');
  if (cb && cb.checked) {
    try { localStorage.setItem(WELCOME_HIDE_KEY, '1'); } catch (e) {}
  }
  if (m) m.setAttribute('hidden', '');
  document.removeEventListener('keydown', welcomeModalOnEscape);
}

function openWelcomeModal() {
  const m = document.getElementById('welcomeModal');
  if (!m) return;
  const cb = document.getElementById('welcomeDontShowAgain');
  if (cb) cb.checked = false;
  fillWelcomeModalI18n();
  m.removeAttribute('hidden');
  document.addEventListener('keydown', welcomeModalOnEscape);
  setTimeout(() => document.getElementById('welcomeModalOk')?.focus(), 0);
}

function maybeShowWelcomeModal() {
  try {
    if (localStorage.getItem(WELCOME_HIDE_KEY) === '1') return;
  } catch (e) {}
  openWelcomeModal();
}

window.syncWelcomeModalStrings = function syncWelcomeModalStrings() {
  const m = document.getElementById('welcomeModal');
  if (!m || m.hasAttribute('hidden')) return;
  fillWelcomeModalI18n();
};

// Init
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  migrateStoredLanguage();
  buildLangBar();
  initLang();
  if (!isCommunityFreeBuild()) refreshCommunityEditionBadge();
  chrome.storage.local.get([COMMUNITY_PROFILE_FIRST_KEY], (d) => {
    const cb = document.getElementById('communityProfileFirstEnabled');
    if (cb && isCommunityFreeBuild()) {
      if (d[COMMUNITY_PROFILE_FIRST_KEY] === false) cb.checked = false;
      else if (d[COMMUNITY_PROFILE_FIRST_KEY] === true) cb.checked = true;
    }
    refreshCommunityEditionBadge();
  });
  maybeShowWelcomeModal();
  document.getElementById('welcomeModalOk')?.addEventListener('click', closeWelcomeModal);
  document.getElementById('welcomeModalBackdrop')?.addEventListener('click', closeWelcomeModal);
  maybeShowUpdateReloadBanner();
  bindAll();
  loadJoinUiPrefs();
  updateResumeProgrammedPostingUI();
  detectUserPausedSessionOnLoad();
  refreshJoinQueueStatePanel();
  loadGroups(() => {
    restorePosterSessionOnLoad();
  });
  loadJoinCandidates();
  initTimerSliders();
  refreshTimerPresetLabels();
  updateTimerUI();
  checkFB(false);
  checkTimer = setInterval(() => checkFB(true), 6000);
  renderPostImages(0);
  updatePostRemoveButtons();
  loadHistory();
  loadGroupSets();
  loadTextPresets();
  removeBridgeLanUICardIfRetailBuild();
  if (isCommunityFreeBuild()) initIrishkaBridgeLan();
  loadSavedLicense();
  if (!isCommunityFreeBuild()) {
    startLicenseRecheckInterval();
    setTimeout(() => silentLicenseRecheck(), 4000);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') silentLicenseRecheck();
    });
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') updateResumeProgrammedPostingUI();
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (
      isCommunityFreeBuild() &&
      changes[IRISHKA_BRIDGE_PENDING_KEY] &&
      (
        changes[IRISHKA_BRIDGE_PENDING_KEY].newValue?.text ||
        Array.isArray(changes[IRISHKA_BRIDGE_PENDING_KEY].newValue?.images)
      )
    ) {
      const incoming = changes[IRISHKA_BRIDGE_PENDING_KEY].newValue;
      chrome.storage.local.remove(IRISHKA_BRIDGE_PENDING_KEY, () => {});
      applyBridgeComposeToEditor(incoming);
    }
    if (changes[TEXT_PRESET_KEY]) {
      renderTextPresets(changes[TEXT_PRESET_KEY].newValue || []);
    }
    if (changes[PENDING_UPDATE_RELOAD_KEY]) {
      const v = changes[PENDING_UPDATE_RELOAD_KEY].newValue;
      if (v) maybeShowUpdateReloadBanner();
    }
    if (changes[POSTER_RUN_STATE_KEY] || changes.posterRunning) {
      updateResumeProgrammedPostingUI();
      if (changes.posterRunning?.newValue === true) {
        hideFailurePauseBanner();
        isPausedByUser = false;
        refreshPauseButtonUI();
      }
    }
    if (changes[JOIN_QUEUE_STORAGE_KEY] && document.getElementById('tab-progress')?.classList.contains('active')) {
      refreshProgressFlowGuide();
      refreshJoinQueueStatePanel();
    }
    if (changes.fartmily_poster_persisted_images) {
      posterImageLayersCache = null;
      if (isRunning) {
        chrome.storage.local.get(['posterConfig'], (d) => {
          syncComposeWithRunningPost(d.posterConfig || {}, lastProgressFlowMeta.postIndex);
        });
      }
    }
    if (!changes[LICENSE_STATUS_KEY] && !changes[LICENSE_KEY]) return;
    if (isCommunityFreeBuild()) {
      applyCommunityLicenseTab();
      return;
    }
    chrome.storage.local.get([LICENSE_KEY, LICENSE_STATUS_KEY], (data) => {
      const key = normalizeLicense(data[LICENSE_KEY] || '');
      const input = document.getElementById('licenseKeyInput');
      if (input && changes[LICENSE_KEY]) input.value = key;
      renderSavedLicenseStatus(key, data[LICENSE_STATUS_KEY]);
    });
  });

});

function setupTelegramControls() {
  const fleetHubEnabled = document.getElementById('fleetHubEnabled');
  const fleetHubSecret = document.getElementById('fleetHubSecret');
  const fleetHubBaseUrl = document.getElementById('fleetHubBaseUrl');
  const fleetHubFields = document.getElementById('fleetHubFields');
  const tgLegacyCard = document.getElementById('tgLegacyCard');
  const tgEnabled = document.getElementById('tgEnabled');
  const tgBotToken = document.getElementById('tgBotToken');
  const tgChatId = document.getElementById('tgChatId');
  const tgInstanceName = document.getElementById('tgInstanceName');
  const tgFields = document.getElementById('tgFields');
  const fleetPanelLink = document.getElementById('fleetPanelLink');
  if (!tgInstanceName) return;

  const DEFAULT_FLEET_URL = 'https://fb-group-poster-production.up.railway.app';

  function refreshRemoteUi(s) {
    const fleetOn = !!s.fleetHubEnabled;
    if (fleetHubFields) fleetHubFields.style.opacity = fleetOn ? '1' : '0.5';
    if (tgLegacyCard) tgLegacyCard.style.opacity = fleetOn ? '0.45' : '1';
    if (tgFields) tgFields.style.opacity = fleetOn ? '0.45' : (s.tgEnabled ? '1' : '0.5');
    if (fleetPanelLink) {
      const base = String(s.fleetHubBaseUrl || DEFAULT_FLEET_URL).trim().replace(/\/$/, '') || DEFAULT_FLEET_URL;
      fleetPanelLink.href = `${base}/fleet/panel.html`;
    }
  }

  chrome.storage.local.get(['settings'], (d) => {
    const s = d.settings || {};
    if (fleetHubEnabled) fleetHubEnabled.checked = !!s.fleetHubEnabled;
    if (fleetHubSecret) fleetHubSecret.value = String(s.fleetHubSecret || '');
    if (fleetHubBaseUrl) fleetHubBaseUrl.value = String(s.fleetHubBaseUrl || DEFAULT_FLEET_URL);
    if (tgEnabled) tgEnabled.checked = !!s.tgEnabled;
    if (tgBotToken) tgBotToken.value = String(s.tgBotToken || '');
    if (tgChatId) tgChatId.value = String(s.tgChatId || '');
    tgInstanceName.value = String(s.tgInstanceName || '');
    refreshRemoteUi(s);
  });

  const persistRemote = async () => {
    const d = await new Promise((resolve) => chrome.storage.local.get(['settings'], resolve));
    const settings = d.settings || {};
    const next = {
      ...settings,
      fleetHubEnabled: !!fleetHubEnabled?.checked,
      fleetHubSecret: fleetHubSecret?.value.trim() || '',
      fleetHubBaseUrl: fleetHubBaseUrl?.value.trim() || DEFAULT_FLEET_URL,
      tgEnabled: fleetHubEnabled?.checked ? false : !!tgEnabled?.checked,
      tgBotToken: tgBotToken?.value.trim() || '',
      tgChatId: tgChatId?.value.trim() || '',
      tgInstanceName: tgInstanceName.value.trim(),
    };
    await new Promise((resolve) => chrome.storage.local.set({ settings: next }, resolve));
    refreshRemoteUi(next);
    chrome.runtime.sendMessage({ action: next.fleetHubEnabled ? 'fleetHubSettingsChanged' : 'tgSettingsChanged' }, () => {});
  };

  fleetHubEnabled?.addEventListener('change', () => {
    if (fleetHubEnabled.checked && tgEnabled) {
      tgEnabled.checked = false;
    }
    persistRemote();
  });
  tgEnabled?.addEventListener('change', () => {
    if (tgEnabled.checked && fleetHubEnabled) {
      fleetHubEnabled.checked = false;
    }
    if (tgFields) tgFields.style.opacity = tgEnabled.checked ? '1' : '0.5';
    persistRemote();
  });
  [fleetHubSecret, fleetHubBaseUrl, tgBotToken, tgChatId, tgInstanceName].forEach((el) => {
    if (!el) return;
    el.addEventListener('change', persistRemote);
    el.addEventListener('blur', persistRemote);
  });

  async function runFleetHeartbeatTest(settings) {
    if (!settings.fleetHubEnabled) return { ok: false, error: 'Enable Fleet Hub first' };
    const secret = String(settings.fleetHubSecret || '').trim();
    const base = String(settings.fleetHubBaseUrl || DEFAULT_FLEET_URL).trim().replace(/\/$/, '') || DEFAULT_FLEET_URL;
    if (!secret) return { ok: false, error: 'Paste fleet secret' };
    const store = await new Promise((resolve) => chrome.storage.local.get(['installDeviceId', 'posterRunning', 'poster_run_state', 'posterResults'], resolve));
    let deviceId = String(store.installDeviceId || '').trim();
    if (!deviceId) {
      const bytes = new Uint8Array(16);
      crypto.getRandomValues(bytes);
      deviceId = Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
      await new Promise((resolve) => chrome.storage.local.set({ installDeviceId: deviceId }, resolve));
    }
    const rs = store.poster_run_state || null;
    const results = store.posterResults || rs?.results || [];
    const total = rs?.config?.groups?.length || 0;
    const done = results.length;
    const okCount = results.filter((r) => r.success).length;
    let res;
    try {
      res = await fetch(`${base}/api/fleet/heartbeat`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${secret}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          deviceId,
          instanceName: String(settings.tgInstanceName || 'Irishka').trim() || 'Irishka',
          extensionVersion: chrome.runtime.getManifest().version,
          posterRunning: !!store.posterRunning,
          hasRunState: !!rs,
          stopReason: rs?.stopReason || null,
          progress: { done, total, ok: okCount, currentGroup: '' },
        }),
      });
    } catch (e) {
      return { ok: false, error: String(e?.message || e || 'Network error') };
    }
    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      return { ok: false, error: `HTTP ${res.status}${txt ? ': ' + txt.slice(0, 100) : ''}` };
    }
    chrome.runtime.sendMessage({ action: 'fleetHubSettingsChanged' }, () => {});
    return { ok: true };
  }

  document.getElementById('btnFleetHubTest')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnFleetHubTest');
    const out = document.getElementById('fleetHubTestResult');
    if (!btn || !out) return;
    await persistRemote();
    btn.disabled = true;
    out.textContent = 'Testing...';
    out.style.color = '';
    const d = await new Promise((resolve) => chrome.storage.local.get(['settings'], resolve));
    const settings = d.settings || {};
    const result = await runFleetHeartbeatTest(settings);
    btn.disabled = false;
    if (result.ok) {
      out.textContent = 'Registered in fleet';
      out.style.color = '#5EC28C';
      return;
    }
    out.textContent = String(result.error || 'Failed');
    out.style.color = '#e88';
  });

  document.getElementById('btnTgTest')?.addEventListener('click', async () => {
    const btn = document.getElementById('btnTgTest');
    const out = document.getElementById('tgTestResult');
    if (!btn || !out) return;
    await persistRemote();
    btn.disabled = true;
    out.textContent = 'Testing...';
    out.style.color = '';
    chrome.runtime.sendMessage({ action: 'tgTestConnection' }, (resp) => {
      btn.disabled = false;
      if (chrome.runtime.lastError) {
        out.textContent = 'Extension error';
        out.style.color = '#e88';
        return;
      }
      if (resp?.ok) {
        out.textContent = 'Connected';
        out.style.color = '#5EC28C';
      } else {
        out.textContent = String(resp?.error || 'Failed');
        out.style.color = '#e88';
      }
    });
  });

  document.getElementById('tgHelpLink')?.addEventListener('click', () => {
    alert(
      'Fleet Hub (recommended):\\n' +
        '1. Set IRISHKA_FLEET_SECRET on Railway (same secret on every PC).\\n' +
        '2. Enable Fleet Hub here + paste secret + unique instance name.\\n' +
        '3. Open your Telegram bot → Fleet Panel (Web App).\\n\\n' +
        'Legacy single-PC mode:\\n' +
        '1. Bot token from @BotFather, chat id from @userinfobot.\\n' +
        '2. Commands: /status, /resume, /stop'
    );
  });
}

// Bind all event listeners
function bindAll() {
  const themeLight = document.getElementById('themeLight');
  if (themeLight) {
    themeLight.addEventListener('change', () => {
      applyTheme(themeLight.checked ? 'light' : 'dark');
    });
  }
  setupTelegramControls();

  document.getElementById('communityProfileFirstEnabled')?.addEventListener('change', () => {
    const cb = document.getElementById('communityProfileFirstEnabled');
    if (cb) chrome.storage.local.set({ [COMMUNITY_PROFILE_FIRST_KEY]: cb.checked });
    refreshCommunityEditionBadge();
  });

  const btnUpdateReloadNow = document.getElementById('btnUpdateReloadNow');
  const btnUpdateReloadAck = document.getElementById('btnUpdateReloadAck');
  if (btnUpdateReloadNow) btnUpdateReloadNow.addEventListener('click', () => location.reload());
  if (btnUpdateReloadAck) {
    btnUpdateReloadAck.addEventListener('click', () => {
      clearUpdateReloadNotice();
      document.getElementById('updateReloadBanner')?.classList.remove('show');
    });
  }

  document.getElementById('btnFailurePauseContinue')?.addEventListener('click', () => {
    hideFailurePauseBanner();
    chrome.runtime.sendMessage({ action: 'resumePostingAfterPause' }, (r) => {
      if (chrome.runtime.lastError || !r || !r.ok) {
        alert(t('failure_resume_failed'));
        return;
      }
      setRunning(true);
      goTab('progress');
    });
  });
  document.getElementById('btnFailurePauseStop')?.addEventListener('click', () => {
    hideFailurePauseBanner();
    stopPosting();
  });

  document.querySelectorAll('.tab').forEach(t => {
    t.addEventListener('click', () => goTab(t.dataset.tab));
    t.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        goTab(t.dataset.tab);
      }
    });
  });

  const postsContainer = document.getElementById('postsContainer');
  postsContainer.addEventListener('click', (e) => {
    const savePreset = e.target.closest('.btn-save-text-preset');
    if (savePreset) {
      const idx = postIdxFromBlock(savePreset);
      if (idx >= 0) saveTextPresetForPost(idx);
      return;
    }
    const loadPreset = e.target.closest('.btn-load-text-preset');
    if (loadPreset) {
      const idx = postIdxFromBlock(loadPreset);
      if (idx >= 0) loadTextPresetForPost(idx);
      return;
    }
    const delPreset = e.target.closest('.btn-delete-text-preset');
    if (delPreset) {
      const idx = postIdxFromBlock(delPreset);
      if (idx >= 0) deleteTextPresetForPost(idx);
      return;
    }
    const emojiBtn = e.target.closest('.emoji-btn');
    if (emojiBtn && postsContainer.contains(emojiBtn)) {
      insertEmoji(emojiBtn.dataset.emoji);
      return;
    }
    const ins = e.target.closest('.sp-insert-btn');
    if (ins) {
      spInsertForPost(+ins.dataset.postIdx);
      return;
    }
    const prev = e.target.closest('.sp-preview-btn');
    if (prev) {
      toggleSpPreviewForPost(+prev.dataset.postIdx);
      return;
    }
    const respin = e.target.closest('.sp-respin-btn');
    if (respin) {
      refreshSpPreviewForPost(+respin.dataset.postIdx);
      return;
    }
    const up = e.target.closest('.post-img-upload');
    if (up) {
      const idx = up.dataset.postIdx;
      const inp = postsContainer.querySelector(`.post-img-input[data-post-idx="${idx}"]`);
      if (inp) inp.click();
      return;
    }
    const rm = e.target.closest('.btn-remove-post');
    if (rm) removePostBlock(+rm.dataset.removeIdx);
    const appendLoop = e.target.closest('.btn-append-active-loop');
    if (appendLoop && postsContainer.contains(appendLoop)) {
      appendEditorPostToRunningLoop(+appendLoop.dataset.appendLoopIdx);
    }
  });
  postsContainer.addEventListener('change', (e) => {
    if (!e.target.classList.contains('post-img-input')) return;
    handlePostImages(e, +e.target.dataset.postIdx);
    queueRunningPostsSync();
  });
  postsContainer.addEventListener('input', (e) => {
    if (!e.target.classList.contains('post-editor')) return;
    updateCC();
    queueRunningPostsSync();
    const block = e.target.closest('.post-block');
    const idx = block ? [...document.querySelectorAll('#postsContainer .post-block')].indexOf(block) : -1;
    if (idx >= 0 && block.querySelector('.sp-preview-wrap')?.classList.contains('sp-preview-open')) {
      refreshSpPreviewForPost(idx);
    }
  });
  postsContainer.addEventListener('focusin', (e) => {
    if (!e.target.classList.contains('post-editor')) return;
    const eds = [...document.querySelectorAll('#postsContainer .post-editor')];
    const i = eds.indexOf(e.target);
    if (i >= 0) lastFocusedPostIdx = i;
  });

  document.getElementById('btnAddPost').addEventListener('click', addPostBlock);

  document.getElementById('btnOpenFb').addEventListener('click', openFacebook);
  document.getElementById('btnScan').addEventListener('click', scanGroups);
  document.getElementById('btnSearchJoinGroups')?.addEventListener('click', searchJoinGroupsByQuery);
  document.getElementById('joinSearchQuery')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      searchJoinGroupsByQuery();
    }
  });
  document.getElementById('joinScanMinDailyPosts')?.addEventListener('change', persistJoinUiPrefs);
  document.getElementById('joinScanMinDailyPosts')?.addEventListener('input', persistJoinUiPrefs);
  document.getElementById('scanRemoveMissingGroups')?.addEventListener('change', persistJoinUiPrefs);
  document.getElementById('joinDailyMax')?.addEventListener('change', persistJoinUiPrefs);
  document.getElementById('joinDailyMax')?.addEventListener('input', persistJoinUiPrefs);
  document.getElementById('joinResumeTime')?.addEventListener('change', persistJoinUiPrefs);
  document.getElementById('btnStartJoinBatch')?.addEventListener('click', () => {
    const urls = joinCandidates.filter((g) => g.selected).map((g) => g.url).filter(Boolean);
    if (!urls.length) {
      alert(t('join_queue_alert_none'));
      return;
    }
    const dailyMax = Math.max(1, Math.min(500, Math.floor(Number(document.getElementById('joinDailyMax')?.value) || 5)));
    const resumeHhmm = normalizeJoinResumeHhmm(document.getElementById('joinResumeTime')?.value);
    persistJoinUiPrefs();
    chrome.runtime.sendMessage({ action: 'startJoinQueue', urls, dailyMax, resumeHhmm }, (r) => {
      if (chrome.runtime.lastError || !r || !r.ok) {
        alert(t('join_queue_start_failed'));
        return;
      }
      appendJoinQueueLog('ok', t('join_queue_started'));
    });
  });
  document.getElementById('btnStopJoinBatch')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'stopJoinQueue' }, () => {
      appendJoinQueueLog('inf', t('join_queue_stopped'));
    });
  });
  document.getElementById('btnSelectAllCandidates')?.addEventListener('click', selectAllJoinCandidates);
  document.getElementById('btnDeselectAllCandidates')?.addEventListener('click', deselectAllJoinCandidates);
  document.getElementById('btnClearCandidates')?.addEventListener('click', clearJoinCandidates);
  document.getElementById('btnVerifyAllGroups').addEventListener('click', () => verifyGroupsPostability('all'));
  document.getElementById('btnVerifyNotVerifiedGroups').addEventListener('click', () => verifyGroupsPostability('not_verified'));
  document.getElementById('btnLeaveNoPostPermission').addEventListener('click', () => requireProLicense(leaveUnpostableGroups));
  document.getElementById('btnLeaveSelectedGroups').addEventListener('click', () => requireProLicense(leaveSelectedGroups));
  // moderation check removed (requested)
  document.getElementById('btnSelectAll').addEventListener('click', selectAll);
  document.getElementById('btnDeselectAll').addEventListener('click', deselectAll);
  document.getElementById('btnClearAll').addEventListener('click', clearAll);
  document.getElementById('btnAddGroup').addEventListener('click', addGroup);
  document.getElementById('groupUrl').addEventListener('keydown', e => { if (e.key === 'Enter') addGroup(); });
  document.getElementById('btnSaveGroupSet').addEventListener('click', saveCurrentGroupSet);
  document.getElementById('btnLoadGroupSet').addEventListener('click', loadSelectedGroupSet);
  document.getElementById('btnDeleteGroupSet').addEventListener('click', deleteSelectedGroupSet);

  document.getElementById('timerSec').addEventListener('input', updateTimerUI);
  document.getElementById('timerVar').addEventListener('input', updateTimerUI);
  document.getElementById('dailyLimitEnabled').addEventListener('change', () => {
    if (hasProTierFeatures()) {
      const on = document.getElementById('dailyLimitEnabled').checked;
      const inp = document.getElementById('dailySuccessLimit');
      if (inp) inp.disabled = !on;
      persistProDailyLimitPrefs();
    }
    updateTimerUI();
  });
  const dailySuccEl = document.getElementById('dailySuccessLimit');
  if (dailySuccEl) {
    dailySuccEl.addEventListener('change', () => {
      if (hasProTierFeatures()) persistProDailyLimitPrefs();
    });
    dailySuccEl.addEventListener('input', () => {
      if (hasProTierFeatures()) persistProDailyLimitPrefs();
    });
  }

  document.getElementById('btnReset').addEventListener('click', resetAll);
  document.getElementById('btnStart').addEventListener('click', startPosting);
  document.getElementById('btnPause')?.addEventListener('click', () => {
    if (isPausedByUser) resumeAfterUserPause();
    else if (isRunning) pausePosting();
  });
  document.getElementById('btnStop').addEventListener('click', stopPosting);
  document.getElementById('btnResumeProgrammedPosting')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'resumeProgrammedPosting' }, (r) => {
      if (chrome.runtime.lastError) {
        alert(t('alert_resume_programmed_failed'));
        return;
      }
      if (!r || !r.ok) {
        if (r && r.error === 'nothing_to_resume') alert(t('alert_resume_programmed_nothing'));
        else if (r && r.error === 'already_running') alert(t('alert_resume_programmed_running'));
        else alert(t('alert_resume_programmed_failed'));
      }
    });
  });
  const upgradeBtn = document.getElementById('btnUpgrade');
  if (upgradeBtn) upgradeBtn.addEventListener('click', openUpgradeCheckout);
  const btnDailyLimitGoPro = document.getElementById('btnDailyLimitGoPro');
  if (btnDailyLimitGoPro) btnDailyLimitGoPro.addEventListener('click', openUpgradeCheckout);
  const checkoutBtn = document.getElementById('btnOpenCheckoutLicense');
  if (checkoutBtn) checkoutBtn.addEventListener('click', openUpgradeCheckout);
  const activateLicenseBtn = document.getElementById('btnActivateLicense');
  if (activateLicenseBtn) activateLicenseBtn.addEventListener('click', () => validateLicenseOnline());
  const removeSubBtn = document.getElementById('btnRemoveSubscription');
  if (removeSubBtn) removeSubBtn.addEventListener('click', removeLocalSubscription);
  bindSubscriptionTerminateModal();
  const transferLicenseBtn = document.getElementById('btnTransferLicense');
  if (transferLicenseBtn) transferLicenseBtn.addEventListener('click', transferLicenseToThisDevice);

  document.getElementById('btnClearHistory').addEventListener('click', clearHistory);

  const loopInf = document.getElementById('groupLoopInfinite');
  if (loopInf) {
    loopInf.addEventListener('change', () => {
      const loopInfinite = loopInf.checked === true;
      chrome.storage.local.get(['posterConfig'], (d) => {
        const pc = { ...(d.posterConfig || {}), loopInfinite };
        chrome.storage.local.set({ posterConfig: pc });
      });
      chrome.runtime.sendMessage({ action: 'setPosterLoopInfinite', loopInfinite });
      refreshProgressFlowGuide();
    });
  }
  document.getElementById('securityStopBannerDismiss')?.addEventListener('click', hideSecurityStopBanner);

  initGroupScheduleDatetimeLocal();
  updateGroupSchedulePostingHint();
  document.getElementById('progressFlowCard')?.addEventListener('click', onProgressFlowCardClick);
  document.getElementById('btnSchedulePostingStart')?.addEventListener('click', () => schedulePostingFromUI());
  document.getElementById('btnCancelSchedulePosting')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'cancelScheduledPosting' }, (r) => {
      if (chrome.runtime.lastError || !r || !r.ok) alert(t('alert_cancel_schedule_nothing'));
      updateGroupSchedulePostingHint();
      updateResumeProgrammedPostingUI();
      refreshProgressFlowGuide();
    });
  });
  document.getElementById('flowSkipActivePostBtn')?.addEventListener('click', () => {
    if (!isRunning) return;
    if (!confirm(t('flow_skip_active_post_confirm'))) return;
    chrome.runtime.sendMessage({ action: 'skipCurrentPosterPost' });
  });
}

function goTab(name) {
  document.querySelectorAll('.tab').forEach(t => {
    const active = t.dataset.tab === name;
    t.classList.toggle('active', active);
    t.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-' + name));
  if (name === 'progress' && typeof refreshProgressFlowGuide === 'function') refreshProgressFlowGuide();
  if (name === 'progress') refreshJoinQueueStatePanel();
  if (name === 'compose' && isRunning) {
    posterImageLayersCache = null;
    chrome.storage.local.get(['posterConfig'], (d) => {
      const cfg = d.posterConfig;
      if (!cfg) return;
      restoreComposeFromPosterConfig(cfg);
      syncComposeWithRunningPost(cfg, lastProgressFlowMeta.postIndex);
    });
  }
}

function openUpgradeCheckout() {
  if (!STRIPE_CHECKOUT_URL) return;
  chrome.tabs.create({ url: STRIPE_CHECKOUT_URL, active: true });
}

function refreshPremiumButtons() {
  const btnIds = ['btnLeaveNoPostPermission', 'btnLeaveSelectedGroups'];
  btnIds.forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const locked = !hasProTierFeatures();
    el.disabled = locked;
    el.style.opacity = locked ? '0.65' : '';
    el.style.cursor = locked ? 'not-allowed' : '';
    el.title = locked ? t('premium_locked_tooltip') : '';
  });
}

function refreshUpgradeCtas() {
  const headerBtn = document.getElementById('btnUpgrade');
  const licenseBtn = document.getElementById('btnOpenCheckoutLicense');

  if (isCommunityFreeBuild()) {
    if (headerBtn) headerBtn.style.display = 'none';
    if (licenseBtn) licenseBtn.style.display = 'none';
    return;
  }

  if (headerBtn) {
    headerBtn.textContent = t('btn_go_pro_unlimited');
    headerBtn.style.display = isProLicenseValid ? 'none' : '';
  }

  if (licenseBtn) {
    licenseBtn.style.display = '';
    if (isProLicenseValid) {
      licenseBtn.textContent = t('pro_active_label');
      licenseBtn.disabled = true;
      licenseBtn.style.opacity = '0.65';
      licenseBtn.style.cursor = 'not-allowed';
    } else {
      licenseBtn.textContent = t('btn_go_pro_unlimited');
      licenseBtn.disabled = false;
      licenseBtn.style.opacity = '';
      licenseBtn.style.cursor = '';
    }
  }
}

function requireProLicense(fn) {
  if (hasProTierFeatures()) return fn();
  alert(t('premium_locked_msg'));
  goTab('license');
}

function persistProDailyLimitPrefs() {
  if (!hasProTierFeatures()) return;
  const enabled = document.getElementById('dailyLimitEnabled')?.checked === true;
  const limit = parseInt(document.getElementById('dailySuccessLimit')?.value, 10);
  chrome.storage.local.set({
    [DAILY_LIMIT_PREFS_KEY]: {
      enabled,
      limit: Number.isFinite(limit) && limit >= 1 ? limit : PRO_DAILY_LIMIT_DEFAULT
    }
  });
}

/** Igual que persistProDailyLimitPrefs pero el caller puede await hasta que chrome.storage haya aplicado el set (evita leer 10 por carrera). */
function persistProDailyLimitPrefsAsync() {
  if (!hasProTierFeatures()) return Promise.resolve();
  const enabled = document.getElementById('dailyLimitEnabled')?.checked === true;
  const limit = parseInt(document.getElementById('dailySuccessLimit')?.value, 10);
  return new Promise((resolve) => {
    chrome.storage.local.set(
      {
        [DAILY_LIMIT_PREFS_KEY]: {
          enabled,
          limit: Number.isFinite(limit) && limit >= 1 ? limit : PRO_DAILY_LIMIT_DEFAULT
        }
      },
      () => resolve()
    );
  });
}

/**
 * Refreshes daily-limit card. Resolves after storage prefs are applied (Pro/Community) so callers
 * like startPosting() read the correct limit — avoids racing on PRO_DAILY_LIMIT_DEFAULT (10).
 * @returns {Promise<void>}
 */
function refreshMonetizationUI() {
  const dailyToggle = document.getElementById('dailyLimitEnabled');
  const dailyLimitInput = document.getElementById('dailySuccessLimit');
  const dailyResumeInput = document.getElementById('dailyResumeTime');
  const card = document.getElementById('dailyLimitCard');
  const freeBlock = document.getElementById('dailyLimitFreeBlock');
  const desc = document.getElementById('dailyLimitDesc');
  const pill = document.getElementById('dailyLimitPlanPill');
  const lockBadge = document.getElementById('dailyLimitLockBadge');
  const btnDailyPro = document.getElementById('btnDailyLimitGoPro');
  if (!dailyToggle || !dailyLimitInput) return Promise.resolve();

  if (hasProTierFeatures()) {
    if (desc) {
      desc.textContent = isCommunityFreeBuild()
        ? t('community_daily_limit_desc')
        : t('daily_limit_card_desc_pro');
    }
    if (pill) {
      pill.textContent = isCommunityFreeBuild()
        ? t('community_daily_limit_pill')
        : t('daily_limit_pill_pro');
      pill.className = 'pro-feature-pill pro-feature-pill--pro';
    }
    if (card) {
      card.classList.add('daily-limit-card--pro');
      card.classList.remove('daily-limit-card--free');
    }
    if (freeBlock) freeBlock.hidden = false;
    if (lockBadge) lockBadge.style.display = 'none';
    if (btnDailyPro) btnDailyPro.style.display = 'none';
    dailyToggle.disabled = false;
    if (dailyResumeInput) dailyResumeInput.disabled = false;
    dailyLimitInput.min = '1';
    dailyLimitInput.max = '99999';
    dailyLimitInput.disabled = false;
    updateTimerUI();
    return new Promise((resolve) => {
      chrome.storage.local.get([DAILY_LIMIT_PREFS_KEY], (d) => {
        const p = d[DAILY_LIMIT_PREFS_KEY];
        let lim = p && Number(p.limit);
        if (!Number.isFinite(lim) || lim < 1) lim = PRO_DAILY_LIMIT_DEFAULT;
        dailyLimitInput.value = String(lim);
        if (!p || p.enabled === undefined) dailyToggle.checked = true;
        else dailyToggle.checked = !!p.enabled;
        dailyLimitInput.disabled = !dailyToggle.checked;
        updateTimerUI();
        resolve();
      });
    });
  }

  dailyToggle.checked = true;
  dailyToggle.disabled = true;
  dailyLimitInput.value = '3';
  dailyLimitInput.disabled = true;
  dailyLimitInput.min = '1';
  dailyLimitInput.max = '99999';
  if (dailyResumeInput) dailyResumeInput.disabled = false;
  if (desc) desc.textContent = t('daily_limit_card_desc_free');
  if (pill) {
    pill.textContent = t('daily_limit_pill_free');
    pill.className = 'pro-feature-pill pro-feature-pill--free';
  }
  if (card) {
    card.classList.add('daily-limit-card--free');
    card.classList.remove('daily-limit-card--pro');
  }
  if (freeBlock) freeBlock.hidden = false;
  if (lockBadge) {
    lockBadge.style.display = '';
    lockBadge.textContent = t('daily_limit_lock_badge');
  }
  if (btnDailyPro) btnDailyPro.style.display = '';
  updateTimerUI();
  return Promise.resolve();
}

function readLicenseStatus() {
  return new Promise((resolve) => {
    chrome.storage.local.get([LICENSE_STATUS_KEY], (data) => {
      const valid = Boolean(data?.[LICENSE_STATUS_KEY]?.valid === true);
      isProLicenseValid = isCommunityFreeBuild() ? false : valid;
      refreshPremiumButtons();
      Promise.resolve(refreshMonetizationUI()).then(() => {
        refreshUpgradeCtas();
        resolve(hasProTierFeatures());
      });
    });
  });
}

/** Igual que license-server canonicalLicenseKey: 16 hex; si sobran, primeros 16; si faltan, vacío. */
function normalizeLicense(input) {
  const hex = String(input || '').replace(/[^0-9a-fA-F]/g, '').toUpperCase();
  if (hex.length === 16) return hex;
  if (hex.length > 16) return hex.slice(0, 16);
  return '';
}

function makeInstallId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

function getOrCreateInstallId() {
  return new Promise((resolve) => {
    chrome.storage.local.get([INSTALL_ID_KEY], (data) => {
      const existing = String(data?.[INSTALL_ID_KEY] || '').trim();
      if (existing) return resolve(existing);
      const next = makeInstallId();
      chrome.storage.local.set({ [INSTALL_ID_KEY]: next }, () => resolve(next));
    });
  });
}

function updateLicenseStatusBox(msg) {
  const box = document.getElementById('licenseStatusBox');
  if (box) box.textContent = msg;
}

function formatCheckedAt(iso) {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleString();
  } catch {
    return '';
  }
}

function setLicenseTransferRowVisible(show) {
  const row = document.getElementById('licenseTransferRow');
  if (row) row.style.display = show ? '' : 'none';
}

/** Si la licencia pasó de Pro válida a no-Pro (otro dispositivo, caducidad, etc.): detiene posting y recarga la app. */
function haltPostingAndReloadBecauseLicenseLost() {
  if (licenseRevokeReloadScheduled) return;
  licenseRevokeReloadScheduled = true;
  try {
    stopPosting('license_lost');
  } catch (e) {}
  setTimeout(() => {
    window.location.reload();
  }, 800);
}

function applyCommunityLicenseTab() {
  const retail = document.getElementById('licenseRetailBlock');
  const comm = document.getElementById('licenseCommunityBlock');
  const welcomePro = document.querySelector('.welcome-col--pro');
  if (!isCommunityFreeBuild()) {
    if (retail) retail.hidden = false;
    if (comm) comm.hidden = true;
    if (welcomePro) welcomePro.hidden = false;
    return;
  }
  if (retail) retail.hidden = true;
  if (comm) {
    comm.hidden = false;
    const title = document.getElementById('licenseCommunityTitle');
    const sub = document.getElementById('licenseCommunitySub');
    if (title) title.textContent = t('community_license_title');
    if (sub) sub.textContent = t('community_license_sub');
  }
  const tabLbl = document.querySelector('.tab[data-tab="license"] .tab-label');
  if (tabLbl) tabLbl.textContent = t('tab_license_community');
  updateLicenseStatusBox(t('community_license_status_line'));
  if (welcomePro) welcomePro.hidden = true;
  setLicenseTransferRowVisible(false);
}

function renderSavedLicenseStatus(key, statusObj, options = {}) {
  if (isCommunityFreeBuild()) {
    applyCommunityLicenseTab();
    return;
  }
  const revokeHalt = options.revokeHalt !== false;
  const wasPro = isProLicenseValid;
  isProLicenseValid = Boolean(statusObj && statusObj.valid === true);
  refreshPremiumButtons();
  refreshMonetizationUI();
  refreshUpgradeCtas();
  setLicenseTransferRowVisible(false);
  if (!key) {
    updateLicenseStatusBox(t('license_status_empty'));
    if (revokeHalt && wasPro && !isProLicenseValid) haltPostingAndReloadBecauseLicenseLost();
    return;
  }
  if (!statusObj || typeof statusObj !== 'object') {
    updateLicenseStatusBox(tfmt('license_status_saved', { key }));
    if (revokeHalt && wasPro && !isProLicenseValid) haltPostingAndReloadBecauseLicenseLost();
    return;
  }
  const checkedAt = formatCheckedAt(statusObj.checkedAt);
  if (statusObj.valid === true) {
    const plan = statusObj.plan || 'PRO';
    updateLicenseStatusBox(tfmt('license_status_valid', { plan, checkedAt }));
    return;
  }
  if (statusObj.valid === false) {
    if (statusObj.code === 'DEVICE_LIMIT_REACHED') {
      updateLicenseStatusBox(tfmt('license_status_device_limit', { checkedAt }));
      setLicenseTransferRowVisible(true);
      if (revokeHalt && wasPro && !isProLicenseValid) haltPostingAndReloadBecauseLicenseLost();
      return;
    }
    const reason = statusObj.message || t('license_invalid_reason_default');
    updateLicenseStatusBox(tfmt('license_status_invalid', { reason, checkedAt }));
    if (revokeHalt && wasPro && !isProLicenseValid) haltPostingAndReloadBecauseLicenseLost();
    return;
  }
  updateLicenseStatusBox(tfmt('license_status_saved', { key }));
  if (revokeHalt && wasPro && !isProLicenseValid) haltPostingAndReloadBecauseLicenseLost();
}

function flowStepCountFromPosterConfig(cfg) {
  const gr = Array.isArray(cfg?.groups) ? cfg.groups : [];
  if (!gr.length) return 0;
  if (isCommunityFreeBuild() && cfg.communityProfileFirst !== false) return gr.length + 1;
  return gr.length;
}

function syncLastProgressFlowMetaFromSavedRun(cfg, saved) {
  if (!cfg) return;
  const postsCount = Array.isArray(cfg.posts) && cfg.posts.length ? cfg.posts.length : 1;
  const steps = flowStepCountFromPosterConfig(cfg);
  const pi = Math.max(0, Math.min(postsCount - 1, Number(saved?.postIndex) || 0));
  const idx = Math.max(0, Number(saved?.index) || 0);
  const fromResults = Array.isArray(saved?.results) ? saved.results.length : 0;
  const resultsDone = Math.min(steps || 0, Math.max(idx, fromResults));
  lastProgressFlowMeta = {
    postIndex: pi,
    totalPosts: postsCount,
    totalGroups: steps,
    resultsDone
  };
}

function loadSavedLicense() {
  chrome.storage.local.get([LICENSE_KEY, LICENSE_STATUS_KEY, 'posterRunning', 'posterConfig', 'posterResults', POSTER_RUN_STATE_KEY], (data) => {
    if (isCommunityFreeBuild()) {
      isProLicenseValid = false;
      applyCommunityLicenseTab();
      refreshPremiumButtons();
      refreshMonetizationUI();
      refreshUpgradeCtas();
      if (data.posterRunning && data.posterConfig && !hasProTierFeatures()) {
        haltPostingAndReloadBecauseLicenseLost();
        return;
      }
      if (data.posterRunning && data.posterConfig) {
        syncLastProgressFlowMetaFromSavedRun(data.posterConfig, data[POSTER_RUN_STATE_KEY]);
        setRunning(true);
        restoreComposeFromPosterConfig(data.posterConfig);
        syncComposeWithRunningPost(data.posterConfig, lastProgressFlowMeta.postIndex);
        const grps = data.posterConfig.groups || [];
        const wantProfile = data.posterConfig.communityProfileFirst !== false;
        const steps = grps.length
          ? (wantProfile
            ? [{ isProfileTimelineSlot: true, name: '', url: 'https://www.facebook.com/me' }, ...grps]
            : grps)
          : [];
        initSteps(steps);
        if (data.posterResults?.length) updateProgress(data.posterResults, steps.length, 0, {
          postIndex: lastProgressFlowMeta.postIndex,
          totalPosts: lastProgressFlowMeta.totalPosts
        });
      }
      refreshProgressFlowGuide();
      return;
    }
    const key = normalizeLicense(data[LICENSE_KEY] || '');
    const input = document.getElementById('licenseKeyInput');
    if (input && key) input.value = key;
    renderSavedLicenseStatus(key, data[LICENSE_STATUS_KEY]);
    if (data.posterRunning && data.posterConfig && !isProLicenseValid) {
      haltPostingAndReloadBecauseLicenseLost();
      return;
    }
    if (data.posterRunning && data.posterConfig) {
      syncLastProgressFlowMetaFromSavedRun(data.posterConfig, data[POSTER_RUN_STATE_KEY]);
      setRunning(true);
      restoreComposeFromPosterConfig(data.posterConfig);
      syncComposeWithRunningPost(data.posterConfig, lastProgressFlowMeta.postIndex);
      initSteps(data.posterConfig.groups);
      if (data.posterResults?.length) updateProgress(data.posterResults, data.posterConfig.groups.length, 0, {
        postIndex: lastProgressFlowMeta.postIndex,
        totalPosts: lastProgressFlowMeta.totalPosts
      });
    }
    refreshProgressFlowGuide();
  });
}

function openStripeCustomerPortalLogin() {
  chrome.tabs.create({ url: STRIPE_CUSTOMER_PORTAL_LOGIN_URL, active: true });
}

function performRemoveLocalSubscription() {
  chrome.storage.local.remove([LICENSE_KEY, LICENSE_STATUS_KEY], () => {
    const input = document.getElementById('licenseKeyInput');
    if (input) input.value = '';
    setLicenseTransferRowVisible(false);
    renderSavedLicenseStatus('', null);
  });
}

function syncSubscriptionTerminateModalTexts() {
  const title = document.getElementById('subscriptionTerminateModalTitle');
  const body = document.getElementById('subscriptionTerminateModalBody');
  const cancel = document.getElementById('btnSubscriptionTerminateCancel');
  const cont = document.getElementById('btnSubscriptionTerminateContinue');
  if (title) title.textContent = t('subscription_terminate_modal_title');
  if (body) body.textContent = t('subscription_terminate_modal_body');
  if (cancel) cancel.textContent = t('subscription_terminate_modal_cancel');
  if (cont) cont.textContent = t('subscription_terminate_modal_continue');
}

function openSubscriptionTerminateModal() {
  const modal = document.getElementById('subscriptionTerminateModal');
  if (!modal) {
    if (!confirm(t('license_remove_confirm'))) return;
    performRemoveLocalSubscription();
    return;
  }
  syncSubscriptionTerminateModalTexts();
  modal.hidden = false;
}

function bindSubscriptionTerminateModal() {
  const modal = document.getElementById('subscriptionTerminateModal');
  const backdrop = document.getElementById('subscriptionTerminateModalBackdrop');
  const cancel = document.getElementById('btnSubscriptionTerminateCancel');
  const cont = document.getElementById('btnSubscriptionTerminateContinue');
  if (!modal || !cancel || !cont) return;
  const close = () => { modal.hidden = true; };
  if (backdrop) backdrop.addEventListener('click', close);
  cancel.addEventListener('click', close);
  cont.addEventListener('click', () => {
    close();
    openStripeCustomerPortalLogin();
    if (!confirm(t('license_remove_confirm'))) return;
    performRemoveLocalSubscription();
  });
  document.addEventListener('keydown', (ev) => {
    if (ev.key !== 'Escape') return;
    if (!modal.hidden) close();
  });
}

function removeLocalSubscription() {
  if (isCommunityFreeBuild()) return;
  openSubscriptionTerminateModal();
}

function startLicenseRecheckInterval() {
  if (licenseRecheckInterval) clearInterval(licenseRecheckInterval);
  if (isCommunityFreeBuild()) return;
  licenseRecheckInterval = setInterval(() => silentLicenseRecheck(), 8 * 60 * 1000);
}

async function silentLicenseRecheck() {
  if (isCommunityFreeBuild()) return;
  const data = await new Promise((resolve) => chrome.storage.local.get([LICENSE_KEY], resolve));
  const key = normalizeLicense(data[LICENSE_KEY] || '');
  if (!key) return;
  await validateLicenseOnline({ silent: true });
}

async function validateLicenseOnline(options = {}) {
  if (isCommunityFreeBuild()) {
    if (!options.silent) alert(t('community_no_license_online'));
    return;
  }
  const silent = Boolean(options.silent);
  let key;
  if (silent) {
    const data = await new Promise((resolve) => chrome.storage.local.get([LICENSE_KEY], resolve));
    key = normalizeLicense(data[LICENSE_KEY] || '');
  } else {
    const input = document.getElementById('licenseKeyInput');
    key = normalizeLicense(input?.value);
  }
  if (!key) {
    if (!silent) alert(t('license_enter_key'));
    return;
  }
  if (!silent) updateLicenseStatusBox(t('license_validating'));
  try {
    const deviceId = await getOrCreateInstallId();
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 12000);
    const res = await fetch(LICENSE_VALIDATE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        licenseKey: key,
        deviceId,
        app: 'irishka-group-master',
        source: 'chrome-extension'
      }),
      signal: ctrl.signal
    });
    clearTimeout(timeout);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json().catch(() => ({}));
    const valid = Boolean(data.valid ?? data.ok ?? data.active);
    const status = {
      valid,
      checkedAt: new Date().toISOString(),
      plan: data.plan || data.tier || '',
      message: data.message || '',
      code: data.code || ''
    };
    chrome.storage.local.set({ [LICENSE_KEY]: key, [LICENSE_STATUS_KEY]: status }, () => {
      renderSavedLicenseStatus(key, status);
    });
  } catch (err) {
    if (silent) return;
    const failedStatus = {
      valid: false,
      checkedAt: new Date().toISOString(),
      plan: '',
      message: String(err?.message || 'Network error'),
      code: ''
    };
    chrome.storage.local.set({
      [LICENSE_KEY]: key,
      [LICENSE_STATUS_KEY]: failedStatus
    }, () => {
      renderSavedLicenseStatus(key, failedStatus, { revokeHalt: false });
    });
  }
}

async function transferLicenseToThisDevice() {
  if (isCommunityFreeBuild()) return;
  const input = document.getElementById('licenseKeyInput');
  const key = normalizeLicense(input?.value);
  if (!key) {
    alert(t('license_enter_key'));
    return;
  }
  if (!confirm(t('license_transfer_confirm'))) return;
  updateLicenseStatusBox(t('license_transfering'));
  setLicenseTransferRowVisible(false);
  try {
    const deviceId = await getOrCreateInstallId();
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 12000);
    const res = await fetch(LICENSE_TRANSFER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        licenseKey: key,
        deviceId,
        app: 'irishka-group-master',
        source: 'chrome-extension'
      }),
      signal: ctrl.signal
    });
    clearTimeout(timeout);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json().catch(() => ({}));
    if (!data.ok && !data.valid) {
      throw new Error(data.message || 'Transfer failed');
    }
    await validateLicenseOnline();
  } catch (err) {
    updateLicenseStatusBox(tfmt('license_transfer_failed', { reason: String(err?.message || 'Error') }));
    const st = await new Promise((resolve) => {
      chrome.storage.local.get([LICENSE_STATUS_KEY], (d) => resolve(d[LICENSE_STATUS_KEY]));
    });
    if (st && st.code === 'DEVICE_LIMIT_REACHED') setLicenseTransferRowVisible(true);
  }
}

// Facebook connection check — silent=true only refreshes status without "checking" flashing (periodic poll).
async function checkFB(silent) {
  if (!silent) setPill('checking', t('verifying'));
  const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);
  if (!tabs.length) {
    if (silent && lastConnState === 'offline') return;
    lastConnState = 'offline';
    setPill('offline', t('no_connection'));
    showConnected(false);
    return;
  }

  const tab = await pickBestFacebookTab(tabs);
  try {
    const res = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: detectFBLogin });
    const loginInfo = res?.[0]?.result;
    if (loginInfo && loginInfo.loggedIn) {
      if (silent && lastConnState === 'online') return;
      lastConnState = 'online';
      const name = loginInfo.name || t('facebook_user_fallback');
      setPill('online', t('online_label'));
      document.getElementById('fbUserName').textContent = name;
      document.getElementById('fbUserSub').textContent = t('connection_verified');
      document.title = 'Irishka Group Master by SBS - ' + name;
      showConnected(true);
    } else {
      if (silent && lastConnState === 'offline') return;
      lastConnState = 'offline';
      setPill('offline', t('no_connection'));
      showConnected(false);
    }
  } catch (err) {
    if (silent && lastConnState === 'offline') return;
    lastConnState = 'offline';
    setPill('offline', t('no_connection'));
    showConnected(false);
  }
}

function detectFBLogin() {
  try {
    if (document.querySelector('#email, input[name="email"], [data-testid="royal_email"]')) {
      return { loggedIn: false, reason: 'Formulario de login visible' };
    }
    if (window.location.pathname.startsWith('/login')) {
      return { loggedIn: false, reason: 'Pagina de login' };
    }
    var UI_LABEL_DENY = {
      'editar perfil': 1, 'edit profile': 1, 'editar tu perfil': 1, 'modifier le profil': 1,
      'modifier votre profil': 1, 'profil bearbeiten': 1, 'modifica profilo': 1,
      'редактировать профиль': 1, 'profiel bewerken': 1, 'edytuj profil': 1, 'profili düzenle': 1,
      'ver perfil': 1, 'view profile': 1, 'voir le profil': 1, 'mi perfil': 1, 'your profile': 1,
      'tu perfil': 1, 'mon profil': 1, 'verified': 1, 'verificado': 1, 'verificada': 1,
      'account': 1, 'cuenta': 1
    };
    function cleanText(t) {
      if (!t) return false;
      var s = t.trim();
      if (s.length < 2 || s.length >= 60) return false;
      var low = s.toLowerCase();
      if (UI_LABEL_DENY[low]) return false;
      if (s.indexOf('Facebook') !== -1 || /^\d/.test(s) || s.indexOf('·') !== -1) return false;
      low = s.toLowerCase();
      if (low.indexOf('search') !== -1 || low.indexOf('buscar') !== -1) return false;
      return true;
    }
    function nameFromProfileLinks() {
      var selList = ['a[href*="/me"]', 'a[href*="profile.php"]', 'a[href^="/profile/"]', 'a[href*="/profile/"]'];
      for (var li = 0; li < selList.length; li++) {
        var anchors = document.querySelectorAll(selList[li]);
        for (var ai = 0; ai < anchors.length; ai++) {
          var spans = anchors[ai].querySelectorAll('span');
          for (var si = 0; si < spans.length; si++) {
            var raw = spans[si].textContent && spans[si].textContent.trim();
            if (raw && cleanText(raw)) return raw;
          }
          var imgAlt = anchors[ai].querySelector('img[alt]');
          if (imgAlt) {
            var altT = imgAlt.getAttribute('alt') && imgAlt.getAttribute('alt').trim();
            if (altT && cleanText(altT)) return altT;
          }
        }
      }
      return null;
    }
    var fromMe = nameFromProfileLinks();
    if (fromMe) return { loggedIn: true, name: fromMe };
    var blueBar = document.querySelector('[data-testid="blue_bar_profile_link"]');
    if (blueBar) {
      var bs = blueBar.querySelectorAll('span');
      for (var bi = 0; bi < bs.length; bi++) {
        var br = bs[bi].textContent && bs[bi].textContent.trim();
        if (br && cleanText(br)) return { loggedIn: true, name: br };
      }
    }
    const profileSels = [
      'a[aria-label*="perfil"] span', 'a[aria-label*="profile"] span', 'a[aria-label*="cuenta"] span'
    ];
    for (const sel of profileSels) {
      const el = document.querySelector(sel);
      if (el && cleanText(el.textContent)) return { loggedIn: true, name: el.textContent.trim() };
    }
    const nav = document.querySelector('[role="banner"], [data-pagelet="NavBar"], header');
    if (nav) {
      for (const s of nav.querySelectorAll('span')) {
        const t = s.textContent?.trim();
        if (cleanText(t) && t.split(' ').length >= 1 && t.split(' ').length <= 5) {
          return { loggedIn: true, name: t };
        }
      }
    }
    const hasMain = document.querySelector(
      '[role="main"], [data-pagelet="GroupFeed"], [data-pagelet="ProfileTimeline"], [data-pagelet="Feed"]'
    );
    if (hasMain) return { loggedIn: true, name: null };
    if (document.cookie.includes('c_user=')) return { loggedIn: true, name: null };
    return { loggedIn: false, reason: 'Sin sesion detectada' };
  } catch (e) {
    return { loggedIn: false, reason: e.message };
  }
}

function extractGroupLinks() {
  const results = [];
  const seen = new Set();
  const EXCLUDED = new Set([
    'feed', 'discover', 'create', 'search', 'joins', 'highlights',
    'videos', 'photos', 'members', 'events', 'files', 'store',
    'about', 'rooms', 'bookmark', 'notifications', 'invite'
  ]);
  document.querySelectorAll('a[href*="/groups/"]').forEach(link => {
    const href = link.href || '';
    const m = href.match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
    if (!m) return;
    const id = m[1];
    if (EXCLUDED.has(id.toLowerCase()) || /^\d{0,3}$/.test(id) || seen.has(id)) return;
    seen.add(id);
    let name = '';
    link.querySelectorAll('span').forEach(s => {
      const t = s.textContent?.trim();
      if (!name && t && t.length > 2 && t.length < 80 && !t.match(/^\d+[KkMm]?$/) && !t.includes('·')) name = t;
    });
    if (!name) name = link.getAttribute('aria-label') || link.textContent?.trim() || '';
    if (!name || name.length < 2) name = id.replace(/[-_]/g, ' ');
    results.push({ url: 'https://www.facebook.com/groups/' + id, name: name.substring(0, 80).trim() });
  });
  return results;
}

/**
 * Runs on facebook.com/groups/joins — extrae enlaces y estima actividad (posts/día) desde el texto de la tarjeta.
 * minDaily <= 0: sin filtro. Si minDaily > 0 y no se puede estimar, se excluye (estricto).
 */
function extractJoinDiscoverGroupsFiltered(minDaily) {
  const MIN = Math.max(0, Math.floor(Number(minDaily) || 0));
  const results = [];
  const seen = new Set();
  const EXCLUDED = new Set([
    'feed', 'discover', 'create', 'search', 'joins', 'highlights',
    'videos', 'photos', 'members', 'events', 'files', 'store',
    'about', 'rooms', 'bookmark', 'notifications', 'invite'
  ]);

  /** Heuristic: member posting cap vs activity text on the same card (runs inside Facebook). */
  function parseMemberDailyPostCap(blob) {
    const raw = String(blob || '');
    const tCompact = raw.replace(/\s+/g, ' ');
    const low = tCompact.toLowerCase();
    if (/unlimited\s+posts?|unlimited\s+posting|posts?\s+unlimited|ilimitad|sin\s+l[ií]mite\s+diari|no\s+daily\s+post|publicaciones\s+ilimitadas|posting\s+without\s+limits?/i.test(low)) {
      return { unlimited: true, limitN: null };
    }
    if (/\bonce\s+(a|per)\s+day\b|\buna\s+(vez|publicaci[oó]n)\s+al\s+d[ií]a\b|\bone\s+post\s+per\s+day\b/i.test(low)) {
      return { unlimited: false, limitN: 1 };
    }
    const memberish = /member|miembro|members|miembros|you\s+can\s+post|puedes\s+publicar|for\s+members|contributions?\s+per\s+day|publicaciones\s+por\s+d[ií]a/i.test(low);
    const rxList = [
      /(?:l[ií]mite|limit|limited|limitado|máx\.?|max\.?)[^.\n]{0,100}?(\d{1,3})\s*(?:posts?|publicaciones?|contribuciones?)[^.\n]{0,50}?(?:per|por|\/|a)\s*(?:day|d[ií]a|24\s*h)/i,
      /(\d{1,3})\s*(?:posts?|publicaciones?|contribuciones?)[^.\n]{0,50}?(?:per|por|\/|a)\s*(?:day|d[ií]a|24\s*h)[^.\n]{0,120}?(?:member|miembro|you\s+can|puedes)/i,
      /(?:member|miembro|members)[^.\n]{0,120}?(\d{1,3})\s*(?:posts?|publicaciones?|contribuciones?)[^.\n]{0,40}?(?:per|por|\/)\s*(?:day|d[ií]a)/i
    ];
    for (let ri = 0; ri < rxList.length; ri++) {
      const m = tCompact.match(rxList[ri]);
      if (m && m[1]) {
        const n = parseInt(m[1], 10);
        if (n >= 1 && n <= 500) return { unlimited: false, limitN: n };
      }
    }
    if (memberish) {
      const m2 = tCompact.match(/(\d{1,3})\s*(?:posts?|publicaciones?)\s*(?:per|por|\/|a)\s*(?:day|d[ií]a)/i);
      if (m2 && m2[1]) {
        const n = parseInt(m2[1], 10);
        if (n >= 1 && n <= 500) return { unlimited: false, limitN: n };
      }
    }
    return { unlimited: false, limitN: null };
  }

  function scoreActivity(blob) {
    const t = String(blob || '').toLowerCase().replace(/\s+/g, ' ');
    let m = t.match(/(\d+)\s*[-–]?\s*(\d+)?\s*(posts?|publicaciones?|publicações|beiträge)\s*(per\s*day|por\s*d[ií]a|\/\s*day|a\s*day|daily|diarios?|par\s*jour|pro\s*tag)/i);
    if (m) return parseInt(m[1], 10);
    m = t.match(/(\d+)\+?\s*(posts?|publicaciones?)\s*(this\s*week|esta\s*semana|this\s*month|este\s*mes)/i);
    if (m) {
      const n = parseInt(String(m[1]).replace('+', ''), 10);
      if (t.includes('week') || t.includes('semana')) return Math.max(1, Math.round(n / 7));
      if (t.includes('month') || t.includes('mes')) return Math.max(1, Math.round(n / 30));
    }
    m = t.match(/(\d+)\s*(posts?|publicaciones?)\s*(per|\/)\s*(day|d[ií]a)/i);
    if (m) return parseInt(m[1], 10);
    if (/very\s*active|muy\s*activo|super\s*activo|très\s*actif|sehr\s*aktiv/i.test(t)) return 15;
    return null;
  }

  function rowBlobForLink(link) {
    let el = link;
    let best = '';
    for (let d = 0; d < 12 && el; d++) {
      const tx = (el.innerText || el.textContent || '').trim();
      if (tx.length > best.length && tx.length < 4000) best = tx;
      el = el.parentElement;
    }
    return best.slice(0, 3500);
  }

  document.querySelectorAll('a[href*="/groups/"]').forEach((link) => {
    const href = link.href || '';
    const m = href.match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
    if (!m) return;
    const id = m[1];
    if (EXCLUDED.has(id.toLowerCase()) || /^\d{0,3}$/.test(id) || seen.has(id)) return;
    let name = '';
    link.querySelectorAll('span').forEach((s) => {
      const tx = s.textContent?.trim();
      if (!name && tx && tx.length > 2 && tx.length < 80 && !tx.match(/^\d+[KkMm]?$/) && !tx.includes('·')) name = tx;
    });
    if (!name) name = link.getAttribute('aria-label') || link.textContent?.trim() || '';
    if (!name || name.length < 2) name = id.replace(/[-_]/g, ' ');
    const blob = rowBlobForLink(link);
    const cap = parseMemberDailyPostCap(blob);
    const score = scoreActivity(blob);
    if (MIN > 0) {
      if (score == null || !Number.isFinite(score) || score < MIN) return;
    }
    seen.add(id);
    const memberPostsUnlimited = !!cap.unlimited;
    let memberDailyLimit = cap.limitN != null && Number.isFinite(cap.limitN) ? cap.limitN : null;
    if (memberPostsUnlimited) memberDailyLimit = null;
    results.push({
      url: 'https://www.facebook.com/groups/' + id,
      name: name.substring(0, 80).trim(),
      activityEst: Number.isFinite(score) ? score : null,
      memberDailyLimit,
      memberPostsUnlimited
    });
  });
  return results;
}

/** Runs inside Facebook joins tab: scroll nested mains and document to load lazy-listed groups. */
function scrollScanPageForMoreGroups() {
  try {
    const anchors = document.querySelectorAll('a[href*="/groups/"]');
    for (let i = anchors.length - 1; i >= 0; i--) {
      const href = anchors[i].href || '';
      const m = href.match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
      if (!m) continue;
      const id = m[1].toLowerCase();
      if (['joins', 'feed', 'discover', 'create', 'search'].includes(id)) continue;
      anchors[i].scrollIntoView({ block: 'end', behavior: 'auto' });
      break;
    }
    document.querySelectorAll('[role="main"]').forEach((main) => {
      const sh = main.scrollHeight;
      const ch = main.clientHeight;
      if (sh > ch + 40) {
        main.scrollTop = Math.min(main.scrollTop + Math.floor(ch * 0.88), sh);
      }
    });
    const step = Math.max(300, Math.floor(window.innerHeight * 0.88));
    window.scrollBy(0, step);
    const docH = Math.max(
      document.body ? document.body.scrollHeight : 0,
      document.documentElement ? document.documentElement.scrollHeight : 0
    );
    window.scrollTo(0, docH);
  } catch (e) {}
}

function persistJoinUiPrefs() {
  try {
    chrome.storage.local.set({
      [JOIN_UI_PREFS_KEY]: {
        minDaily: (() => {
          const el = document.getElementById('joinScanMinDailyPosts');
          const raw = el && el.value !== '' && el.value != null ? Math.floor(Number(el.value)) : 0;
          return Number.isFinite(raw) ? Math.max(0, Math.min(999, raw)) : 0;
        })(),
        removeMissing: !!document.getElementById('scanRemoveMissingGroups')?.checked,
        dailyMax: Math.max(1, Math.min(500, Math.floor(Number(document.getElementById('joinDailyMax')?.value) || 5))),
        resumeHhmm: normalizeJoinResumeHhmm(document.getElementById('joinResumeTime')?.value)
      }
    });
  } catch (e) {}
}

function normalizeJoinResumeHhmm(raw) {
  let s = String(raw || '07:00').trim();
  if (!/^\d{1,2}:\d{2}$/.test(s)) return '07:00';
  const [a, b] = s.split(':');
  const hh = Math.min(23, Math.max(0, parseInt(a, 10) || 0));
  const mm = Math.min(59, Math.max(0, parseInt(b, 10) || 0));
  return String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0');
}

function loadJoinUiPrefs() {
  chrome.storage.local.get([JOIN_UI_PREFS_KEY], (d) => {
    const p = d[JOIN_UI_PREFS_KEY];
    if (!p || typeof p !== 'object') return;
    const m = document.getElementById('joinScanMinDailyPosts');
    if (m && (p.minDaily != null || p.filterMinDaily != null)) {
      const raw = p.minDaily != null ? Number(p.minDaily) : 0;
      const n = Number.isFinite(raw) ? raw : 0;
      m.value = String(Math.max(0, Math.min(999, n)));
    }
    const r = document.getElementById('scanRemoveMissingGroups');
    if (r && typeof p.removeMissing === 'boolean') r.checked = p.removeMissing;
    const dm = document.getElementById('joinDailyMax');
    if (dm && p.dailyMax != null) dm.value = String(Math.max(1, Math.min(500, Number(p.dailyMax))));
    const rt = document.getElementById('joinResumeTime');
    if (rt && p.resumeHhmm) rt.value = normalizeJoinResumeHhmm(p.resumeHhmm);
  });
}

function appendJoinQueueLog(cls, msg) {
  const el = document.getElementById('joinQueueLog');
  if (!el) return;
  el.className = 'scan-log ' + (cls || 'inf');
  el.textContent = msg || '';
}

function loadJoinCandidates() {
  chrome.storage.local.get([JOIN_CANDIDATES_KEY], (d) => {
    const raw = Array.isArray(d[JOIN_CANDIDATES_KEY]) ? d[JOIN_CANDIDATES_KEY] : [];
    joinCandidates = raw.map((g) => ({
      url: g.url,
      name: g.name || '',
      selected: g.selected !== false,
      activityEst: Number.isFinite(Number(g.activityEst)) ? Number(g.activityEst) : null
    })).filter((g) => g.url);
    renderJoinCandidates();
  });
}

function saveJoinCandidates() {
  chrome.storage.local.set({ [JOIN_CANDIDATES_KEY]: joinCandidates });
}

function renderJoinCandidates() {
  const list = document.getElementById('joinCandidatesList');
  const countEl = document.getElementById('joinCandidatesCount');
  if (!list || !countEl) return;
  countEl.textContent = String(joinCandidates.length);
  if (!joinCandidates.length) {
    list.innerHTML = '<div class="empty-note">No active join candidates yet.<br>Use integrated search above.</div>';
    return;
  }
  list.innerHTML = '';
  joinCandidates.forEach((g, i) => {
    const item = document.createElement('div');
    item.className = 'group-item';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = g.selected;
    cb.addEventListener('change', () => {
      joinCandidates[i].selected = cb.checked;
      saveJoinCandidates();
    });
    const info = document.createElement('div');
    info.className = 'group-info';
    const nameEl = document.createElement('div');
    nameEl.className = 'group-name';
    nameEl.textContent = g.name || g.url;
    const urlEl = document.createElement('div');
    urlEl.className = 'group-url-txt';
    urlEl.textContent = g.url;
    const meta = document.createElement('div');
    meta.className = 'group-meta';
    const b = document.createElement('span');
    b.className = 'group-badge ' + (Number.isFinite(Number(g.activityEst)) ? 'ok' : 'unk');
    b.textContent = Number.isFinite(Number(g.activityEst))
      ? ('Posts/day: ' + Math.round(Number(g.activityEst)))
      : 'Posts/day: N/A';
    meta.appendChild(b);
    info.appendChild(nameEl);
    info.appendChild(urlEl);
    info.appendChild(meta);
    const delBtn = document.createElement('button');
    delBtn.className = 'icon-btn';
    delBtn.title = 'Remove candidate';
    delBtn.textContent = 'x';
    delBtn.addEventListener('click', () => {
      joinCandidates.splice(i, 1);
      saveJoinCandidates();
      renderJoinCandidates();
    });
    const goBtn = document.createElement('button');
    goBtn.className = 'btn btn-secondary btn-sm';
    goBtn.style.marginLeft = '6px';
    goBtn.textContent = 'Open';
    goBtn.addEventListener('click', () => chrome.tabs.create({ url: g.url, active: true }));
    item.appendChild(cb);
    item.appendChild(info);
    item.appendChild(goBtn);
    item.appendChild(delBtn);
    list.appendChild(item);
  });
}

function selectAllJoinCandidates() {
  if (!joinCandidates.length) return;
  joinCandidates.forEach((g) => { g.selected = true; });
  saveJoinCandidates();
  renderJoinCandidates();
}

function deselectAllJoinCandidates() {
  if (!joinCandidates.length) return;
  joinCandidates.forEach((g) => { g.selected = false; });
  saveJoinCandidates();
  renderJoinCandidates();
}

function clearJoinCandidates() {
  if (!joinCandidates.length) return;
  if (!confirm('Delete all active join candidates?')) return;
  joinCandidates = [];
  saveJoinCandidates();
  renderJoinCandidates();
}

function onJoinQueueSuccessMoveToPostingList(url) {
  const targetUrl = String(url || '').trim();
  if (!targetUrl) return;
  const key = groupUrlKey(targetUrl);
  if (!key) return;
  let candidate = null;
  const keep = [];
  joinCandidates.forEach((c) => {
    if (groupUrlKey(c.url) === key) {
      if (!candidate) candidate = c;
      return;
    }
    keep.push(c);
  });
  joinCandidates = keep;
  const existsIdx = groups.findIndex((g) => groupUrlKey(g.url) === key);
  if (existsIdx >= 0) {
    const ex = groups.splice(existsIdx, 1)[0];
    groups.push(ex);
  } else {
    const act = Number.isFinite(Number(candidate?.activityEst)) ? Math.round(Number(candidate.activityEst)) : null;
    groups.push({
      url: targetUrl,
      name: (candidate && candidate.name) ? candidate.name : key.replace(/[-_]/g, ' '),
      selected: true,
      canPost: null,
      isMember: true,
      postabilityCheckedAt: null,
      membershipCheckedAt: Date.now(),
      postStatus: null,
      postError: '',
      pendingPostsCount: 0,
      moderationStats: { pending: 0, approved: 0, rejected: 0, deleted: 0 },
      postsPerDayActivity: act,
      postsPerDayMemberLimit: null,
      postsPerDayUnlimited: false
    });
  }
  saveJoinCandidates();
  renderJoinCandidates();
  saveGroups();
  renderGroups();
}

async function focusScanFacebookTab(tab) {
  if (!tab?.id) return;
  try {
    await chrome.tabs.update(tab.id, { active: true });
  } catch (e) {}
  try {
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } catch (e) {}
}

async function restoreTabFocus(tabId) {
  if (tabId == null) return;
  try {
    const t = await chrome.tabs.get(tabId);
    await chrome.windows.update(t.windowId, { focused: true });
    await chrome.tabs.update(tabId, { active: true });
  } catch (e) {}
}

/** Canonical group id segment for matching stored groups to scan results (www vs web, querystrings). */
function groupUrlKey(url) {
  const m = String(url || '').match(/facebook\.com\/groups\/([^/?&#\s]+)/i);
  return m ? String(m[1]).toLowerCase() : '';
}

/** Merge daily-post hints from a Facebook card scan into a stored group row (only overwrites when new data exists). */
function patchDailyPostsFromScan(base, foundRow) {
  const out = { ...base };
  if (foundRow && foundRow.activityEst != null && Number.isFinite(Number(foundRow.activityEst))) {
    out.postsPerDayActivity = Math.round(Number(foundRow.activityEst));
  }
  if (foundRow && foundRow.memberPostsUnlimited) {
    out.postsPerDayUnlimited = true;
    out.postsPerDayMemberLimit = null;
  } else if (foundRow && foundRow.memberDailyLimit != null && Number.isFinite(Number(foundRow.memberDailyLimit))) {
    out.postsPerDayMemberLimit = Math.round(Number(foundRow.memberDailyLimit));
    out.postsPerDayUnlimited = false;
  }
  return out;
}

function defaultDailyPostFields() {
  return { postsPerDayActivity: null, postsPerDayMemberLimit: null, postsPerDayUnlimited: false };
}

/**
 * Merge Facebook scan into `groups`.
 * @param {Array<{url:string,name:string,activityEst?:number|null,memberDailyLimit?:number|null,memberPostsUnlimited?:boolean}>} found
 * @param {{ appendOnly?: boolean }} opts — appendOnly true (default): añade/actualiza nombres sin quitar grupos que ya no salgan en FB. false: reemplazo total como antes.
 */
function mergeGroupsFromFacebookScan(found, opts) {
  const appendOnly = !opts || opts.appendOnly !== false;
  const before = groups.length;
  const oldByKey = new Map();
  groups.forEach((g) => {
    const k = groupUrlKey(g.url);
    if (k) oldByKey.set(k, g);
  });
  let added = 0;
  if (appendOnly) {
    const merged = groups.map((g) => ({ ...g }));
    const idxByKey = new Map();
    merged.forEach((g, i) => {
      const k = groupUrlKey(g.url);
      if (k) idxByKey.set(k, i);
    });
    for (const g of found) {
      const k = groupUrlKey(g.url);
      if (!k) continue;
      const ix = idxByKey.get(k);
      if (ix != null) {
        merged[ix] = patchDailyPostsFromScan({ ...merged[ix], name: g.name }, g);
      } else {
        merged.push(patchDailyPostsFromScan({
          url: g.url,
          name: g.name,
          selected: true,
          canPost: null,
          postabilityCheckedAt: null,
          postStatus: null,
          postError: '',
          pendingPostsCount: 0,
          moderationStats: { pending: 0, approved: 0, rejected: 0, deleted: 0 },
          ...defaultDailyPostFields()
        }, g));
        idxByKey.set(k, merged.length - 1);
        added++;
      }
    }
    groups = merged;
    return { added, removed: 0 };
  }
  const merged = [];
  for (const g of found) {
    const k = groupUrlKey(g.url);
    if (!k) continue;
    const old = oldByKey.get(k);
    if (old) {
      merged.push(patchDailyPostsFromScan({ ...old, name: g.name }, g));
    } else {
      merged.push(patchDailyPostsFromScan({
        url: g.url,
        name: g.name,
        selected: true,
        canPost: null,
        postabilityCheckedAt: null,
        postStatus: null,
        postError: '',
        pendingPostsCount: 0,
        moderationStats: { pending: 0, approved: 0, rejected: 0, deleted: 0 },
        ...defaultDailyPostFields()
      }, g));
      added++;
    }
  }
  const removed = Math.max(0, before + added - merged.length);
  groups = merged;
  return { added, removed };
}

function mergeJoinCandidatesFromSearch(found, opts) {
  const appendOnly = !opts || opts.appendOnly !== false;
  const before = joinCandidates.length;
  const oldByKey = new Map();
  joinCandidates.forEach((g) => {
    const k = groupUrlKey(g.url);
    if (k) oldByKey.set(k, g);
  });
  let added = 0;
  if (appendOnly) {
    const merged = joinCandidates.map((g) => ({ ...g }));
    const idxByKey = new Map();
    merged.forEach((g, i) => {
      const k = groupUrlKey(g.url);
      if (k) idxByKey.set(k, i);
    });
    for (const g of found) {
      const k = groupUrlKey(g.url);
      if (!k) continue;
      const ix = idxByKey.get(k);
      if (ix != null) {
        merged[ix] = { ...merged[ix], name: g.name, activityEst: g.activityEst };
      } else {
        merged.push({ url: g.url, name: g.name, selected: true, activityEst: g.activityEst || null });
        idxByKey.set(k, merged.length - 1);
        added++;
      }
    }
    joinCandidates = merged;
    return { added, removed: 0 };
  }
  const merged = [];
  for (const g of found) {
    const k = groupUrlKey(g.url);
    if (!k) continue;
    const old = oldByKey.get(k);
    if (old) merged.push({ ...old, name: g.name, activityEst: g.activityEst || old.activityEst || null });
    else {
      merged.push({ url: g.url, name: g.name, selected: true, activityEst: g.activityEst || null });
      added++;
    }
  }
  const removed = Math.max(0, before + added - merged.length);
  joinCandidates = merged;
  return { added, removed };
}

function openFacebook() {
  chrome.tabs.create({ url: 'https://www.facebook.com/', active: true }, () => {
    setPill('checking', t('opening_fb'));
    setTimeout(() => checkFB(false), 4000);
  });
}

async function scanGroups() {
  // Member groups loader: keeps posting list and does not use discover search candidates.
  const btn = document.getElementById('btnScan');
  const icon = document.getElementById('scanIcon');
  const txt = document.getElementById('scanTxt');
  const logEl = document.getElementById('scanLog');
  let scanTab = null;
  let returnToTabId = null;

  btn.disabled = true;
  icon.textContent = '⏳';
  txt.textContent = t('scanning');
  setLog(logEl, 'inf', t('searching_fb_tab'));

  try {
    const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);
    if (!tabs.length) { setLog(logEl, 'err', t('open_fb_first')); resetScanBtn(btn, icon, txt); return; }
    const fbTab = await pickBestFacebookTab(tabs);
    const scanDeadline = Date.now() + SCAN_GROUPS_MAX_MS;
    const prevActive = await chrome.tabs.query({ active: true, currentWindow: true });
    returnToTabId = prevActive[0]?.id ?? null;
    const isWeb = (fbTab.url || '').includes('web.facebook.com');
    const targetUrl = isWeb
      ? 'https://web.facebook.com/groups/joins/?nav_source=tab'
      : 'https://www.facebook.com/groups/joins/?nav_source=tab';
    setLog(logEl, 'inf', 'Loading your member groups...');
    scanTab = await createTabAndWait(targetUrl, true, SCAN_TAB_LOAD_MAX_MS);
    await focusScanFacebookTab(scanTab);
    await sleep(1200);
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      files: ['src/scan-overlay-inject.js']
    });
    const overlayCountdownEnd = Date.now() + SCAN_OVERLAY_COUNTDOWN_MS;
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      args: [t('scan_overlay_please_wait'), t('scan_overlay_detected_label'), t('scan_overlay_time_label'), overlayCountdownEnd],
      func: (pleaseWait, detLab, timeLab, deadlineMs) => {
        window.fartmilyScanOverlayInit?.(pleaseWait, detLab, timeLab, deadlineMs);
      }
    });
    const foundMap = new Map();
    let noGrowth = 0;
    for (let i = 0; i < 160; i++) {
      const res = await chrome.scripting.executeScript({
        target: { tabId: scanTab.id },
        func: extractJoinDiscoverGroupsFiltered,
        args: [0]
      });
      const pageFound = res?.[0]?.result || [];
      const prevCount = foundMap.size;
      pageFound.forEach((g) => foundMap.set(g.url, g));
      const growth = foundMap.size - prevCount;
      setLog(logEl, 'inf', foundMap.size + ' ' + t('groups_detected'));
      await chrome.scripting.executeScript({
        target: { tabId: scanTab.id },
        args: [foundMap.size, t('scan_overlay_detected_label')],
        func: (count, detLab) => {
          window.fartmilyScanOverlayUpdateDetected?.(count, detLab);
        }
      });
      if (Date.now() >= scanDeadline) break;
      if (growth === 0) noGrowth++;
      else noGrowth = 0;
      if (noGrowth >= 12) break;
      await chrome.scripting.executeScript({
        target: { tabId: scanTab.id },
        func: scrollScanPageForMoreGroups
      });
      await sleep(growth > 0 ? 700 : 1500);
    }
    const found = Array.from(foundMap.values());
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      func: () => {
        window.fartmilyScanOverlayRemove?.();
      }
    });
    try { chrome.tabs.remove(scanTab.id); } catch (e) {}
    scanTab = null;
    await restoreTabFocus(returnToTabId);
    if (!found.length) {
      setLog(logEl, 'err', t('no_results_scan'));
    } else {
      const removeMissing = !!(document.getElementById('scanRemoveMissingGroups') && document.getElementById('scanRemoveMissingGroups').checked);
      const { added, removed } = mergeGroupsFromFacebookScan(found, { appendOnly: !removeMissing });
      saveGroups();
      renderGroups();
      setLog(logEl, 'ok', tfmt('log_scan_sync_ok', { total: found.length, added, removed }));
    }
  } catch (e) {
    setLog(logEl, 'err', t('error_label') + ': ' + (e.message || t('unknown')));
    try { if (scanTab?.id) chrome.tabs.remove(scanTab.id); } catch (_) {}
    scanTab = null;
    await restoreTabFocus(returnToTabId);
  }
  resetScanBtn(btn, icon, txt);
}

/** Fusiona resultados de executeScript con allFrames (cada iframe devuelve su propio array). */
function mergeInjectedFrameResults(injectionResults) {
  const byUrl = new Map();
  if (!Array.isArray(injectionResults)) return [];
  for (const fr of injectionResults) {
    if (fr && fr.error) continue;
    const arr = fr && fr.result;
    if (!Array.isArray(arr)) continue;
    for (const g of arr) {
      if (g && typeof g.url === 'string' && !byUrl.has(g.url)) byUrl.set(g.url, g);
    }
  }
  return Array.from(byUrl.values());
}

async function searchJoinGroupsByQuery() {
  const btn = document.getElementById('btnSearchJoinGroups');
  const logEl = document.getElementById('scanLog');
  const queryInput = document.getElementById('joinSearchQuery');
  const rawQuery = String(queryInput?.value || '').trim();
  if (!rawQuery) {
    setLog(logEl, 'err', 'Write a search term first (e.g. jobs in netherlands).');
    return;
  }
  let scanTab = null;
  let returnToTabId = null;

  btn.disabled = true;
  const prevBtnText = btn.textContent;
  btn.textContent = 'Searching...';
  setLog(logEl, 'inf', t('searching_fb_tab'));

  try {
    const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);
    if (!tabs.length) { setLog(logEl, 'err', t('open_fb_first')); btn.disabled = false; btn.textContent = prevBtnText; return; }

    const fbTab = await pickBestFacebookTab(tabs);
    setLog(logEl, 'inf', 'Opening integrated group search...');

    const scanDeadline = Date.now() + SEARCH_JOIN_MAX_MS;

    const prevActive = await chrome.tabs.query({ active: true, currentWindow: true });
    returnToTabId = prevActive[0]?.id ?? null;

    // Pestaña en primer plano: en segundo plano Chrome/FB suelen no cargar la lista completa.
    const isWeb = (fbTab.url || '').includes('web.facebook.com');
    const encodedQ = encodeURIComponent(rawQuery);
    const targetUrl = isWeb
      ? ('https://web.facebook.com/search/groups/?q=' + encodedQ)
      : ('https://www.facebook.com/search/groups/?q=' + encodedQ);
    scanTab = await createTabAndWait(targetUrl, true, SCAN_TAB_LOAD_MAX_MS);
    await focusScanFacebookTab(scanTab);

    if (Date.now() >= scanDeadline) {
      try { chrome.tabs.remove(scanTab.id); } catch (e) {}
      await restoreTabFocus(returnToTabId);
      setLog(logEl, 'err', tfmt('scan_time_exceeded', { sec: Math.round(SEARCH_JOIN_MAX_MS / 1000) }));
      btn.disabled = false; btn.textContent = prevBtnText;
      return;
    }

    await sleep(Math.min(2200, Math.max(0, scanDeadline - Date.now())));
    if (Date.now() >= scanDeadline) {
      try { chrome.tabs.remove(scanTab.id); } catch (e) {}
      await restoreTabFocus(returnToTabId);
      setLog(logEl, 'err', tfmt('scan_time_exceeded', { sec: Math.round(SEARCH_JOIN_MAX_MS / 1000) }));
      btn.disabled = false; btn.textContent = prevBtnText;
      return;
    }
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id, allFrames: false },
      func: function fartmilyPrimeFbSearchGroupDom() {
        const sel =
          'a[href*="/groups/"],a[href*="facebook.com/groups/"],a[href*="fb.com/groups/"],[role="link"][href*="/groups/"]';
        for (let iter = 0; iter < 14; iter++) {
          if (document.querySelectorAll(sel).length >= 3) break;
          document.querySelectorAll('[role="main"]').forEach((m) => {
            const sh = m.scrollHeight;
            const ch = m.clientHeight || 1;
            if (sh > ch + 30) m.scrollTop = Math.min(m.scrollTop + Math.floor(ch * 0.55), sh);
          });
          window.scrollBy(0, Math.min(520, Math.floor((window.innerHeight || 800) * 0.45)));
        }
      }
    });
    setLog(logEl, 'inf', 'Reading search results (public groups, min activity)...');
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      files: ['src/scan-overlay-inject.js']
    });
    const overlayCountdownEnd = Date.now() + SCAN_OVERLAY_COUNTDOWN_MS;
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      args: [t('scan_overlay_please_wait'), t('scan_overlay_detected_label'), t('scan_overlay_time_label'), overlayCountdownEnd],
      func: (pleaseWait, detLab, timeLab, deadlineMs) => {
        window.fartmilyScanOverlayInit?.(pleaseWait, detLab, timeLab, deadlineMs);
      }
    });

    await focusScanFacebookTab(scanTab);

    const foundMap = new Map();
    let noGrowthStreak = 0;
    // Scroll + re-extract until count stabilizes or time runs out (FB loads the list lazily).
    const minEl = document.getElementById('joinScanMinDailyPosts');
    /** Búsqueda: 0 = sin filtro por actividad; >0 = mínimo de posts/día estimado en la tarjeta. */
    const rawMin = minEl && minEl.value !== '' && minEl.value != null ? Math.floor(Number(minEl.value)) : 0;
    const minDaily = Number.isFinite(rawMin) ? Math.max(0, Math.min(999, rawMin)) : 0;
    setLog(logEl, 'inf', 'Search min. posts/day (0=off): ' + String(minDaily));

    for (let i = 0; i < 42; i++) {
      await focusScanFacebookTab(scanTab);
      const res = await chrome.scripting.executeScript({
        target: { tabId: scanTab.id, allFrames: false },
        func: extractJoinSearchGroupsFiltered,
        args: [minDaily, rawQuery]
      });
      const pageFound = mergeInjectedFrameResults(res);
      const prevCount = foundMap.size;
      pageFound.forEach(g => foundMap.set(g.url, g));
      const growth = foundMap.size - prevCount;
      if (growth === 0) noGrowthStreak++;
      else noGrowthStreak = 0;
      setLog(logEl, 'inf', foundMap.size + ' ' + t('groups_detected'));
      await chrome.scripting.executeScript({
        target: { tabId: scanTab.id },
        args: [foundMap.size, t('scan_overlay_detected_label')],
        func: (count, detLab) => {
          window.fartmilyScanOverlayUpdateDetected?.(count, detLab);
        }
      });
      if (Date.now() >= scanDeadline) break;
      if (foundMap.size > 0 && noGrowthStreak >= 7) break;
      if (foundMap.size >= 12 && noGrowthStreak >= 4) break;
      await chrome.scripting.executeScript({
        target: { tabId: scanTab.id, allFrames: false },
        func: scrollScanPageForMoreGroups
      });
      const baseWait = growth > 0 ? 280 : 420;
      const sleepMs = Math.min(baseWait, Math.max(0, scanDeadline - Date.now()));
      if (sleepMs < 80) break;
      await sleep(sleepMs);
    }
    const found = Array.from(foundMap.values());
    await chrome.scripting.executeScript({
      target: { tabId: scanTab.id },
      func: () => {
        window.fartmilyScanOverlayRemove?.();
        const old = document.getElementById('igs-scan-timer');
        if (old) old.remove();
      }
    });
    try { chrome.tabs.remove(scanTab.id); } catch (e) {}
    scanTab = null;
    await restoreTabFocus(returnToTabId);

    if (!found.length) {
      setLog(logEl, 'err', t('no_results_scan'));
    } else {
      const removeMissing = !!(document.getElementById('scanRemoveMissingGroups') && document.getElementById('scanRemoveMissingGroups').checked);
      const { added, removed } = mergeJoinCandidatesFromSearch(found, { appendOnly: !removeMissing });
      saveJoinCandidates();
      renderJoinCandidates();
      setLog(logEl, 'ok', `Search list updated: ${found.length} results · ${added} added · ${removed} removed.`);
    }
  } catch (e) {
    setLog(logEl, 'err', t('error_label') + ': ' + (e.message || t('unknown')));
    try {
      if (scanTab?.id) {
        await chrome.scripting.executeScript({
          target: { tabId: scanTab.id },
          func: () => {
            window.fartmilyScanOverlayRemove?.();
            const old = document.getElementById('igs-scan-timer');
            if (old) old.remove();
          }
        });
      }
    } catch (_) {}
    try {
      if (scanTab?.id) chrome.tabs.remove(scanTab.id);
    } catch (_) {}
    scanTab = null;
    await restoreTabFocus(returnToTabId);
  }
  btn.disabled = false;
  btn.textContent = prevBtnText;
}

function extractJoinSearchGroupsFiltered(minDaily, rawQuery) {
  const MIN = Math.max(0, Math.floor(Number(minDaily) || 0));
  const qNorm = String(rawQuery || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ' ');
  const stop = new Set(['in', 'the', 'of', 'for', 'to', 'and', 'de', 'la', 'el', 'en', 'y', 'para', 'a', 'los', 'las']);
  const qTokensRaw = qNorm.split(/[^a-z0-9]+/i).map((s) => s.trim()).filter((s) => s.length >= 2);
  const qTokens = qTokensRaw.filter((tk) => !stop.has(tk));
  const results = [];
  const seen = new Set();
  const EXCLUDED = new Set(['feed', 'discover', 'create', 'search', 'joins', 'highlights', 'videos', 'photos', 'members', 'events', 'files', 'store', 'about', 'rooms', 'bookmark', 'notifications', 'invite', 'browse', 'suggested', 'quality', 'people']);
  let onFederatedSearch = false;
  try {
    const loc = String(typeof location !== 'undefined' && location.href ? location.href : '');
    const qs = String(typeof location !== 'undefined' && location.search ? location.search : '');
    const path = String(typeof location !== 'undefined' && location.pathname ? location.pathname : '');
    const host = String(typeof location !== 'undefined' && location.hostname ? location.hostname : '').toLowerCase();
    const hostFb =
      host === 'facebook.com' ||
      host.endsWith('.facebook.com') ||
      host === 'fb.com' ||
      host.endsWith('.fb.com');
    onFederatedSearch =
      ((/[?&]q=/i.test(loc) || /[?&]q=/i.test(qs)) && (/facebook\.com|fb\.com/i.test(loc) || hostFb)) ||
      (/\/search\//i.test(loc) && (/facebook\.com|fb\.com/i.test(loc) || hostFb)) ||
      (/\/search\/groups/i.test(path) && hostFb) ||
      (/\/search\/top\/?/i.test(path) && /[?&]q=/i.test(qs) && hostFb);
  } catch (e) {}
  function isAlreadyMember(text) {
    const t = String(text || '').toLowerCase();
    if (t.includes("you're a member") || t.includes('you are a member')) return true;
    if (t.includes('member of this group')) return true;
    if (t.includes('eres miembro') || t.includes('ya eres miembro')) return true;
    if (t.includes('miembro del grupo') || t.includes('miembro de este grupo')) return true;
    if (/you('ve| have)\s+joined\s+this/i.test(t)) return true;
    if (/te\s+uniste\s+a\s+este/i.test(t)) return true;
    return false;
  }
  function extractGroupIdFromHref(href) {
    const h = String(href || '').trim();
    const rel = h.match(/^\/groups\/([^/?&#\s]+)/i);
    if (rel && rel[1]) return rel[1];
    const direct = h.match(/(?:facebook|fb)\.com\/groups\/([^/?&#\s]+)/i);
    if (direct && direct[1]) return direct[1];
    // Search pages sometimes wrap links via /l.php?u=...
    const uParam = h.match(/[?&]u=([^&]+)/i);
    if (uParam && uParam[1]) {
      try {
        const decoded = decodeURIComponent(uParam[1]);
        const nested = decoded.match(/(?:facebook|fb)\.com\/groups\/([^/?&#\s]+)/i);
        if (nested && nested[1]) return nested[1];
      } catch (e) {}
    }
    return null;
  }
  function scoreActivityDiscoverFallback(tCompact) {
    const parseK = (raw) => {
      const s = String(raw || '').toLowerCase().replace(/,/g, '').trim();
      if (!s) return NaN;
      if (s.endsWith('k')) return Math.round(parseFloat(s.slice(0, -1)) * 1000);
      if (s.endsWith('m')) return Math.round(parseFloat(s.slice(0, -1)) * 1000000);
      return parseFloat(s);
    };
    const t = String(tCompact || '').toLowerCase().replace(/\s+/g, ' ');
    let m = t.match(
      /(\d+(?:[.,]\d+)?[km]?)\s*[-–]?\s*(\d+(?:[.,]\d+)?[km]?)?\s*(posts?|publicaciones?|publicações|publications?|beitr[aä]ge)\s*(per\s*day|par\s*jour|par\s*mois|por\s*d[ií]a|al\s*d[ií]a|\/\s*day|a\s*day|daily|diarios?|diarias?|pro\s*tag|\/\s*d[ií]a)/i
    );
    if (m) {
      const v = Math.round(parseK(m[1]));
      if (Number.isFinite(v)) return v;
    }
    m = t.match(
      /(\d+(?:[.,]\d+)?[km]?)\s*\+?\s*(posts?|publicaciones?|publications?)\s*(this\s*week|esta\s*semana|this\s*month|este\s*mes)/i
    );
    if (m) {
      const n = parseK(m[1]);
      if (Number.isFinite(n)) {
        if (t.includes('week') || t.includes('semana')) return Math.max(1, Math.round(n / 7));
        if (t.includes('month') || t.includes('mes')) return Math.max(1, Math.round(n / 30));
      }
    }
    m = t.match(/(\d+(?:[.,]\d+)?[km]?)\s*(posts?|publicaciones?|publications?)\s*(per|por|par|\/|al)\s*(day|d[ií]a|jour)/i);
    if (m) {
      const v = Math.round(parseK(m[1]));
      if (Number.isFinite(v)) return v;
    }
    m = t.match(/(\d+(?:[.,]\d+)?[km]?)\s*(posts?|publicaciones?)\s*[/\u00b7·]\s*(day|d[ií]a|jour)/i);
    if (m) {
      const v = Math.round(parseK(m[1]));
      if (Number.isFinite(v)) return v;
    }
    if (/very\s*active|muy\s*activo|super\s*activo|très\s*actif|sehr\s*aktiv/i.test(t)) return 15;
    return null;
  }
  function scoreActivity(blob) {
    const CAP = 500;
    const parseNum = (raw) => {
      const s = String(raw || '').toLowerCase().replace(/,/g, '').trim();
      if (!s) return NaN;
      if (s.endsWith('k')) return Math.round(parseFloat(s.slice(0, -1)) * 1000);
      if (s.endsWith('m')) return Math.round(parseFloat(s.slice(0, -1)) * 1000000);
      return parseFloat(s);
    };
    const clampDay = (n) => {
      if (!Number.isFinite(n)) return null;
      const r = Math.round(n);
      if (r < 0) return null;
      return Math.min(CAP, r);
    };
    const postWord =
      '(posts?|publicaciones?|publica[cç][oõ]es|publicações|publications?|beitr[aä]ge|publicati(?:on|ons))';
    const dayWord = '(day|days?|d[ií]a|dias?|jour|jours?|tag|tage?|daily|diarios?|diarias?)';
    const midArticles = '(?:a|al|ao|per|por|par|\\/)?';
    const text = String(blob || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[\u00b7•｜|]/g, '\n');
    const lines = text
      .split(/\n+/)
      .map((l) => l.trim())
      .filter(Boolean)
      .slice(0, 160);
    const strongDayHint =
      /(per\s*day|por\s*d[ií]a|al\s*d[ií]a|\/\s*day|\/\s*d[ií]a|\ba\s*day\b|daily|diarios?|diarias?|\bjours?\b|\bjour\b|pro\s*tag|par\s+jour)/i;
    const extractFromLine = (rawLine) => {
      const line = String(rawLine || '')
        .toLowerCase()
        .replace(/\s+/g, ' ');
      if (/(members?|miembros?|member|likes?|comentarios?|comments?)\b/i.test(line) && !new RegExp(postWord, 'i').test(line)) return null;
      if (!new RegExp(postWord, 'i').test(line)) return null;
      let m = line.match(
        new RegExp(
          '([\\d.,]+[km]?)\\s*\\+?\\s*' + postWord + '\\s*' + midArticles + '\\s*' + dayWord,
          'i'
        )
      );
      if (m) return clampDay(parseNum(m[1]));
      m = line.match(
        new RegExp('([\\d.,]+[km]?)\\s*\\+?\\s*' + postWord + '\\s*(this\\s*week|week|semana)', 'i')
      );
      if (m) {
        const n = parseNum(m[1]);
        if (Number.isFinite(n)) return clampDay(Math.max(1, Math.round(n / 7)));
      }
      m = line.match(
        new RegExp('([\\d.,]+[km]?)\\s*\\+?\\s*' + postWord + '\\s*(this\\s*month|month|mes)', 'i')
      );
      if (m) {
        const n = parseNum(m[1]);
        if (Number.isFinite(n)) return clampDay(Math.max(1, Math.round(n / 30)));
      }
      m = line.match(
        new RegExp(
          '([\\d.,]+[km]?)\\s*\\+?\\s*(new\\s*)?' + postWord + '\\s*(today|hoy|heute|oggi|aujourd\'hui)',
          'i'
        )
      );
      if (m) return clampDay(parseNum(m[1]));
      m = line.match(
        new RegExp(
          '(today|hoy|heute|oggi|aujourd\'hui)[^\\d]{0,24}([\\d.,]+[km]?)\\s*\\+?\\s*(new\\s*)?' + postWord,
          'i'
        )
      );
      if (m) return clampDay(parseNum(m[2]));
      return null;
    };
    const strongVals = [];
    const weakVals = [];
    for (const rawLine of lines) {
      const v = extractFromLine(rawLine);
      if (v == null) continue;
      if (strongDayHint.test(rawLine)) strongVals.push(v);
      else weakVals.push(v);
    }
    if (strongVals.length) return strongVals[strongVals.length - 1];
    if (weakVals.length) return weakVals[weakVals.length - 1];
    const t = text.toLowerCase().replace(/\s+/g, ' ');
    let m = t.match(
      new RegExp(
        '([\\d.,]+[km]?)\\s*\\+?\\s*(new\\s*)?' + postWord + '\\s*(today|hoy|heute|oggi|aujourd\'hui)',
        'i'
      )
    );
    if (m) {
      const v = clampDay(parseNum(m[1]));
      if (v != null) return v;
    }
    if (/very\s*active|muy\s*activo|super\s*activo|très\s*actif|sehr\s*aktiv/.test(t)) return 15;
    const fb = scoreActivityDiscoverFallback(t);
    if (fb != null) return clampDay(fb);
    return null;
  }
  function rowBlobForLink(link) {
    if (!link) return '';
    const blobs = [];
    const pushIf = (tx) => {
      const s = String(tx || '')
        .replace(/\u00a0/g, ' ')
        .trim();
      if (s.length >= 28 && s.length < 14000) blobs.push(s);
    };
    try {
      const art = link.closest && link.closest('[role="article"]');
      if (art) pushIf(art.innerText || art.textContent);
      let el = link;
      for (let d = 0; d < 14 && el; d++) {
        pushIf(el.innerText || el.textContent);
        if (art && el === art) break;
        el = el.parentElement;
      }
    } catch (e0) {}
    const activityNeedle =
      /(posts?|publicaciones?|publica[cç][oõ]es|publicações|beitr[aä]ge)\s*(per|por|par|\/|al|a)?\s*(day|d[ií]a|jour|daily|diari)|publicaciones?\s+al\s+d|posts?\s*\/\s*(day|d[ií]a)|posts?\s+a\s+day/i;
    let best = '';
    const ranked = blobs.filter((b) => activityNeedle.test(b));
    if (ranked.length) best = ranked.reduce((a, b) => (a.length <= b.length ? a : b));
    else if (blobs.length) best = blobs.reduce((a, b) => (a.length >= b.length ? a : b));
    try {
      const aria = (link.getAttribute && link.getAttribute('aria-label')) || '';
      if (aria && aria.length > 12) {
        const merged = (best + '\n' + aria.trim()).trim();
        if (merged.length > best.length) best = merged;
      }
    } catch (e1) {}
    return best.slice(0, 5500);
  }
  function normalizeFbHtml(s) {
    return String(s || '')
      .replace(/\\u002f/gi, '/')
      .replace(/\\\//g, '/')
      .replace(/&amp;/gi, '&')
      .replace(/&quot;/gi, '"');
  }
  function gatherHrefGroupTargets() {
    const out = [];
    const seenEl = new Set();
    function addEl(el) {
      if (!el || typeof el.getAttribute !== 'function' || seenEl.has(el)) return;
      seenEl.add(el);
      const href = String(el.href != null ? el.href : el.getAttribute('href') || '').trim();
      if (!href) return;
      if (!/\/groups\/|facebook\.com\/groups|fb\.com\/groups/i.test(href)) return;
      out.push(el);
    }
    const sels = [
      'a[href*="/groups/"]',
      'a[href*="facebook.com/groups/"]',
      'a[href*="fb.com/groups/"]',
      '[role="link"][href*="/groups/"]',
      '[role="link"][href*="facebook.com/groups/"]',
      '[role="link"][href*="fb.com/groups/"]',
      'area[href*="/groups/"]'
    ];
    sels.forEach((s) => {
      try {
        document.querySelectorAll(s).forEach(addEl);
      } catch (e) {}
    });
    try {
      document.querySelectorAll('[href*="groups/"]').forEach(addEl);
    } catch (e2) {}
    try {
      document.querySelectorAll('[href*="facebook.com/groups/"],[href*="fb.com/groups/"]').forEach(addEl);
    } catch (e3) {}
    return out;
  }
  function appendOneGroup(id, link) {
    if (!id || EXCLUDED.has(id.toLowerCase()) || /^\d{0,3}$/.test(id) || seen.has(id)) return;
    const blob = link ? rowBlobForLink(link) : '';
    let score = scoreActivity(blob);
    const low = blob.toLowerCase();
    const hasPrivateHint = /(private\s+group|grupo\s+privado|grupo\s+cerrado|closed\s+group|private\s+community|geschlossene\s+gruppe|groupe\s+priv[eé])/i.test(low);
    if (hasPrivateHint) return;
    if (link && isAlreadyMember(low)) return;
    if (MIN > 0 && Number.isFinite(Number(score)) && Number(score) < MIN) return;
    function cleanName(raw, groupId) {
      let n = String(raw || '').trim();
      n = n.replace(/^profile photo of\s+/i, '').trim();
      n = n.replace(/^foto de perfil de\s+/i, '').trim();
      n = n.replace(/\s+/g, ' ').trim();
      const bad = !n || n.length < 2 || /^profile photo$/i.test(n);
      if (bad) n = String(groupId || '').replace(/[-_]/g, ' ');
      return n;
    }
    const aria = link && link.getAttribute ? link.getAttribute('aria-label') : '';
    const txt = link && link.textContent ? link.textContent.trim() : '';
    let name = cleanName(aria || txt || '', id);
    if (/^profile photo of\b/i.test(String(aria || ''))) {
      const probable = id.replace(/[-_]/g, ' ').trim();
      if (probable.length > 2) name = probable;
    }
    const nameNorm = String(name).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ' ');
    const blobNorm = low.normalize('NFD').replace(/[\u0300-\u036f]/g, ' ');
    const candidateText = (nameNorm + ' ' + blobNorm);
    if (qTokens.length && !onFederatedSearch) {
      const hitsInName = qTokens.filter((tk) => nameNorm.includes(tk)).length;
      const hitsAll = qTokens.filter((tk) => candidateText.includes(tk)).length;
      const phrase = qNorm.length >= 4 && candidateText.includes(qNorm);
      if (!phrase && hitsInName === 0 && hitsAll < 1) return;
    }
    seen.add(id);
    results.push({
      url: 'https://www.facebook.com/groups/' + id,
      name: name.substring(0, 80).trim(),
      selected: true,
      activityEst: Number.isFinite(Number(score)) ? Math.round(Number(score)) : null
    });
  }
  try {
    document.querySelectorAll('a').forEach((a) => {
      const href = String(a.href != null ? a.href : a.getAttribute('href') || '').trim();
      const id = extractGroupIdFromHref(href);
      if (!id) return;
      appendOneGroup(id, a);
    });
  } catch (eA) {}
  gatherHrefGroupTargets().forEach((link) => {
    const href = String(link.href != null ? link.href : link.getAttribute('href') || '').trim();
    const id = extractGroupIdFromHref(href);
    if (!id) return;
    appendOneGroup(id, link);
  });
  try {
    document.querySelectorAll('[role="article"], [role="listitem"]').forEach((node) => {
      const htmlArt = normalizeFbHtml(node.innerHTML || '');
      const artRe = /\/groups\/([^/?"'<>\\s#&]{3,120})/gi;
      let am;
      while ((am = artRe.exec(htmlArt)) !== null) {
        const gid = am[1];
        if (EXCLUDED.has(gid.toLowerCase()) || seen.has(gid) || /^\d{0,3}$/.test(gid)) continue;
        let linkHit = null;
        try {
          node.querySelectorAll('a').forEach((a) => {
            if (linkHit) return;
            const hh = String(a.getAttribute('href') || a.href || '');
            if (hh.indexOf('/groups/' + gid) !== -1) linkHit = a;
          });
        } catch (e1) {}
        appendOneGroup(gid, linkHit);
      }
    });
  } catch (eArt) {}
  const scanRoot = document.querySelector('[role="main"]') || document.body;
  let html = normalizeFbHtml(scanRoot ? scanRoot.innerHTML : '');
  const slashHits = (html.match(/\/groups\//g) || []).length;
  if (slashHits < 4) {
    html = normalizeFbHtml(String(document.documentElement && document.documentElement.innerHTML || '').slice(0, 2800000));
  }
  const idRe = /\/groups\/([^/?"'<>\\s#&]{3,120})/gi;
  let xm;
  while ((xm = idRe.exec(html)) !== null) {
    const gid = xm[1];
    if (EXCLUDED.has(gid.toLowerCase()) || seen.has(gid) || /^\d{0,3}$/.test(gid)) continue;
    let linkHit = null;
    const anchors = document.querySelectorAll('a[href*="/groups/"],a[href*="facebook.com/groups/"],a[href*="fb.com/groups/"]');
    for (let ai = 0; ai < anchors.length; ai++) {
      const hh = String(anchors[ai].getAttribute('href') || anchors[ai].href || '');
      if (hh.indexOf('/groups/' + gid) !== -1) {
        linkHit = anchors[ai];
        break;
      }
    }
    appendOneGroup(gid, linkHit);
  }
  try {
    const seenNum = new Set();
    let scAdded = 0;
    const scriptNodes = document.querySelectorAll('script:not([src])');
    for (let si = 0; si < scriptNodes.length && scAdded < 100; si++) {
      const raw = scriptNodes[si].textContent || '';
      if (raw.length < 80 || raw.length > 600000) continue;
      if (!/group|Group/i.test(raw)) continue;
      const norm = normalizeFbHtml(raw);
      const rNum = /\/groups\/(\d{8,})\b/g;
      let m;
      while ((m = rNum.exec(norm)) !== null && scAdded < 100) {
        const gid = m[1];
        if (seenNum.has(gid) || seen.has(gid) || EXCLUDED.has(gid.toLowerCase())) continue;
        seenNum.add(gid);
        const before = seen.size;
        appendOneGroup(gid, null);
        if (seen.size > before) scAdded++;
      }
      const rQ = /"group_id"\s*:\s*"?(\d{8,})"?/gi;
      while ((m = rQ.exec(norm)) !== null && scAdded < 100) {
        const gid = m[1];
        if (seenNum.has(gid) || seen.has(gid) || EXCLUDED.has(gid.toLowerCase())) continue;
        seenNum.add(gid);
        const before = seen.size;
        appendOneGroup(gid, null);
        if (seen.size > before) scAdded++;
      }
    }
  } catch (eScr) {}
  results.sort((a, b) => String(a.name || '').localeCompare(String(b.name || '')));
  return results;
}

function resetScanBtn(btn, icon, txt) {
  btn.disabled = false;
  icon.textContent = '🔍';
  txt.textContent = t('btn_scan');
}
function setLog(el, cls, msg) { el.className = 'scan-log ' + cls; el.textContent = msg; }

function mergeRunGroupsFromRunState(runGroups) {
  if (!Array.isArray(runGroups) || !runGroups.length) return;
  const norm = (g) => ({
    name: g.name || '',
    url: g.url || '',
    selected: g.selected !== false,
    canPost: typeof g.canPost === 'boolean' ? g.canPost : null,
    postabilityCheckedAt: g.postabilityCheckedAt || null,
    postStatus: g.postStatus || null,
    postError: g.postError || '',
    pendingPostsCount: Number.isFinite(g.pendingPostsCount) ? g.pendingPostsCount : 0,
    moderationStats: g.moderationStats || { pending: 0, approved: 0, rejected: 0, deleted: 0 },
    postsPerDayActivity: Number.isFinite(Number(g.postsPerDayActivity)) ? Math.round(Number(g.postsPerDayActivity)) : null,
    postsPerDayMemberLimit: Number.isFinite(Number(g.postsPerDayMemberLimit)) ? Math.round(Number(g.postsPerDayMemberLimit)) : null,
    postsPerDayUnlimited: !!g.postsPerDayUnlimited,
    isProfileTimelineSlot: !!g.isProfileTimelineSlot,
  });
  if (!groups.length) {
    groups = runGroups.map(norm);
    saveGroups();
    renderGroups();
    return;
  }
  const byUrl = new Map(groups.map((g) => [g.url, g]));
  let changed = false;
  runGroups.forEach((rg) => {
    if (!rg?.url) return;
    if (!byUrl.has(rg.url)) {
      groups.push(norm(rg));
      changed = true;
    }
  });
  if (changed) {
    saveGroups();
    renderGroups();
  }
}

function restorePosterSessionOnLoad() {
  chrome.storage.local.get([POSTER_RUN_STATE_KEY, 'posterRunning', 'posterConfig', 'posterResults'], (d) => {
    const saved = d[POSTER_RUN_STATE_KEY];
    const cfg = (saved && saved.config) ? saved.config : (d.posterConfig || null);
    if (cfg) {
      posterImageLayersCache = null;
      restoreComposeFromPosterConfig(cfg);
    }

    if (!saved || !saved.config) return;

    const runGroups = Array.isArray(saved.config.groups) ? saved.config.groups : [];
    mergeRunGroupsFromRunState(runGroups);

    const results = d.posterResults || saved.results || [];
    const total = runGroups.length || results.length || 1;
    const meta = {
      postIndex: typeof saved.postIndex === 'number' ? saved.postIndex : 0,
      totalPosts: Array.isArray(saved.config.posts) ? saved.config.posts.length : 1,
    };
    const hint = String(saved.resumeHint || '');
    const futureAt = typeof saved.plannedStartAt === 'number' && saved.plannedStartAt > Date.now();

    if (d.posterRunning) {
      setRunning(true);
      if (runGroups.length) initSteps(runGroups);
      updateProgress(results, total, 0, meta);
      goTab('progress');
      return;
    }

    if (futureAt && (hint === 'scheduled_start' || hint === 'daily_limit')) {
      if (runGroups.length) initSteps(runGroups);
      updateProgress(results, total, 0, meta);
      updateGroupSchedulePostingHint();
      updateResumeProgrammedPostingUI();
      const when = new Date(saved.plannedStartAt).toLocaleString();
      const msg = hint === 'daily_limit'
        ? ((t('prog_stopped_daily_limit') || 'Daily limit') + ' · ' + when)
        : (tfmt('group_schedule_posting_hint_active', { when }) || ('Scheduled · ' + when));
      const pl = document.getElementById('progLabel');
      if (pl) pl.textContent = msg;
      const rb = document.getElementById('runBarText');
      if (rb) rb.textContent = msg;
      goTab('progress');
      return;
    }

    if (hint === 'user_pause' || hint === 'post_failure_pause') {
      if (runGroups.length) initSteps(runGroups);
      updateProgress(results, total, 0, meta);
      if (hint === 'user_pause') {
        setUserPaused(true);
        const pausedMsg = t('prog_paused_by_user') || 'Paused';
        const pl = document.getElementById('progLabel');
        if (pl) pl.textContent = pausedMsg;
        const rb = document.getElementById('runBarText');
        if (rb) rb.textContent = pausedMsg;
      } else if (saved.stopReason === 'post_failure_pause' && results.length) {
        const last = results[results.length - 1];
        showFailurePauseBanner({
          groupName: last.name || '',
          groupUrl: last.url || '',
          error: last.error || '',
        });
      }
      goTab('progress');
      updateResumeProgrammedPostingUI();
    }
  });
}

// Groups CRUD
function loadGroups(done) {
  chrome.storage.local.get('fbGroups', d => {
    groups = (d.fbGroups || []).map(g => ({
      ...g,
      canPost: typeof g.canPost === 'boolean' ? g.canPost : null,
      postabilityCheckedAt: g.postabilityCheckedAt || null,
      postStatus: g.postStatus || null, // 'ok'|'err'|'pending'
      postError: g.postError || '',
      pendingPostsCount: Number.isFinite(g.pendingPostsCount) ? g.pendingPostsCount : 0,
      moderationStats: g.moderationStats || { pending: 0, approved: 0, rejected: 0, deleted: 0 },
      postsPerDayActivity: Number.isFinite(Number(g.postsPerDayActivity)) ? Math.round(Number(g.postsPerDayActivity)) : null,
      postsPerDayMemberLimit: Number.isFinite(Number(g.postsPerDayMemberLimit)) ? Math.round(Number(g.postsPerDayMemberLimit)) : null,
      postsPerDayUnlimited: !!g.postsPerDayUnlimited
    }));
    renderGroups();
    if (typeof done === 'function') done();
  });
}
function saveGroups() { chrome.storage.local.set({ fbGroups: groups }); }
function loadGroupSets() {
  chrome.storage.local.get(GROUP_SET_KEY, d => renderGroupSets(d[GROUP_SET_KEY] || []));
}
function renderGroupSets(setsArg) {
  const select = document.getElementById('groupSetSelect');
  if (!select) return;
  const sets = Array.isArray(setsArg) ? setsArg : [];
  select.innerHTML = '';
  const opt0 = document.createElement('option');
  opt0.value = '';
  opt0.textContent = typeof t === 'function' ? t('group_sets_ph') : 'Saved lists';
  select.appendChild(opt0);
  sets.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.name;
    opt.textContent = s.name + ' (' + (s.urls?.length || 0) + ')';
    select.appendChild(opt);
  });
}
function saveCurrentGroupSet() {
  const inp = document.getElementById('groupSetName');
  const name = (inp?.value || '').trim();
  if (!name) { alert(t('alert_list_name_required')); return; }
  const urls = groups.filter(g => g.selected).map(g => g.url);
  if (!urls.length) { alert(t('alert_list_select_groups')); return; }
  chrome.storage.local.get(GROUP_SET_KEY, d => {
    const sets = d[GROUP_SET_KEY] || [];
    const next = sets.filter(s => s.name !== name);
    next.unshift({ name, urls, updatedAt: Date.now() });
    chrome.storage.local.set({ [GROUP_SET_KEY]: next }, () => {
      renderGroupSets(next);
      if (inp) inp.value = '';
    });
  });
}
function loadSelectedGroupSet() {
  const select = document.getElementById('groupSetSelect');
  const name = select?.value;
  if (!name) return;
  chrome.storage.local.get(GROUP_SET_KEY, d => {
    const sets = d[GROUP_SET_KEY] || [];
    const set = sets.find(s => s.name === name);
    if (!set) return;
    const wanted = new Set(set.urls || []);
    groups.forEach(g => { g.selected = wanted.has(g.url); });
    saveGroups();
    renderGroups();
  });
}
function deleteSelectedGroupSet() {
  const select = document.getElementById('groupSetSelect');
  const name = select?.value;
  if (!name) return;
  if (!confirm(tfmt('confirm_delete_list', { name }))) return;
  chrome.storage.local.get(GROUP_SET_KEY, d => {
    const sets = d[GROUP_SET_KEY] || [];
    const next = sets.filter(s => s.name !== name);
    chrome.storage.local.set({ [GROUP_SET_KEY]: next }, () => renderGroupSets(next));
  });
}

function loadTextPresets() {
  chrome.storage.local.get(TEXT_PRESET_KEY, d => renderTextPresets(d[TEXT_PRESET_KEY] || []));
}

function postIdxFromBlock(el) {
  const block = el?.closest('.post-block');
  if (!block) return -1;
  return [...document.querySelectorAll('#postsContainer .post-block')].indexOf(block);
}

function renderTextPresets(presetsArg) {
  const selects = document.querySelectorAll('#postsContainer .text-preset-select');
  if (!selects.length) return;
  const presets = Array.isArray(presetsArg) ? presetsArg : [];
  const ph = typeof t === 'function' ? t('text_presets_ph') : 'Saved texts';
  selects.forEach(select => {
    const cur = select.value;
    select.innerHTML = '';
    const opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = ph;
    select.appendChild(opt0);
    presets.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.name;
      opt.textContent = p.name;
      select.appendChild(opt);
    });
    if (cur && presets.some(p => p.name === cur)) select.value = cur;
  });
}

function saveTextPresetForPost(postIdx) {
  const block = getPostBlockByIdx(postIdx);
  const nameInp = block?.querySelector('.text-preset-name');
  const ta = block?.querySelector('.post-editor');
  const name = (nameInp?.value || '').trim();
  const text = (ta?.value || '').trim();
  if (!name) { alert(t('alert_preset_name_required')); return; }
  if (!text) { alert(t('alert_preset_no_text')); return; }
  chrome.storage.local.get(TEXT_PRESET_KEY, d => {
    const presets = d[TEXT_PRESET_KEY] || [];
    const next = presets.filter(p => p.name !== name);
    next.unshift({ name, text: ta.value || '', updatedAt: Date.now() });
    chrome.storage.local.set({ [TEXT_PRESET_KEY]: next }, () => {
      renderTextPresets(next);
      const select = block?.querySelector('.text-preset-select');
      if (select) select.value = name;
      if (nameInp) nameInp.value = '';
    });
  });
}

function loadTextPresetForPost(postIdx) {
  const block = getPostBlockByIdx(postIdx);
  const select = block?.querySelector('.text-preset-select');
  const ta = block?.querySelector('.post-editor');
  const name = select?.value;
  if (!name || !ta) return;
  chrome.storage.local.get(TEXT_PRESET_KEY, d => {
    const presets = d[TEXT_PRESET_KEY] || [];
    const preset = presets.find(p => p.name === name);
    if (!preset) return;
    ta.value = preset.text || '';
    ta.focus();
    updateCC();
    const wrap = block.querySelector('.sp-preview-wrap');
    if (wrap?.classList.contains('sp-preview-open')) refreshSpPreviewForPost(postIdx);
  });
}

function deleteTextPresetForPost(postIdx) {
  const block = getPostBlockByIdx(postIdx);
  const select = block?.querySelector('.text-preset-select');
  const name = select?.value;
  if (!name) return;
  if (!confirm(tfmt('confirm_delete_preset', { name }))) return;
  chrome.storage.local.get(TEXT_PRESET_KEY, d => {
    const presets = d[TEXT_PRESET_KEY] || [];
    const next = presets.filter(p => p.name !== name);
    chrome.storage.local.set({ [TEXT_PRESET_KEY]: next }, () => renderTextPresets(next));
  });
}

async function runLeaveGroupsLoop(targets, btn, logEl) {
  if (!btn || !logEl) return;
  if (!targets.length) return;
  if (!confirm(tfmt('log_leave_confirm', { total: targets.length }))) return;
  btn.disabled = true;
  try {
    let ok = 0;
    let fail = 0;
    for (let i = 0; i < targets.length; i++) {
      const g = targets[i];
      setLog(logEl, 'inf', tfmt('log_leave_item', { current: i + 1, total: targets.length, name: g.name }));
      const tab = await createTabAndWait(g.url, automationFbTabActive());
      await sleep(3500);
      const res = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: leaveGroupInPage
      });
      const left = !!res?.[0]?.result?.left;
      if (left) {
        ok++;
        groups = groups.filter(x => x.url !== g.url);
        saveGroups();
        renderGroups();
      } else {
        fail++;
      }
      try { chrome.tabs.remove(tab.id); } catch (e) {}
      await sleep(1200);
    }
    setLog(logEl, 'ok', tfmt('log_leave_done', { ok, fail }));
  } catch (e) {
    setLog(logEl, 'err', t('log_leave_error') + ' ' + (e.message || t('unknown')));
  } finally {
    btn.disabled = false;
    await focusAppTab();
  }
}

async function leaveUnpostableGroups() {
  const btn = document.getElementById('btnLeaveNoPostPermission');
  const logEl = document.getElementById('scanLog');
  const targets = groups.filter(g => g.canPost === false);
  if (!targets.length) { setLog(logEl, 'inf', t('log_leave_none')); return; }
  await runLeaveGroupsLoop(targets, btn, logEl);
}

async function leaveSelectedGroups() {
  const btn = document.getElementById('btnLeaveSelectedGroups');
  const logEl = document.getElementById('scanLog');
  const targets = groups.filter(g => g.selected);
  if (!targets.length) { setLog(logEl, 'err', t('log_leave_selected_none')); return; }
  await runLeaveGroupsLoop(targets, btn, logEl);
}

async function leaveGroupInPage() {
  const wait = (ms) => new Promise(r => setTimeout(r, ms));
  const words = ['joined', 'miembro', 'member', 'unido'];
  const leaveWords = ['leave group', 'abandonar grupo', 'salir del grupo', 'salir de este grupo'];
  const confirmWords = ['leave', 'abandonar', 'salir', 'confirm'];
  const joinWords = ['join group', 'unirte', 'unirse', 'join'];

  const visible = () => Array.from(document.querySelectorAll('[role=button],button,[role=menuitem]')).filter(el => el.offsetParent);
  const txt = (el) => ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
  const pick = (arr, dict) => arr.find(el => dict.some(w => txt(el).includes(w)));

  function isStillMember() {
    const buttons = visible();
    return !!pick(buttons, words) && !pick(buttons, joinWords);
  }

  async function confirmLeavePopup() {
    // Facebook often opens a dialog that requires a second explicit confirmation.
    for (let i = 0; i < 8; i++) {
      const dialogs = Array.from(document.querySelectorAll('[role="dialog"]')).filter(d => d.offsetParent);
      for (const d of dialogs) {
        const btns = Array.from(d.querySelectorAll('[role=button],button')).filter(b => b.offsetParent);
        // Prefer exact destructive wording first.
        const exact = btns.find(b => {
          const t = txt(b);
          return t.includes('leave group') || t.includes('abandonar grupo') || t.includes('salir del grupo');
        });
        if (exact) {
          exact.click();
          await wait(900);
          return true;
        }
        const generic = pick(btns, confirmWords);
        if (generic) {
          generic.click();
          await wait(900);
          return true;
        }
      }
      await wait(500);
    }
    return false;
  }

  for (let tries = 0; tries < 4; tries++) {
    const buttons = visible();
    const joinedBtn = pick(buttons, words);
    if (!joinedBtn) { await wait(1000); continue; }
    joinedBtn.click();
    await wait(900);
    const leaveBtn = pick(visible(), leaveWords);
    if (!leaveBtn) { await wait(900); continue; }
    leaveBtn.click();
    await wait(1100);
    await confirmLeavePopup();
    // Fallback for UIs where confirm appears as a regular button outside dialog.
    for (let k = 0; k < 2; k++) {
      const c = pick(visible(), confirmWords);
      if (c) { c.click(); await wait(800); }
    }
    await wait(1500);
    if (!isStillMember()) return { left: true };
  }
  return { left: false };
}

function addGroup() {
  const inp = document.getElementById('groupUrl');
  let url = inp.value.trim();
  if (!url) return;
  if (!url.startsWith('http')) url = 'https://' + url;
  if (!url.includes('facebook.com/groups/')) { alert(t('alert_group_url_invalid')); return; }
  const m = url.match(/groups\/([^/?#\s]+)/);
  if (!m) { alert(t('alert_group_id_failed')); return; }
  const cleanUrl = 'https://www.facebook.com/groups/' + m[1];
  if (groups.find(g => g.url === cleanUrl)) { alert(t('alert_group_duplicate')); return; }
  groups.push({
    url: cleanUrl,
    name: m[1].replace(/[-_]/g, ' '),
    selected: true,
    canPost: null,
    postabilityCheckedAt: null,
    pendingPostsCount: 0,
    ...defaultDailyPostFields()
  });
  saveGroups(); renderGroups(); inp.value = '';
}

function removeGroup(i) { groups.splice(i, 1); saveGroups(); renderGroups(); }
function toggleGroup(i) { groups[i].selected = !groups[i].selected; saveGroups(); }
function selectAll() { groups.forEach(g => g.selected = true); saveGroups(); renderGroups(); }
function deselectAll() { groups.forEach(g => g.selected = false); saveGroups(); renderGroups(); }
function clearAll() {
  if (!groups.length || !confirm(t('confirm_delete_all_groups'))) return;
  groups = []; saveGroups(); renderGroups();
}

function formatGroupDailyPostsUi(g) {
  if (g.postsPerDayUnlimited) return { text: t('group_daily_unlimited'), hint: t('group_daily_tooltip'), variant: 'unl' };
  if (Number.isFinite(g.postsPerDayMemberLimit) && g.postsPerDayMemberLimit >= 1) {
    return {
      text: tfmt('group_daily_member_limit', { n: g.postsPerDayMemberLimit }),
      hint: t('group_daily_tooltip'),
      variant: 'rule'
    };
  }
  if (Number.isFinite(g.postsPerDayActivity) && g.postsPerDayActivity >= 1) {
    return {
      text: tfmt('group_daily_activity_est', { n: Math.round(g.postsPerDayActivity) }),
      hint: t('group_daily_activity_tooltip'),
      variant: 'act'
    };
  }
  return { text: t('group_daily_unknown'), hint: t('group_daily_tooltip'), variant: 'na' };
}

function renderGroups() {
  const list = document.getElementById('groupsList');
  document.getElementById('groupCount').textContent = groups.length;
  if (!groups.length) {
    list.innerHTML = '<div class="empty-note">' + (typeof t === 'function' ? t('groups_empty') : 'No groups yet.') + '</div>';
    return;
  }
  list.innerHTML = '';
  groups.forEach((g, i) => {
    const item = document.createElement('div');
    item.className = 'group-item';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = g.selected;
    cb.addEventListener('change', () => toggleGroup(i));
    const info = document.createElement('div');
    info.className = 'group-info';
    const nameEl = document.createElement('div');
    nameEl.className = 'group-name';
    nameEl.textContent = g.name;
    const urlEl = document.createElement('div');
    urlEl.className = 'group-url-txt';
    urlEl.textContent = g.url;
    const meta = document.createElement('div');
    meta.className = 'group-meta';
    const b = document.createElement('span');
    const canPost = g.canPost;
    b.className = 'group-badge ' + (canPost === true ? 'ok' : canPost === false ? 'no' : 'unk');
    b.textContent = canPost === true
      ? t('group_badge_can_post')
      : canPost === false
        ? t('group_badge_no_permission')
        : t('group_badge_unverified');
    b.style.cursor = 'pointer';
    b.title = 'Toggle can post / not verified';
    b.addEventListener('click', () => {
      const cur = groups[i]?.canPost;
      if (cur === true) groups[i].canPost = null;
      else groups[i].canPost = true;
      groups[i].postabilityCheckedAt = Date.now();
      saveGroups();
      renderGroups();
    });
    meta.appendChild(b);
    const dailyUi = formatGroupDailyPostsUi(g);
    const dailyBadge = document.createElement('span');
    dailyBadge.className = 'group-badge group-daily-badge group-daily-badge--' + dailyUi.variant;
    dailyBadge.textContent = dailyUi.text;
    dailyBadge.title = dailyUi.hint || '';
    meta.appendChild(dailyBadge);
    const postS = g.postStatus;
    if (postS === 'ok' || postS === 'err') {
      const pb = document.createElement('span');
      pb.className = 'group-post-badge ' + (postS === 'ok' ? 'ok' : 'err');
      pb.textContent = postS === 'ok' ? t('post_status_ok') : t('post_status_err');
      pb.title = postS === 'err' ? (g.postError || t('post_status_err')) : '';
      meta.appendChild(pb);
    }
    info.appendChild(nameEl);
    info.appendChild(urlEl);
    info.appendChild(meta);
    const delBtn = document.createElement('button');
    delBtn.className = 'icon-btn';
    delBtn.title = t('group_btn_remove_title');
    delBtn.textContent = 'x';
    delBtn.addEventListener('click', () => removeGroup(i));
    const goBtn = document.createElement('button');
    goBtn.className = 'btn btn-secondary btn-sm';
    goBtn.style.marginLeft = '6px';
    goBtn.textContent = t('group_btn_open');
    goBtn.addEventListener('click', () => chrome.tabs.create({ url: g.url, active: true }));
    item.appendChild(cb);
    item.appendChild(info);
    item.appendChild(goBtn);
    item.appendChild(delBtn);
    list.appendChild(item);
  });
  if (document.getElementById('tab-progress')?.classList.contains('active')) refreshProgressFlowGuide();
}

async function verifyGroupsPostability(scope) {
  const btnAll = document.getElementById('btnVerifyAllGroups');
  const btnNotVerified = document.getElementById('btnVerifyNotVerifiedGroups');
  const logEl = document.getElementById('scanLog');
  if (!groups.length) { setLog(logEl, 'err', t('log_groups_need_first')); return; }
  const targets = scope === 'not_verified'
    ? groups.map((g, i) => ({ g, i })).filter(({ g }) => g.canPost !== true && g.canPost !== false)
    : groups.map((g, i) => ({ g, i }));
  if (!targets.length) {
    setLog(logEl, 'inf', scope === 'not_verified' ? 'No not-verified groups to check.' : t('log_groups_need_first'));
    return;
  }
  if (btnAll) btnAll.disabled = true;
  if (btnNotVerified) btnNotVerified.disabled = true;
  setLog(logEl, 'inf', t('log_verify_start'));
  try {
    const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);
    if (!tabs.length) { setLog(logEl, 'err', t('open_fb_first')); return; }
    const fbTab = await pickBestFacebookTab(tabs);
    let okCount = 0;
    let failCount = 0;
    const nonMemberUrls = [];
    for (let k = 0; k < targets.length; k++) {
      const i = targets[k].i;
      const g = targets[k].g;
      setLog(logEl, 'inf', tfmt('log_verify_item', { current: k + 1, total: targets.length, name: g.name }));
      await openTabAndWait(fbTab.id, g.url, automationFbTabActive());
      await sleep(5200);
      const res = await chrome.scripting.executeScript({ target: { tabId: fbTab.id }, func: detectGroupPostabilityInPage });
      const result = res?.[0]?.result || {};
      const canPost = !!result.canPost;
      const isMember = typeof result.isMember === 'boolean' ? result.isMember : null;
      groups[i].canPost = canPost;
      groups[i].isMember = isMember;
      groups[i].membershipCheckedAt = Date.now();
      groups[i].postabilityCheckedAt = Date.now();
      if (canPost) okCount++; else failCount++;
      if (isMember === false && g?.url) nonMemberUrls.push(g.url);
      saveGroups();
      renderGroups();
    }
    setLog(logEl, 'ok', tfmt('log_verify_done', { ok: okCount, noperm: failCount }));
    const queueUrls = [...new Set(nonMemberUrls)];
    if (queueUrls.length) {
      const dailyMax = Math.max(1, Math.min(500, Math.floor(Number(document.getElementById('joinDailyMax')?.value) || 5)));
      const resumeHhmm = normalizeJoinResumeHhmm(document.getElementById('joinResumeTime')?.value);
      persistJoinUiPrefs();
      appendJoinQueueLog('inf', `Detected ${queueUrls.length} non-member groups. Sending to join queue...`);
      await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'startJoinQueue', urls: queueUrls, dailyMax, resumeHhmm }, (r) => {
          if (chrome.runtime.lastError || !r || !r.ok) {
            appendJoinQueueLog('err', 'Could not start join queue from verification.');
          } else {
            appendJoinQueueLog('ok', `Join queue started with ${queueUrls.length} non-member groups.`);
          }
          resolve();
        });
      });
    } else {
      appendJoinQueueLog('ok', 'All checked groups are already member groups.');
    }
  } catch (e) {
    setLog(logEl, 'err', t('log_verify_error') + ' ' + (e.message || t('unknown')));
  } finally {
    if (btnAll) btnAll.disabled = false;
    if (btnNotVerified) btnNotVerified.disabled = false;
    await focusAppTab();
  }
}

async function checkModerationForAllGroups() {
  const logEl = document.getElementById('scanLog');
  if (!groups.length) { setLog(logEl, 'err', t('log_groups_need_first')); return; }
  const mode = document.getElementById('moderationCheckMode')?.value === 'deep' ? 'deep' : 'fast';
  const deep = mode === 'deep';
  const idxs = groups.map((_, i) => i);
  const btn = document.getElementById('btnCheckModeration');
  if (!btn) return;
  moderationCheckRunning = true;
  moderationCheckAborted = false;
  btn.disabled = false;
  btn.classList.add('btn-verify--stop-mode');
  btn.textContent = t('btn_stop_moderation');
  refreshPremiumButtons();
  setLog(logEl, 'inf', t('log_moderation_start') + ' [' + mode.toUpperCase() + ']');
  try {
    const tabs = await qTabs(FACEBOOK_TAB_URL_PATTERNS);
    if (!tabs.length) { setLog(logEl, 'err', t('open_fb_first')); return; }
    const fbTab = await pickBestFacebookTab(tabs);
    const tabActive = automationFbTabActive();
    const modAbort = () => moderationCheckAborted;
    let okCount = 0;
    let failCount = 0;
    for (let k = 0; k < idxs.length; k++) {
      if (moderationCheckAborted) {
        setLog(logEl, 'inf', t('log_moderation_stopped'));
        break;
      }
      const i = idxs[k];
      const g = groups[i];
      setLog(logEl, 'inf', tfmt('log_moderation_item', { current: k + 1, total: idxs.length, name: g.name }));
      const canPost = typeof g.canPost === 'boolean' ? g.canPost : null;
      const pendingUrl = toPendingContentUrl(g.url);
      const pendingRes = await readPendingStatsAt(fbTab.id, pendingUrl, deep ? 2 : 1, tabActive, modAbort);
      if (moderationCheckAborted) {
        setLog(logEl, 'inf', t('log_moderation_stopped'));
        break;
      }
      const pendingFromPage = Number(pendingRes?.pendingPostsCount || 0);
      const statsFromPending = pendingRes?.moderationStats || { pending: 0, approved: 0, rejected: 0, deleted: 0 };
      const pendingMerged = Math.max(pendingFromPage, Number(statsFromPending.pending || 0));

      const postedCount = await readContentCountAt(fbTab.id, toPostedContentUrl(g.url), 'approved', deep ? 2 : 1, tabActive, modAbort);
      if (moderationCheckAborted) {
        setLog(logEl, 'inf', t('log_moderation_stopped'));
        break;
      }
      const declinedCount = await readContentCountAt(fbTab.id, toDeclinedContentUrl(g.url), 'rejected', deep ? 2 : 1, tabActive, modAbort);
      if (moderationCheckAborted) {
        setLog(logEl, 'inf', t('log_moderation_stopped'));
        break;
      }
      const removedCount = await readContentCountAt(fbTab.id, toRemovedContentUrl(g.url), 'deleted', deep ? 2 : 1, tabActive, modAbort);
      if (moderationCheckAborted) {
        setLog(logEl, 'inf', t('log_moderation_stopped'));
        break;
      }

      const moderationStats = {
        pending: pendingMerged,
        approved: Number(postedCount) || 0,
        rejected: Number(declinedCount) || 0,
        deleted: Number(removedCount) || 0
      };
      groups[i].canPost = canPost;
      groups[i].pendingPostsCount = moderationStats.pending;
      groups[i].moderationStats = moderationStats;
      groups[i].postabilityCheckedAt = Date.now();
      if (canPost === true) okCount++;
      else if (canPost === false) failCount++;
      saveGroups();
      renderGroups();
    }
    if (!moderationCheckAborted) {
      setLog(logEl, 'ok', tfmt('log_moderation_done', { ok: okCount, noperm: failCount }));
    }
  } catch (e) {
    setLog(logEl, 'err', t('log_moderation_error') + ' ' + (e.message || t('unknown')));
  } finally {
    moderationCheckRunning = false;
    moderationCheckAborted = false;
    if (btn) {
      btn.classList.remove('btn-verify--stop-mode');
      btn.textContent = t('btn_check_moderation');
    }
    refreshPremiumButtons();
    await focusAppTab();
  }
}

function toPendingContentUrl(groupUrl) {
  const m = String(groupUrl || '').match(/facebook\.com\/groups\/([^/?#\s]+)/i);
  if (!m) return groupUrl;
  return 'https://www.facebook.com/groups/' + m[1] + '/my_pending_content/';
}
function toPostedContentUrl(groupUrl) {
  const m = String(groupUrl || '').match(/facebook\.com\/groups\/([^/?#\s]+)/i);
  if (!m) return groupUrl;
  return 'https://www.facebook.com/groups/' + m[1] + '/my_posted_content';
}
function toDeclinedContentUrl(groupUrl) {
  const m = String(groupUrl || '').match(/facebook\.com\/groups\/([^/?#\s]+)/i);
  if (!m) return groupUrl;
  return 'https://www.facebook.com/groups/' + m[1] + '/my_declined_content';
}
function toRemovedContentUrl(groupUrl) {
  const m = String(groupUrl || '').match(/facebook\.com\/groups\/([^/?#\s]+)/i);
  if (!m) return groupUrl;
  return 'https://www.facebook.com/groups/' + m[1] + '/my_removed_content';
}

async function readContentCountAt(tabId, url, mode, attempts, tabActive = true, abortPoll = null) {
  const ap = typeof abortPoll === 'function' ? abortPoll : null;
  let max = 0;
  const tries = Math.max(1, Number(attempts || 1));
  const openOpts = ap ? { abortPoll: ap } : undefined;
  for (let attempt = 0; attempt < tries; attempt++) {
    if (ap && ap()) return null;
    await openTabAndWait(tabId, url, tabActive, openOpts);
    if (ap && ap()) return null;
    await sleepAbortable(1200 + attempt * 400, ap);
    if (ap && ap()) return null;
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => window.scrollTo(0, Math.max(document.body.scrollHeight, document.documentElement.scrollHeight))
    });
    await sleepAbortable(500 + attempt * 200, ap);
    if (ap && ap()) return null;
    const res = await chrome.scripting.executeScript({ target: { tabId }, func: detectContentPageCount, args: [mode || ''] });
    const count = Number(res?.[0]?.result?.count || 0);
    if (count > max) max = count;
    if (max > 0 && tries === 1) break;
  }
  return max;
}

async function readPendingStatsAt(tabId, url, attempts, tabActive = true, abortPoll = null) {
  const ap = typeof abortPoll === 'function' ? abortPoll : null;
  let best = { pendingPostsCount: 0, moderationStats: { pending: 0, approved: 0, rejected: 0, deleted: 0 } };
  const tries = Math.max(1, Number(attempts || 1));
  const openOpts = ap ? { abortPoll: ap } : undefined;
  for (let i = 0; i < tries; i++) {
    if (ap && ap()) return null;
    await openTabAndWait(tabId, url, tabActive, openOpts);
    if (ap && ap()) return null;
    await sleepAbortable(1200 + i * 400, ap);
    if (ap && ap()) return null;
    const res = await chrome.scripting.executeScript({ target: { tabId }, func: detectPendingPostsInPendingPage });
    const next = res?.[0]?.result || {};
    const nextPending = Number(next.pendingPostsCount || 0);
    if (nextPending >= Number(best.pendingPostsCount || 0)) best = next;
    if (nextPending > 0 && tries === 1) break;
  }
  return best;
}

function extractCountByPatterns(text, regexes) {
  let max = 0;
  (regexes || []).forEach(re => {
    const m = String(text || '').match(re);
    if (m) max = Math.max(max, Number(m[1]) || 0);
  });
  return max;
}

function detectPendingPostsInPendingPage() {
  function countByPatterns(text, regexes) {
    let max = 0;
    (regexes || []).forEach(re => {
      const m = String(text || '').match(re);
      if (m) max = Math.max(max, Number(m[1]) || 0);
    });
    return max;
  }
  const body = (document.body?.innerText || '').toLowerCase();
  const noPendingHints = [
    'no tienes publicaciones pendientes',
    'no pending posts',
    'no pending content',
    'sin publicaciones pendientes'
  ];
  if (noPendingHints.some(h => body.includes(h))) return { pendingPostsCount: 0 };

  // Heuristic 1: pending list items usually render as articles/cards.
  const articleCount = document.querySelectorAll('div[role="article"], article').length;

  // Heuristic 2: one delete/remove action per pending item on this page.
  const btns = Array.from(document.querySelectorAll('[role=button],button,[role=menuitem]'));
  const delCount = btns.filter(b => {
    if (!b.offsetParent) return false;
    const t = ((b.textContent || '') + ' ' + (b.getAttribute('aria-label') || '')).toLowerCase();
    return t.includes('eliminar') || t.includes('delete') || t.includes('cancel request') || t.includes('cancelar solicitud');
  }).length;

  // Heuristic 3: explicit numeric label on page.
  const m = body.match(/(?:publicaciones pendientes|pending posts|pending content)\D{0,20}(\d{1,4})/i)
         || body.match(/(\d{1,4})\D{0,20}(?:publicaciones pendientes|pending posts|pending content)/i);
  const explicit = m ? (Number(m[1]) || 0) : 0;

  const pendingPostsCount = Math.max(explicit, articleCount, delCount);
  const moderationStats = {
    pending: pendingPostsCount,
    approved: countByPatterns(body, [/aprobad[oa]s?\D{0,25}(\d{1,4})/i, /approved\D{0,25}(\d{1,4})/i]),
    rejected: countByPatterns(body, [/rechazad[oa]s?\D{0,25}(\d{1,4})/i, /rejected\D{0,25}(\d{1,4})/i, /declined\D{0,25}(\d{1,4})/i]),
    deleted: countByPatterns(body, [/eliminad[oa]s?\D{0,25}(\d{1,4})/i, /deleted\D{0,25}(\d{1,4})/i, /removed\D{0,25}(\d{1,4})/i])
  };
  return { pendingPostsCount, moderationStats };
}

function detectContentPageCount(mode) {
  const body = (document.body?.innerText || '').toLowerCase();
  const emptyHints = [
    'no hay publicaciones',
    'no posts yet',
    'sin contenido publicado',
    'nothing to show'
  ];
  if (emptyHints.some(h => body.includes(h))) return { count: 0 };
  const modeMap = {
    approved: ['approved', 'posted', 'published', 'aprobad', 'publicad'],
    rejected: ['rejected', 'declined', 'rechazad', 'refused', 'denied'],
    deleted: ['deleted', 'removed', 'eliminad', 'borrad']
  };
  const words = modeMap[String(mode || '').toLowerCase()] || [];
  let explicit = 0;
  if (words.length) {
    for (const w of words) {
      const r1 = new RegExp(w + '\\D{0,25}(\\d{1,4})', 'i');
      const r2 = new RegExp('(\\d{1,4})\\D{0,25}' + w, 'i');
      const m1 = body.match(r1);
      const m2 = body.match(r2);
      explicit = Math.max(explicit, Number(m1?.[1] || 0), Number(m2?.[1] || 0));
    }
  }
  if (explicit > 0) return { count: explicit };
  const articleCount = document.querySelectorAll('div[role="article"], article').length;
  const rowCount = document.querySelectorAll('[role="feed"] > div, [data-pagelet*="FeedUnit"], [aria-posinset]').length;
  return { count: Math.max(articleCount, rowCount) };
}


/** Si modo silencioso está ON (por defecto), las automatizaciones no traen la pestaña FB al frente. */
function automationFbTabActive() {
  return document.getElementById('bgTabsEnabled')?.checked === false;
}

function openTabAndWait(tabId, url, active = true, opts) {
  const abortPoll = opts && typeof opts.abortPoll === 'function' ? opts.abortPoll : null;
  return new Promise(resolve => {
    chrome.tabs.update(tabId, { url, active: !!active }, () => {
      let settled = false;
      let pollId = null;
      let maxTimer = null;
      const done = () => {
        if (settled) return;
        settled = true;
        chrome.tabs.onUpdated.removeListener(onUpd);
        if (pollId != null) clearInterval(pollId);
        if (maxTimer != null) clearTimeout(maxTimer);
        resolve();
      };
      const onUpd = (id, info) => {
        if (id === tabId && info.status === 'complete') done();
      };
      chrome.tabs.onUpdated.addListener(onUpd);
      maxTimer = setTimeout(done, 12000);
      if (abortPoll) {
        pollId = setInterval(() => {
          try {
            if (abortPoll()) done();
          } catch (_) {}
        }, 60);
      }
    });
  });
}

// Editor — multi-post
function getPostEditors() {
  return document.querySelectorAll('#postsContainer .post-editor');
}

function getFocusedOrFirstEditor() {
  const ed = document.activeElement;
  if (ed && ed.classList && ed.classList.contains('post-editor')) return ed;
  const eds = [...getPostEditors()];
  return eds[lastFocusedPostIdx] || eds[0] || document.getElementById('editor');
}

function syncPostImagesSlots() {
  const n = document.querySelectorAll('#postsContainer .post-block').length;
  while (postImages.length < n) postImages.push([]);
  while (postImages.length > n) postImages.pop();
}

function insertEmoji(emoji) {
  const ta = getFocusedOrFirstEditor();
  const start = ta.selectionStart;
  const end   = ta.selectionEnd;
  ta.value = ta.value.slice(0, start) + emoji + ta.value.slice(end);
  ta.selectionStart = ta.selectionEnd = start + emoji.length;
  ta.focus();
  updateCC();
  const block = ta.closest('.post-block');
  const idx = block ? [...document.querySelectorAll('#postsContainer .post-block')].indexOf(block) : -1;
  if (idx >= 0 && block.querySelector('.sp-preview-wrap')?.classList.contains('sp-preview-open')) {
    refreshSpPreviewForPost(idx);
  }
}

function updateCC() {
  let n = 0;
  getPostEditors().forEach(ta => { n += ta.value.length; });
  const el = document.getElementById('charCount');
  if (el) {
    el.textContent = tfmt('char_count_label', { n });
    el.className = 'char-count' + (n > 60000 ? ' over' : n > 50000 ? ' warn' : '');
  }
}

function renderPostImages(postIdx) {
  syncPostImagesSlots();
  const p = document.querySelector(`.post-img-preview[data-post-idx="${postIdx}"]`);
  if (!p) return;
  p.innerHTML = '';
  (postImages[postIdx] || []).forEach((img, i) => {
    const wrap = document.createElement('div');
    wrap.className = 'img-thumb';
    const im = document.createElement('img');
    im.src = img.dataUrl;
    im.alt = img.name;
    const rm = document.createElement('button');
    rm.className = 'remove-img';
    rm.textContent = 'x';
    rm.addEventListener('click', () => removePostImage(postIdx, i));
    wrap.appendChild(im);
    wrap.appendChild(rm);
    p.appendChild(wrap);
  });
}

function queueComposeImagesPersist() {
  if (composeImagesPersistTimer) clearTimeout(composeImagesPersistTimer);
  composeImagesPersistTimer = setTimeout(() => {
    composeImagesPersistTimer = null;
    persistComposeImagesNow();
  }, 400);
}

function persistComposeImagesNow() {
  const posts = collectPostsForConfig();
  const hasAny = posts.some((p) => (p.images || []).some((img) => String(img.dataUrl || '').length > 80));
  if (!hasAny) return;
  const config = {
    posts,
    text: String(posts[0]?.text || ''),
    images: (posts[0]?.images || []).slice(0, MAX_IMAGES_PER_POST)
  };
  posterImageLayersCache = null;
  writePosterImagesSessionThenSlim(config, () => {});
}

function handlePostImages(ev, postIdx) {
  syncPostImagesSlots();
  const cap = MAX_IMAGES_PER_POST - (postImages[postIdx] || []).length;
  if (cap <= 0) { ev.target.value = ''; return; }
  Array.from(ev.target.files).slice(0, cap).forEach(f => {
    const r = new FileReader();
    r.onload = e => {
      postImages[postIdx].push({ dataUrl: e.target.result, name: f.name, type: f.type });
      renderPostImages(postIdx);
      queueRunningPostsSync();
      queueComposeImagesPersist();
    };
    r.readAsDataURL(f);
  });
  ev.target.value = '';
}

function removePostImage(postIdx, imgIdx) {
  postImages[postIdx].splice(imgIdx, 1);
  renderPostImages(postIdx);
  queueRunningPostsSync();
  queueComposeImagesPersist();
}

function collectPostsForConfig() {
  const eds = [...getPostEditors()];
  syncPostImagesSlots();
  return eds.map((ta, i) => ({
    text: ta.value || '',
    images: (postImages[i] || []).slice(0, MAX_IMAGES_PER_POST).map(img => ({
      dataUrl: img.dataUrl,
      name: img.name,
      type: img.type
    }))
  }));
}

function updatePostRemoveButtons() {
  const blocks = document.querySelectorAll('#postsContainer .post-block');
  const show = blocks.length > 1;
  blocks.forEach((block, i) => {
    const btn = block.querySelector('.btn-remove-post');
    if (btn) {
      btn.style.display = show ? '' : 'none';
      btn.dataset.removeIdx = String(i);
    }
    block.dataset.postIdx = String(i);
    block.querySelectorAll('[data-post-idx]').forEach(el => { el.dataset.postIdx = String(i); });
    block.querySelectorAll('[data-append-loop-idx]').forEach(el => { el.dataset.appendLoopIdx = String(i); });
  });
  getPostEditors().forEach((ta, i) => {
    if (i === 0) ta.id = 'editor';
    else ta.removeAttribute('id');
  });
}

function resetPostBlockSpintaxUI(block) {
  if (!block) return;
  const wrap = block.querySelector('.sp-preview-wrap');
  if (wrap) {
    wrap.style.display = 'none';
    wrap.classList.remove('sp-preview-open');
  }
  const hint = block.querySelector('.post-sp-hint');
  if (hint) hint.style.display = '';
  const btn = block.querySelector('.sp-preview-btn');
  if (btn) {
    btn.classList.remove('sp-highlight');
    btn.textContent = typeof t === 'function' ? t('spintax_preview_btn_alt') : '👁';
  }
  const body = block.querySelector('.sp-preview-body');
  if (body) body.innerHTML = '';
  const vl = block.querySelector('.sp-variant-label');
  if (vl) vl.textContent = '';
}

function addPostBlock() {
  const container = document.getElementById('postsContainer');
  const first = container.querySelector('.post-block');
  const clone = first.cloneNode(true);
  const idx = container.querySelectorAll('.post-block').length;
  const ta = clone.querySelector('.post-editor');
  ta.removeAttribute('id');
  ta.value = '';
  const presetName = clone.querySelector('.text-preset-name');
  if (presetName) presetName.value = '';
  clone.querySelector('.post-img-preview').innerHTML = '';
  clone.querySelectorAll('[data-post-idx]').forEach(el => { el.dataset.postIdx = String(idx); });
  clone.querySelectorAll('[data-append-loop-idx]').forEach(el => { el.dataset.appendLoopIdx = String(idx); });
  const rm = clone.querySelector('.btn-remove-post');
  if (rm) { rm.style.display = ''; rm.dataset.removeIdx = String(idx); }
  resetPostBlockSpintaxUI(clone);
  if (typeof t === 'function') {
    const spLbl = clone.querySelector('.sp-label');
    if (spLbl) spLbl.textContent = t('spintax_section_label') || 'Spintax';
    const title = clone.querySelector('.sp-preview-title');
    if (title) title.textContent = t('sp_preview_label') || '';
    clone.querySelectorAll('.post-sp-hint').forEach(el => { el.innerHTML = t('sp_hint') || ''; });
  }
  container.appendChild(clone);
  postImages.push([]);
  renderPostImages(idx);
  updatePostRemoveButtons();
  updateCC();
  loadTextPresets();
  if (document.getElementById('tab-progress')?.classList.contains('active')) refreshProgressFlowGuide();
  queueRunningPostsSync(true);
}

function removePostBlock(idx) {
  const blocks = document.querySelectorAll('#postsContainer .post-block');
  if (blocks.length <= 1) return;
  const block = blocks[idx];
  if (!block) return;
  block.remove();
  postImages.splice(idx, 1);
  updatePostRemoveButtons();
  lastFocusedPostIdx = Math.min(lastFocusedPostIdx, document.querySelectorAll('#postsContainer .post-block').length - 1);
  updateCC();
  if (document.getElementById('tab-progress')?.classList.contains('active')) refreshProgressFlowGuide();
  queueRunningPostsSync(true);
}

function queueRunningPostsSync(immediate) {
  if (!isRunning) return;
  if (runningPostsSyncTimer) {
    clearTimeout(runningPostsSyncTimer);
    runningPostsSyncTimer = null;
  }
  const delay = immediate ? 0 : 450;
  runningPostsSyncTimer = setTimeout(() => {
    runningPostsSyncTimer = null;
    syncRunningPostsToPosterConfig();
  }, delay);
}

function syncRunningPostsToPosterConfig() {
  if (!isRunning) return;
  const posts = collectPostsForConfig();
  chrome.storage.local.get(['posterConfig'], (d) => {
    const current = d && d.posterConfig;
    if (!current || typeof current !== 'object') return;
    const next = {
      ...current,
      posts,
      text: String((posts[0] && posts[0].text) || ''),
      images: (posts[0] && posts[0].images) ? posts[0].images : []
    };
    writePosterImagesSessionThenSlim(next, (sessionWrite) => {
      posterImageLayersCache = null;
      if (!sessionWrite || !sessionWrite.slim) return;
      if (!sessionWrite.ok) {
        try {
          console.warn('[Irishka] Persistencia de imágenes incompleta; texto de posts se guarda igual.', sessionWrite.error || '');
        } catch (e) {}
      }
      chrome.storage.local.set({ posterConfig: sessionWrite.slim });
    });
  });
}

function refreshTimerPresetLabels() {
  const ids = [
    ['timerPresetFastLbl', 'timer_preset_fast'],
    ['timerPresetNormalLbl', 'timer_preset_normal'],
    ['timerPresetSafeLbl', 'timer_preset_safe'],
    ['timerPresetCustomLbl', 'timer_preset_custom'],
    ['timerCustomMinutesLabel', 'timer_custom_minutes_hint'],
    ['timerWaitBetweenLabel', 'label_wait_between_minutes'],
  ];
  ids.forEach(([id, key]) => {
    const el = document.getElementById(id);
    if (el) el.textContent = t(key);
  });
}
window.refreshTimerPresetLabels = refreshTimerPresetLabels;

// Timer (solo minutos; mínimo TIMER_MIN_MINUTES entre grupos)
function initTimerSliders() {
  const slider = document.getElementById('timerSec');
  const varSlider = document.getElementById('timerVar');
  const customInput = document.getElementById('timerCustomMinutes');
  if (slider) {
    slider.min = String(TIMER_MIN_MINUTES);
    slider.max = String(TIMER_MAX_MINUTES);
    let v = +slider.value;
    if (!Number.isFinite(v)) v = TIMER_MIN_MINUTES;
    if (v < TIMER_MIN_MINUTES) slider.value = String(TIMER_MIN_MINUTES);
    else if (v > TIMER_MAX_MINUTES) slider.value = String(TIMER_MAX_MINUTES);
    const vv = Number(slider.value);
    if (customInput && TIMER_PRESET_MINUTES.indexOf(vv) === -1) customInput.value = String(vv);
  }
  if (varSlider) {
    varSlider.min = '0';
    varSlider.max = '30';
  }
  const presetBtns = document.querySelectorAll('[data-timer-preset]');
  presetBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const rawPreset = String(btn.getAttribute('data-timer-preset') || '');
      let raw = Number(rawPreset);
      if (rawPreset === 'custom') {
        raw = Number(customInput?.value || 30);
        const wrap = document.getElementById('timerCustomWrap');
        if (wrap) wrap.hidden = false;
        customInput?.focus();
      } else {
        const wrap = document.getElementById('timerCustomWrap');
        if (wrap) wrap.hidden = true;
      }
      if (!Number.isFinite(raw)) return;
      const next = Math.max(TIMER_MIN_MINUTES, Math.min(TIMER_MAX_MINUTES, Math.floor(raw)));
      if (slider) slider.value = String(next);
      if (rawPreset === 'custom' && customInput) customInput.value = String(next);
      updateTimerUI();
    });
  });
  if (customInput) {
    customInput.addEventListener('input', () => {
      const raw = Number(customInput.value);
      if (!Number.isFinite(raw)) return;
      const next = Math.max(TIMER_MIN_MINUTES, Math.min(TIMER_MAX_MINUTES, Math.floor(raw)));
      const customBtn = document.querySelector('[data-timer-preset="custom"]');
      if (customBtn) customBtn.classList.add('active');
      document.querySelectorAll('[data-timer-preset]').forEach((b) => {
        if (b !== customBtn) b.classList.remove('active');
      });
      const wrap = document.getElementById('timerCustomWrap');
      if (wrap) wrap.hidden = false;
      if (slider) {
        slider.value = String(next);
        updateTimerUI();
      }
    });
  }
}

function updateTimerUI() {
  const val = +document.getElementById('timerSec').value;
  const v = +document.getElementById('timerVar').value;
  document.getElementById('timerSecVal').textContent = formatTimerMinutesForDisplay(val);
  document.getElementById('timerVarVal').textContent = '±' + formatTimerMinutesForDisplay(v);
  document.querySelectorAll('[data-timer-preset]').forEach((btn) => {
    const preset = String(btn.getAttribute('data-timer-preset') || '');
    if (preset === 'custom') {
      btn.classList.toggle('active', TIMER_PRESET_MINUTES.indexOf(val) === -1);
      return;
    }
    const m = Number(preset);
    btn.classList.toggle('active', Number.isFinite(m) && m === val);
  });
  const customInput = document.getElementById('timerCustomMinutes');
  if (customInput && TIMER_PRESET_MINUTES.indexOf(val) === -1) customInput.value = String(val);
  const customWrap = document.getElementById('timerCustomWrap');
  if (customWrap) customWrap.hidden = TIMER_PRESET_MINUTES.indexOf(val) !== -1;
  document.getElementById('tMin').textContent = formatTimerMinutesForDisplay(Math.max(0, val - v));
  document.getElementById('tMax').textContent = formatTimerMinutesForDisplay(val + v);
  document.getElementById('tMinLbl').textContent = t('lbl_min');
  document.getElementById('tMaxLbl').textContent = t('lbl_max');
  const dailyOn = document.getElementById('dailyLimitEnabled').checked;
  const dailyOpts = document.getElementById('dailyLimitOpts');
  if (dailyOpts) {
    dailyOpts.style.opacity = dailyOn ? '1' : '0.45';
    dailyOpts.style.pointerEvents = dailyOn ? 'auto' : 'none';
  }
}

// Start/stop posting
function hideSecurityStopBanner() {
  const b = document.getElementById('securityStopBanner');
  if (b) b.hidden = true;
}

async function startPosting() {
  const posts = collectPostsForConfig();
  if (!posts.some(p => p.text && p.text.trim())) { alert(t('alert_message_required')); return; }
  let selBase = groups.filter(g => g.selected);
  if (!selBase.length) { alert(t('alert_select_one_group')); return; }
  const verifiedOnlyEnabled = document.getElementById('verifiedOnlyEnabled')?.checked;
  const sel = verifiedOnlyEnabled ? selBase.filter(g => g.canPost === true) : selBase;
  if (!sel.length) {
    if (verifiedOnlyEnabled) alert(t('alert_no_verified_groups'));
    else alert(t('alert_select_one_group'));
    return;
  }
  hideSecurityStopBanner();
  hideFailurePauseBanner();

  activePostingGroupUrls = new Set(sel.map(g => g.url));
  // Mark all selected groups as pending until we get results from background.
  sel.forEach(g => {
    g.postStatus = 'pending';
    g.postError = '';
  });
  renderGroups();

  const hasSpintax = posts.some(p => /\{[^{}]*\|[^{}]*\}/.test(p.text || ''));
  const dailyResumeTime = (document.getElementById('dailyResumeTime')?.value || '09:00').trim();
  if (hasProTierFeatures()) await persistProDailyLimitPrefsAsync();
  const proActive = await readLicenseStatus();

  let dailyLimitEnabled;
  let dailySuccessLimit;
  if (proActive) {
    const prefs = await new Promise((resolve) => {
      chrome.storage.local.get([DAILY_LIMIT_PREFS_KEY], (d) => resolve(d[DAILY_LIMIT_PREFS_KEY]));
    });
    dailyLimitEnabled = prefs?.enabled !== false;
    if (!dailyLimitEnabled) {
      dailySuccessLimit = 0;
    } else {
      let lim = Number(prefs?.limit);
      if (!Number.isFinite(lim) || lim < 1) lim = PRO_DAILY_LIMIT_DEFAULT;
      dailySuccessLimit = lim;
    }
    if (dailyLimitEnabled && (!Number.isFinite(dailySuccessLimit) || dailySuccessLimit < 1)) {
      alert(t('alert_daily_limit_invalid'));
      return;
    }
  } else {
    // Free tier = hard cap 3 successful posts per day.
    dailyLimitEnabled = true;
    dailySuccessLimit = 3;
    const dailyLimitInput = document.getElementById('dailySuccessLimit');
    if (dailyLimitInput) dailyLimitInput.value = '3';
    const dailyToggle = document.getElementById('dailyLimitEnabled');
    if (dailyToggle) dailyToggle.checked = true;
    refreshMonetizationUI();
    alert(t('free_daily_limit_forced'));
  }
  if (dailyLimitEnabled && (!Number.isFinite(dailySuccessLimit) || dailySuccessLimit < 1)) {
    alert(t('alert_daily_limit_invalid'));
    return;
  }
  if (dailyLimitEnabled && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(dailyResumeTime)) {
    alert(t('alert_resume_time_invalid'));
    return;
  }
  const config = {
    posts,
    text: posts[0].text,
    images: posts[0].images,
    useSpintax: hasSpintax,
    groups: sel,
    timerEnabled: true,
    timerSeconds: (() => {
      const raw = +document.getElementById('timerSec').value;
      const min = Math.min(TIMER_MAX_MINUTES, Math.max(TIMER_MIN_MINUTES, Number.isFinite(raw) ? raw : TIMER_MIN_MINUTES));
      return min * 60;
    })(),
    timerVariation: (+document.getElementById('timerVar').value || 0) * 60,
    dailyLimitEnabled,
    dailySuccessLimit,
    dailyResumeTime,
    bgTabsEnabled: document.getElementById('bgTabsEnabled')?.checked !== false,
    closeTabAfterPost: true,
    notifyEnd: document.getElementById('notifyEnd').checked,
    loopInfinite: document.getElementById('groupLoopInfinite')?.checked === true,
    verifiedOnlyEnabled: document.getElementById('verifiedOnlyEnabled')?.checked === true,
    pauseOnFailedPublication: document.getElementById('pauseOnFailedPublication')?.checked !== false,
    communityProfileFirst: isCommunityFreeBuild() && isCommunityProfileFirstEnabled()
  };

  const sessionWrite = await new Promise((resolve) => {
    posterImageLayersCache = null;
    writePosterImagesSessionThenSlim(config, resolve);
  });
  if (!sessionWrite.ok) {
    try {
      console.warn('[Irishka] Capas de imagen no persistidas del todo; se inicia publicación igual (IDB/local).', sessionWrite.error || '');
    } catch (e) {}
    if (!sessionWrite.slim) {
      if (sessionWrite.error === 'session_storage_unavailable') {
        alert(t('alert_session_storage_missing'));
      } else {
        alert(t('alert_storage_session_images_failed') + '\n' + (sessionWrite.error || ''));
      }
      return;
    }
  }
  const slimPoster = sessionWrite.slim;

  let posterStorageOk = false;
  await new Promise((resolve) => {
    chrome.storage.local.set({
      fbGroups: groups,
      posterConfig: slimPoster,
      posterRunning: true,
      posterResults: []
    }, () => {
      if (chrome.runtime.lastError) {
        alert(t('alert_storage_post_failed') + '\n' + chrome.runtime.lastError.message);
        resolve();
        return;
      }
      posterStorageOk = true;
      const selStepsForUi = isCommunityProfileFirstEnabled()
        ? [{ isProfileTimelineSlot: true, name: '', url: 'https://www.facebook.com/me' }, ...sel]
        : sel;
      lastProgressFlowMeta = {
        postIndex: 0,
        totalPosts: posts.length,
        totalGroups: selStepsForUi.length,
        resultsDone: 0
      };
      refreshProgressFlowGuide();
      resolve();
    });
  });
  if (!posterStorageOk) return;
  setRunning(true);
  goTab('progress');
  const selStepsForUi = isCommunityProfileFirstEnabled()
    ? [{ isProfileTimelineSlot: true, name: '', url: 'https://www.facebook.com/me' }, ...sel]
    : sel;
  initSteps(selStepsForUi);
  saveToHistory(posts.map(p => p.text).join('\n---\n'), '', sel.length);
  const groupsSnapshot = sel.map((g) => ({
    url: g.url,
    name: g.name,
    selected: true,
    canPost: typeof g.canPost === 'boolean' ? g.canPost : null,
    postStatus: g.postStatus || null,
    postError: g.postError || '',
    postabilityCheckedAt: g.postabilityCheckedAt || null,
    pendingPostsCount: g.pendingPostsCount || 0
  }));
  chrome.runtime.sendMessage({ action: 'startPosting', groupsSnapshot });
}

function createTabAndWait(url, active, maxWaitMs = 15000) {
  return new Promise(resolve => {
    chrome.tabs.create({ url, active: !!active }, (tab) => {
      const tabId = tab.id;
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        chrome.tabs.onUpdated.removeListener(onUpd);
        resolve(tab);
      };
      const onUpd = (id, info) => {
        if (id === tabId && info.status === 'complete') finish();
      };
      chrome.tabs.onUpdated.addListener(onUpd);
      setTimeout(finish, maxWaitMs);
    });
  });
}

function stopPosting(stopReason) {
  hideFailurePauseBanner();
  if (stopReason !== 'user_pause') {
    isPausedByUser = false;
  }
  chrome.runtime.sendMessage({
    action: 'stopPosting',
    stopReason: stopReason || 'user_stop'
  });
}

function setRunning(on) {
  isRunning = on;
  if (on) isPausedByUser = false;
  const btnStart = document.getElementById('btnStart');
  const btnStop = document.getElementById('btnStop');
  if (btnStart) btnStart.disabled = !!on || isPausedByUser;
  if (btnStop) btnStop.disabled = !on && !isPausedByUser;
  refreshPauseButtonUI();
  const bar = document.getElementById('runBar');
  if (bar) bar.className = 'run-bar' + ((on || isPausedByUser) ? ' show' : '');
  if (!on && !isPausedByUser) {
    if (runningPostsSyncTimer) {
      clearTimeout(runningPostsSyncTimer);
      runningPostsSyncTimer = null;
    }
    const cd = document.getElementById('cdBox');
    if (cd) cd.style.display = 'none';
    if (cdInterval) { clearInterval(cdInterval); cdInterval = null; }
  }
}

function resetAll() {
  if (isRunning && !confirm(t('confirm_stop_process'))) return;
  stopPosting();
  groups = [];
  saveGroups();
  renderGroups();
  const container = document.getElementById('postsContainer');
  while (container.querySelectorAll('.post-block').length > 1) {
    container.removeChild(container.lastElementChild);
  }
  const ed = document.getElementById('editor');
  if (ed) ed.value = '';
  const firstBlock = container.querySelector('.post-block');
  const pn = firstBlock?.querySelector('.text-preset-name');
  if (pn) pn.value = '';
  if (firstBlock) resetPostBlockSpintaxUI(firstBlock);
  postImages = [[]];
  bridgePostIndexById = {};
  posterImageLayersCache = null;
  renderPostImages(0);
  updatePostRemoveButtons();
  updateCC();
  loadTextPresets();
  initSteps([]);
  setLog(document.getElementById('scanLog'), 'inf', '');
  try {
    if (chrome.storage.session) {
      chrome.storage.session.remove(['fartmily_poster_session_images', 'fartmily_pending_images']);
    }
  } catch (e) {}
  try {
    if (typeof posterImageIdbClear === 'function') {
      posterImageIdbClear().catch(() => {});
    }
  } catch (e) {}
  chrome.storage.local.remove(['posterConfig', 'posterResults', HISTORY_KEY, 'fartmily_pending_images', 'fartmily_poster_persisted_images'], () => {
    renderHistory([]);
  });
}

// Progress
function initSteps(grps) {
  const el = document.getElementById('progSteps');
  document.getElementById('progLabel').textContent = grps.length ? (t('in_progress') || 'In progress...') : t('prog_not_started');
  document.getElementById('progFrac').textContent = '0/' + grps.length;
  document.getElementById('progBar').style.width = '0%';
  if (!grps.length) {
    el.innerHTML = '<div class="empty-note">' + (t('prog_empty') || 'Start the process to view status.') + '</div>';
    return;
  }
  el.innerHTML = '';
  grps.forEach((g, i) => {
    const d = document.createElement('div');
    d.className = 'step-item pending';
    d.id = 'step-' + i;
    const icon = document.createElement('span'); icon.textContent = '...';
    const label = g.isProfileTimelineSlot ? t('community_profile_slot') : (g.name || '');
    const name = document.createElement('span'); name.textContent = label;
    d.appendChild(icon); d.appendChild(name);
    el.appendChild(d);
  });
}

function refreshProgressFlowGuide() {
  const card = document.getElementById('progressFlowCard');
  if (!card) return;
  const titleEl = document.getElementById('progressFlowTitle');
  const leadEl = document.getElementById('progressFlowLead');
  const descEl = document.getElementById('progressFlowDesc');
  const statusEl = document.getElementById('progressFlowStatus');
  const badgesEl = document.getElementById('flowPostBadges');
  const stepPosts = document.getElementById('flowStepPosts');
  const stepGroups = document.getElementById('flowStepGroups');
  const stepOutcome = document.getElementById('flowStepOutcome');
  const flowGroupsDetail = document.getElementById('flowGroupsDetail');
  const flowOutcomeIcon = document.getElementById('flowOutcomeIcon');
  const postsLabel = document.getElementById('flowStepPostsLabel');
  const groupsLabel = document.getElementById('flowStepGroupsLabel');
  const outcomeLabel = document.getElementById('flowStepOutcomeLabel');
  const joinerEl = document.getElementById('progressFlowJoinerLine');
  if (!titleEl || !badgesEl || !statusEl) return;

  titleEl.textContent = t('progress_flow_title');
  if (leadEl) leadEl.textContent = t('progress_flow_lead');
  if (postsLabel) postsLabel.textContent = t('progress_flow_step_posts');
  if (groupsLabel) groupsLabel.textContent = t('progress_flow_step_groups');

  chrome.storage.local.get(['posterRunning', 'posterConfig', JOIN_QUEUE_STORAGE_KEY], (d) => {
    const jq = d[JOIN_QUEUE_STORAGE_KEY];
    const joinerOn = !!(jq && jq.active && Array.isArray(jq.urls) && jq.urls.length
      && (jq.cursor || 0) < jq.urls.length);
    if (joinerEl) {
      joinerEl.textContent = joinerOn ? t('progress_flow_auto_joiner_on') : t('progress_flow_auto_joiner_off');
    }

    // Solo isRunning: si OR con d.posterRunning, storage obsoleto puede dejar "Sesión activa" tras Stop / postingStopped.
    const running = !!isRunning;
    const cfg = d.posterConfig || {};
    if (running) syncComposeWithRunningPost(cfg, lastProgressFlowMeta.postIndex);
    const cfgPosts = Array.isArray(cfg.posts) && cfg.posts.length ? cfg.posts.length : 1;
    const totalPosts = running ? cfgPosts : Math.max(1, document.querySelectorAll('#postsContainer .post-block').length);
    const totalGroups = running
      ? Math.max(lastProgressFlowMeta.totalGroups || 0, (cfg.groups || []).length)
      : groups.filter(g => g.selected).length;
    const loopOn = running
      ? !!cfg.loopInfinite
      : (document.getElementById('groupLoopInfinite')?.checked === true);

    if (flowOutcomeIcon) flowOutcomeIcon.textContent = loopOn ? '🔁' : '✅';
    if (outcomeLabel) {
      outcomeLabel.textContent = loopOn ? t('progress_flow_step_loop') : t('progress_flow_step_once');
    }
    if (descEl) {
      descEl.textContent = loopOn ? t('progress_flow_loop_on_hint') : t('progress_flow_loop_off_hint');
    }

    const curPost = running ? Math.min(lastProgressFlowMeta.postIndex, Math.max(0, totalPosts - 1)) : -1;
    const done = running ? lastProgressFlowMeta.resultsDone : 0;

    if (stepOutcome) {
      if (running) {
        stepOutcome.classList.add('flow-outcome-clickable');
        stepOutcome.setAttribute('tabindex', '0');
        stepOutcome.setAttribute('role', 'button');
        stepOutcome.setAttribute('aria-label', t('progress_flow_click_toggle_loop'));
        stepOutcome.title = t('progress_flow_click_toggle_loop');
      } else {
        stepOutcome.classList.remove('flow-outcome-clickable');
        stepOutcome.removeAttribute('tabindex');
        stepOutcome.removeAttribute('role');
        stepOutcome.removeAttribute('aria-label');
        stepOutcome.removeAttribute('title');
      }
    }

    const activeRow = document.getElementById('flowActivePostRow');
    const thumb = document.getElementById('flowActivePostThumb');
    const cap = document.getElementById('flowActivePostCaption');
    const skipBtn = document.getElementById('flowSkipActivePostBtn');
    if (skipBtn) skipBtn.textContent = t('flow_skip_active_post');
    if (running && curPost >= 0 && cfg.posts && cfg.posts[curPost] && activeRow && thumb) {
      const showFlowThumb = (url) => {
        if (url && String(url).startsWith('data:')) {
          thumb.src = url;
          thumb.hidden = false;
        } else {
          thumb.removeAttribute('src');
          thumb.hidden = true;
        }
        if (cap) cap.textContent = tfmt('progress_flow_active_post_thumb_caption', { n: curPost + 1, total: totalPosts });
        activeRow.hidden = false;
      };
      const imgs = cfg.posts[curPost].images || [];
      const inlineUrl = imgs[0] && (imgs[0].dataUrl || imgs[0].thumbnail);
      if (inlineUrl && String(inlineUrl).startsWith('data:')) {
        showFlowThumb(inlineUrl);
      } else {
        loadPosterImageLayersForUi((layers) => {
          const row = Array.isArray(layers) ? layers[curPost] : null;
          const hydratedUrl = row && row[0] && row[0].dataUrl;
          showFlowThumb(hydratedUrl);
        });
      }
    } else if (activeRow) {
      activeRow.hidden = true;
      if (thumb) {
        thumb.removeAttribute('src');
        thumb.hidden = true;
      }
    }

    badgesEl.innerHTML = '';
    for (let i = 0; i < totalPosts; i++) {
      const span = document.createElement('span');
      span.className = 'flow-badge';
      span.textContent = String(i + 1);
      span.title = tfmt('progress_flow_post_n', { n: i + 1 });
      if (running) {
        if (i < curPost) span.classList.add('done');
        else if (i === curPost) {
          span.classList.add('active');
          if (totalGroups > 0 && done < totalGroups) span.classList.add('flow-badge-pulse');
        }
      }
      badgesEl.appendChild(span);
    }

    if (flowGroupsDetail) {
      flowGroupsDetail.textContent = totalGroups
        ? tfmt('progress_flow_groups_in_round', { n: totalGroups })
        : '0';
    }

    stepPosts?.classList.remove('active', 'done');
    stepGroups?.classList.remove('active', 'done');
    stepOutcome?.classList.remove('active', 'done');
    if (running) {
      stepPosts?.classList.add('active');
      if (totalGroups && done < totalGroups) stepGroups?.classList.add('active');
      else if (totalGroups) stepGroups?.classList.add('done');
      else stepGroups?.classList.add('active');
      if (loopOn) stepOutcome?.classList.add('active');
    }

    if (!running) {
      const loopStr = loopOn ? t('progress_flow_loop_yes') : t('progress_flow_loop_no');
      const pauseHint =
        document.getElementById('pauseOnFailedPublication')?.checked !== false
          ? '<p style="margin:8px 0 0;font-size:11px;color:var(--muted);line-height:1.45">' +
            escHtml(t('progress_flow_pause_manage_hint')) +
            '</p>'
          : '';
      statusEl.innerHTML =
        '<p style="margin:0 0 8px">' + escHtml(t('progress_flow_status_idle')) + '</p>' +
        '<p style="margin:0;font-size:11px;color:var(--muted)">' +
        escHtml(tfmt('progress_flow_draft', { posts: totalPosts, groups: totalGroups, loop: loopStr })) +
        '</p>' +
        pauseHint;
    } else {
      const sweepLine = totalGroups
        ? tfmt('progress_flow_sweep_progress', { done: Math.min(done, totalGroups), total: totalGroups })
        : '';
      const postLine = tfmt('progress_flow_now_post', { current: curPost + 1, total: totalPosts });
      const between = waitCountdownSec > 0
        ? '<br><span style="color:var(--muted)">' + escHtml(tfmt('progress_flow_between_wait_with_time', { time: formatCountdownSecondsForDisplay(waitCountdownSec) })) + '</span>'
        : '';
      statusEl.innerHTML =
        '<strong>' + escHtml(t('progress_flow_status_running')) + '</strong><br>' +
        escHtml(postLine) + '<br>' +
        escHtml(tfmt('progress_flow_groups_in_round', { n: totalGroups })) +
        (sweepLine ? '<br>' + escHtml(sweepLine) : '') +
        between;
    }
  });
}

function updateProgress(results, total, countdown, meta = {}) {
  const postIndex = meta.postIndex;
  const totalPosts = meta.totalPosts;
  const postPrefix = (totalPosts > 1 && postIndex !== undefined)
    ? tfmt('progress_post_of', { current: postIndex + 1, total: totalPosts }) + ' · '
    : '';
  waitCountdownSec = Math.max(0, Number(countdown || 0));
  // Update per-group post status badges (OK / Error).
  let changed = false;
  results.forEach(r => {
    const g = groups.find(x => x.url === r.url);
    if (!g) return;
    const nextStatus = r.success ? 'ok' : 'err';
    const nextError = r.success ? '' : (r.error || '');
    if (g.postStatus !== nextStatus || g.postError !== nextError) {
      g.postStatus = nextStatus;
      g.postError = nextError;
      changed = true;
    }
  });
  if (changed) {
    // Persist and refresh badges occasionally to avoid excessive DOM work.
    chrome.storage.local.set({ fbGroups: groups });
    const now = Date.now();
    if (now - lastGroupStatusRenderAt > 2000) {
      renderGroups();
      lastGroupStatusRenderAt = now;
    }
  }
  const done = results.length;
  const pct = total ? Math.round(done / total * 100) : 0;
  document.getElementById('progFrac').textContent = done + '/' + total;
  document.getElementById('progBar').style.width = pct + '%';
  if (countdown > 0 && done < total) {
    document.getElementById('progLabel').textContent = postPrefix + tfmt('wait_next_post', { time: formatCountdownSecondsForDisplay(countdown) });
  } else {
    document.getElementById('progLabel').textContent = postPrefix + ((done === total && total) ? (t('all_published') || 'All posts published!') : ((t('publishing') || 'Publishing...') + ' ' + pct + '%'));
  }
  const rb = document.getElementById('runBarText');
  if (rb) {
    if (countdown > 0 && done < total) rb.textContent = postPrefix + tfmt('wait_next_post', { time: formatCountdownSecondsForDisplay(countdown) });
    else rb.textContent = postPrefix + tfmt('posting_group_of', { current: Math.min(done + 1, total), total });
  }

  results.forEach((r, i) => {
    const el = document.getElementById('step-' + i);
    if (!el) return;
    el.className = 'step-item ' + (r.success ? 'done' : 'error');
    el.innerHTML = '';
    const icon = document.createElement('span'); icon.textContent = r.success ? t('progress_row_ok') : t('progress_row_err');
    const txt = document.createElement('span');
    txt.textContent = r.name + ' - ' + (r.success ? t('progress_published') : (r.error || t('error_label')));
    el.appendChild(icon); el.appendChild(txt);
  });

  if (done < total) {
    const cur = document.getElementById('step-' + done);
    if (cur) {
      const baseName = (results[done]?.name || groups[done]?.name || cur.querySelector('span:last-child')?.textContent || '').split(' - ')[0];
      cur.className = 'step-item current';
      cur.innerHTML = '';
      const i2 = document.createElement('span'); i2.textContent = '...';
      const t2 = document.createElement('span'); t2.textContent = baseName + ' - ' + (t('publishing') || 'Publishing...');
      cur.appendChild(i2); cur.appendChild(t2);
    }
  }

  const cdBox = document.getElementById('cdBox');
  if (countdown > 0 && done < total) { cdBox.style.display = 'block'; startCD(countdown); }
  else { cdBox.style.display = 'none'; }

  lastProgressFlowMeta = {
    postIndex: meta.postIndex !== undefined ? meta.postIndex : lastProgressFlowMeta.postIndex,
    totalPosts: meta.totalPosts !== undefined ? meta.totalPosts : lastProgressFlowMeta.totalPosts,
    totalGroups: total,
    resultsDone: done
  };
  refreshProgressFlowGuide();
}

function startCD(sec) {
  if (cdInterval) clearInterval(cdInterval);
  let r = sec;
  waitCountdownSec = r;
  document.getElementById('cdNum').textContent = formatCountdownSecondsForDisplay(r);
  refreshProgressFlowGuide();
  cdInterval = setInterval(() => {
    r--;
    waitCountdownSec = Math.max(0, r);
    document.getElementById('cdNum').textContent = formatCountdownSecondsForDisplay(r);
    refreshProgressFlowGuide();
    if (r <= 0) {
      clearInterval(cdInterval);
      cdInterval = null;
      waitCountdownSec = 0;
      refreshProgressFlowGuide();
      document.getElementById('cdBox').style.display = 'none';
    }
  }, 1000);
}

chrome.runtime.onMessage.addListener(msg => {
  if (msg.action === 'postRunStateResumed') {
    hideFailurePauseBanner();
    isPausedByUser = false;
    setRunning(true);
    goTab('progress');
    updateResumeProgrammedPostingUI();
    if (typeof msg.postIndex === 'number') lastProgressFlowMeta.postIndex = msg.postIndex;
    if (typeof msg.totalPosts === 'number' && msg.totalPosts > 0) {
      lastProgressFlowMeta.totalPosts = msg.totalPosts;
    }
    if (typeof msg.loopInfinite === 'boolean') {
      const cb = document.getElementById('groupLoopInfinite');
      if (cb) cb.checked = msg.loopInfinite;
    }
    const fromMsg = Array.isArray(msg.groupsForProgress) && msg.groupsForProgress.length
      ? msg.groupsForProgress.map((g) => ({
          name: g.name,
          url: g.url,
          selected: true,
          canPost: true,
          isProfileTimelineSlot: !!g.isProfileTimelineSlot
        }))
      : null;
    if (fromMsg) {
      initSteps(fromMsg);
    } else {
      chrome.storage.local.get(['posterConfig'], (d) => {
        const grps = d.posterConfig?.groups || [];
        initSteps(grps);
      });
    }
    chrome.storage.local.get(['posterResults', 'posterConfig', POSTER_RUN_STATE_KEY], (d) => {
      const saved = d[POSTER_RUN_STATE_KEY];
      const r = d.posterResults || [];
      const total = (saved?.config?.groups && saved.config.groups.length)
        ? saved.config.groups.length
        : (d.posterConfig && d.posterConfig.groups && d.posterConfig.groups.length)
          ? d.posterConfig.groups.length
          : Math.max(r.length, 1);
      const meta = {
        postIndex: typeof saved?.postIndex === 'number'
          ? saved.postIndex
          : (typeof msg.postIndex === 'number' ? msg.postIndex : lastProgressFlowMeta.postIndex),
        totalPosts: Array.isArray(saved?.config?.posts) && saved.config.posts.length
          ? saved.config.posts.length
          : (typeof msg.totalPosts === 'number' ? msg.totalPosts : (d.posterConfig?.posts?.length || lastProgressFlowMeta.totalPosts)),
      };
      lastProgressFlowMeta.postIndex = meta.postIndex ?? lastProgressFlowMeta.postIndex;
      lastProgressFlowMeta.totalPosts = meta.totalPosts ?? lastProgressFlowMeta.totalPosts;
      updateProgress(r, total, 0, meta);
    });
    refreshProgressFlowGuide();
    return;
  }
  if (msg.action === 'bridgeIncomingCompose') {
    if (!isCommunityFreeBuild()) return;
    try {
      chrome.storage.local.remove(IRISHKA_BRIDGE_PENDING_KEY);
    } catch (e) {}
    applyBridgeComposeToEditor(msg);
    return;
  }
  if (msg.action === 'bridgeIncomingText' && msg.text) {
    if (!isCommunityFreeBuild()) return;
    try {
      chrome.storage.local.remove(IRISHKA_BRIDGE_PENDING_KEY);
    } catch (e) {}
    applyBridgeComposeToEditor({ text: msg.text });
    return;
  }
  if (msg.action === 'progressUpdate') updateProgress(msg.results, msg.total, msg.countdown || 0, msg);
  if (msg.action === 'postSweepStart') {
    lastProgressFlowMeta.postIndex = msg.postIndex ?? 0;
    if (msg.totalPosts != null) lastProgressFlowMeta.totalPosts = msg.totalPosts;
    if (msg.total != null) {
      lastProgressFlowMeta.totalGroups = msg.total;
      lastProgressFlowMeta.resultsDone = 0;
    }
    refreshProgressFlowGuide();
    chrome.storage.local.get(['posterConfig'], (d) => {
      syncComposeWithRunningPost(d.posterConfig || {}, lastProgressFlowMeta.postIndex);
    });
    const fromMsg = Array.isArray(msg.groupsForProgress) && msg.groupsForProgress.length
      ? msg.groupsForProgress
      : null;
    if (fromMsg) {
      initSteps(fromMsg);
    } else {
      chrome.storage.local.get(['posterConfig'], (d) => {
        const grps = d.posterConfig?.groups || [];
        initSteps(grps);
      });
    }
    if (msg.totalPosts > 1) {
      const line = tfmt('progress_post_of', { current: msg.postIndex + 1, total: msg.totalPosts }) + ' — ' + (t('in_progress') || '');
      const pl = document.getElementById('progLabel');
      if (pl) pl.textContent = line;
      const rb = document.getElementById('runBarText');
      if (rb) rb.textContent = line;
    }
  }
  if (msg.action === 'loopVerifyProgress') {
    const pl = document.getElementById('progLabel');
    const rb = document.getElementById('runBarText');
    const total = Number(msg.total) || 0;
    const cur = Number(msg.current) || 0;
    const name = String(msg.groupName || '').trim();
    const line = cur <= 0
      ? (tfmt('loop_verify_start', { total }) || `Verificando ${total} grupos no verificados…`)
      : (tfmt('loop_verify_item', { current: cur, total, name: name || '…' })
        || `Verificando ${cur}/${total}: ${name || '…'}`);
    if (pl) pl.textContent = line;
    if (rb) rb.textContent = line;
    return;
  }
  if (msg.action === 'groupsListChanged') {
    chrome.storage.local.get(['fbGroups'], (d) => {
      if (Array.isArray(d.fbGroups)) {
        groups = d.fbGroups;
        renderGroups();
      }
    });
    return;
  }
  if (msg.action === 'loopRoundRestart') {
    lastProgressFlowMeta.postIndex = 0;
    lastProgressFlowMeta.resultsDone = 0;
    if (typeof msg.total === 'number') lastProgressFlowMeta.totalGroups = msg.total;
    refreshProgressFlowGuide();
    let label = t('loop_round_restart') || '';
    const newlyVerified = Number(msg.newlyVerified) || 0;
    const verifyChecked = Number(msg.verifyChecked) || 0;
    if (verifyChecked > 0) {
      label = tfmt('loop_round_restart_verified', {
        new: newlyVerified,
        checked: verifyChecked,
      }) || `Nueva vuelta · ${newlyVerified}/${verifyChecked} grupos verificados OK`;
    }
    const pl = document.getElementById('progLabel');
    if (pl) pl.textContent = label;
    const rb = document.getElementById('runBarText');
    if (rb) rb.textContent = label;
    if (Array.isArray(msg.groupsForProgress) && msg.groupsForProgress.length) {
      initSteps(msg.groupsForProgress);
    } else {
      chrome.storage.local.get(['posterConfig'], (d) => {
        const grps = d.posterConfig?.groups || [];
        initSteps(grps);
      });
    }
  }
  if (msg.action === 'plannerStatus') {
    const text = msg.message || t('planner_active_default');
    document.getElementById('progLabel').textContent = text;
    const rb = document.getElementById('runBarText');
    if (rb) rb.textContent = text;
    updateGroupSchedulePostingHint();
  }
  if (msg.action === 'posterLoopModeChanged') {
    const cb = document.getElementById('groupLoopInfinite');
    if (cb) cb.checked = !!msg.loopInfinite;
    refreshProgressFlowGuide();
  }
  if (msg.action === 'runningPostsQueueChanged') {
    if (typeof msg.totalPosts === 'number' && msg.totalPosts > 0) {
      lastProgressFlowMeta.totalPosts = msg.totalPosts;
    }
    refreshProgressFlowGuide();
  }
  if (msg.action === 'joinQueueProgress') {
    const result = msg.lastOk ? t('join_queue_status_ok') : t('join_queue_status_fail');
    if (msg.lastOk && msg.lastUrl) {
      onJoinQueueSuccessMoveToPostingList(msg.lastUrl);
    }
    appendJoinQueueLog(
      'inf',
      tfmt('join_queue_log_progress', {
        current: msg.joinedTotal,
        total: msg.listTotal,
        today: msg.joinedToday,
        max: msg.dailyMax,
        result
      })
    );
    refreshJoinQueueStatePanel();
  }
  if (msg.action === 'joinQueueScheduled') {
    const whenStr = msg.when ? new Date(msg.when).toLocaleString() : '';
    appendJoinQueueLog('ok', tfmt('join_queue_scheduled_log', { when: whenStr }));
    refreshJoinQueueStatePanel();
  }
  if (msg.action === 'joinQueueFinished') {
    appendJoinQueueLog('ok', tfmt('join_queue_finished', { n: msg.total || 0 }));
    refreshJoinQueueStatePanel();
  }
  if (msg.action === 'postingFinished') {
    hideSecurityStopBanner();
    hideFailurePauseBanner();
    setRunning(false);
    updateResumeProgrammedPostingUI();
    updateProgress(msg.results, msg.total, 0);
    document.getElementById('progLabel').textContent = t('all_published') || 'All posts published!';
    if (activePostingGroupUrls) {
      // Remaining groups that weren't attempted yet stay pending.
      groups.forEach(g => {
        if (activePostingGroupUrls.has(g.url) && !msg.results.some(r => r.url === g.url)) {
          if (!g.postStatus || g.postStatus !== 'ok') g.postStatus = 'pending';
        }
      });
      activePostingGroupUrls = null;
      saveGroups();
      renderGroups();
    }
  }
  if (msg.action === 'postingStopped') {
    const wasRunning = isRunning;
    const rawReason = msg.stopReason;
    const reason = (rawReason != null && rawReason !== '')
      ? rawReason
      : (wasRunning ? 'session_interrupted' : 'unknown');

    if (reason === 'user_pause') {
      isRunning = false;
      try { chrome.storage.local.set({ posterRunning: false }); } catch (e) {}
      hideFailurePauseBanner();
      chrome.storage.local.get(['posterResults', 'posterConfig'], (d) => {
        const r = d.posterResults || [];
        const total = (d.posterConfig && d.posterConfig.groups && d.posterConfig.groups.length)
          ? d.posterConfig.groups.length
          : Math.max(r.length, 1);
        const meta = {
          postIndex: d.posterConfig && Array.isArray(d.posterConfig.posts) ? lastProgressFlowMeta.postIndex : undefined,
          totalPosts: d.posterConfig && Array.isArray(d.posterConfig.posts) ? d.posterConfig.posts.length : undefined
        };
        updateProgress(r, total, 0, meta);
        const pausedMsg = t('prog_paused_by_user') || 'Paused';
        const pl = document.getElementById('progLabel');
        if (pl) pl.textContent = pausedMsg;
        const rb = document.getElementById('runBarText');
        if (rb) rb.textContent = pausedMsg;
        setUserPaused(true);
        refreshProgressFlowGuide();
      });
      updateResumeProgrammedPostingUI();
      return;
    }

    setRunning(false);
    try { chrome.storage.local.set({ posterRunning: false }); } catch (e) {}
    if (reason === 'post_failure_pause') {
      const pauseDetail = msg.pauseDetail || { groupName: '', groupUrl: '', error: '' };
      chrome.storage.local.get(['posterResults', 'posterConfig'], (d) => {
        const r = d.posterResults || [];
        const total = (d.posterConfig && d.posterConfig.groups && d.posterConfig.groups.length)
          ? d.posterConfig.groups.length
          : Math.max(r.length, 1);
        const meta = {
          postIndex: d.posterConfig && Array.isArray(d.posterConfig.posts) ? lastProgressFlowMeta.postIndex : undefined,
          totalPosts: d.posterConfig && Array.isArray(d.posterConfig.posts) ? d.posterConfig.posts.length : undefined
        };
        updateProgress(r, total, 0, meta);
        const shortMsg = t('failure_pause_title') || '';
        const pl = document.getElementById('progLabel');
        if (pl) pl.textContent = shortMsg;
        const rb = document.getElementById('runBarText');
        if (rb) rb.textContent = shortMsg;
        showFailurePauseBanner(pauseDetail);
        refreshProgressFlowGuide();
      });
    } else {
      hideFailurePauseBanner();
    }
    if (reason !== 'post_failure_pause') {
      let idleMsg = t('prog_not_started');
      if (reason === 'user_stop') idleMsg = t('prog_stopped_by_user');
      else if (reason === 'session_interrupted') idleMsg = t('prog_session_interrupted');
      else if (reason === 'daily_limit') idleMsg = t('prog_stopped_daily_limit');
      else if (reason === 'license_lost') idleMsg = t('prog_stopped_license');
      else if (reason === 'no_groups' || reason === 'bad_config') idleMsg = t('prog_not_started');
      else if (reason === 'unknown') idleMsg = t('prog_not_started');
      const pl = document.getElementById('progLabel');
      if (pl) pl.textContent = idleMsg;
      const rb = document.getElementById('runBarText');
      if (rb) rb.textContent = idleMsg;
    }
    if (reason !== 'post_failure_pause') refreshProgressFlowGuide();
    if (activePostingGroupUrls && reason !== 'post_failure_pause') {
      groups.forEach(g => {
        if (!activePostingGroupUrls.has(g.url)) return;
        // If it wasn't reported as OK/ERR, keep it pending.
        if (g.postStatus !== 'ok' && g.postStatus !== 'err') {
          g.postStatus = 'pending';
          g.postError = '';
        }
      });
      activePostingGroupUrls = null;
      saveGroups();
      renderGroups();
    }
    updateResumeProgrammedPostingUI();
  }

});

// Spintax
function spinText(text) {
  let result = text, maxPasses = 20;
  while (maxPasses-- > 0) {
    const prev = result;
    result = result.replace(/\{([^{}]+)\}/g, (match, inner) => {
      const options = inner.split('|');
      return options[Math.floor(Math.random() * options.length)];
    });
    if (result === prev) break;
  }
  return result;
}

function countSpinGroups(text) {
  const matches = text.match(/\{[^{}]*\|[^{}]*\}/g);
  return matches ? matches.length : 0;
}

function getPostBlockByIdx(postIdx) {
  return document.querySelectorAll('#postsContainer .post-block')[postIdx];
}

function getEditorForPost(postIdx) {
  const b = getPostBlockByIdx(postIdx);
  return b?.querySelector('.post-editor') || null;
}

function spInsertForPost(postIdx) {
  const ta = getEditorForPost(postIdx) || getFocusedOrFirstEditor();
  const start = ta.selectionStart;
  const end = ta.selectionEnd;
  const snippet = t('spintax_template_example');
  ta.value = ta.value.slice(0, start) + snippet + ta.value.slice(end);
  const open = snippet.indexOf('{');
  const pipe = snippet.indexOf('|');
  if (open !== -1 && pipe > open) {
    ta.selectionStart = start + open + 1;
    ta.selectionEnd = start + pipe;
  } else {
    ta.selectionStart = ta.selectionEnd = start + snippet.length;
  }
  ta.focus();
  updateCC();
  const block = ta.closest('.post-block');
  const i = block ? [...document.querySelectorAll('#postsContainer .post-block')].indexOf(block) : -1;
  if (i >= 0 && block.querySelector('.sp-preview-wrap')?.classList.contains('sp-preview-open')) {
    refreshSpPreviewForPost(i);
  }
}

function syncSpPreviewForLang() {
  document.querySelectorAll('#postsContainer .post-block').forEach((block) => {
    const btn = block.querySelector('.sp-preview-btn');
    const wrap = block.querySelector('.sp-preview-wrap');
    if (!btn || !wrap) return;
    const open = wrap.classList.contains('sp-preview-open');
    btn.textContent = open ? t('spintax_close_view') : t('spintax_preview_btn_alt');
    if (open) {
      const idx = [...document.querySelectorAll('#postsContainer .post-block')].indexOf(block);
      if (idx >= 0) refreshSpPreviewForPost(idx);
    }
  });
}

function toggleSpPreviewForPost(postIdx) {
  const block = getPostBlockByIdx(postIdx);
  if (!block) return;
  const wrap = block.querySelector('.sp-preview-wrap');
  const hint = block.querySelector('.post-sp-hint');
  const btn = block.querySelector('.sp-preview-btn');
  if (!wrap || !btn) return;
  const open = !wrap.classList.contains('sp-preview-open');
  wrap.classList.toggle('sp-preview-open', open);
  wrap.style.display = open ? 'block' : 'none';
  if (hint) hint.style.display = open ? 'none' : 'block';
  btn.classList.toggle('sp-highlight', open);
  btn.textContent = open ? t('spintax_close_view') : t('spintax_preview_btn_alt');
  if (open) refreshSpPreviewForPost(postIdx);
}

function refreshSpPreviewForPost(postIdx) {
  const ta = getEditorForPost(postIdx);
  const block = getPostBlockByIdx(postIdx);
  if (!ta || !block) return;
  const body = block.querySelector('.sp-preview-body');
  const label = block.querySelector('.sp-variant-label');
  if (!body || !label) return;
  const raw = ta.value || '';
  if (!raw.trim()) {
    body.innerHTML = '<span style="color:var(--muted)">' + escHtml(t('editor_empty')) + '</span>';
    label.textContent = '';
    return;
  }
  const spinCount = countSpinGroups(raw);
  label.textContent = spinCount > 0 ? tfmt('spintax_variations', { n: spinCount }) : t('spintax_none');
  if (spinCount === 0) {
    body.textContent = raw;
    return;
  }
  let preview = escHtml(raw);
  let passes = 20;
  while (passes-- > 0) {
    const prev = preview;
    preview = preview.replace(/\{([^{}]+)\}/g, (match, inner) => {
      const options = inner.split('|');
      const chosen = options[Math.floor(Math.random() * options.length)];
      return '<span class="sp-chosen">' + chosen + '</span>';
    });
    if (preview === prev) break;
  }
  body.innerHTML = preview;
}

// History
async function saveToHistory(text, link, groupCount) {
  const entry = { id: Date.now(), date: new Date().toLocaleString(), text, link: link || '', groupCount, charCount: text.length };
  chrome.storage.local.get(HISTORY_KEY, (data) => {
    let hist = data[HISTORY_KEY] || [];
    hist.unshift(entry);
    if (hist.length > HISTORY_MAX) hist = hist.slice(0, HISTORY_MAX);
    chrome.storage.local.set({ [HISTORY_KEY]: hist }, renderHistory);
  });
}

function loadHistory() {
  chrome.storage.local.get(HISTORY_KEY, (data) => { renderHistory(data[HISTORY_KEY] || []); });
}

function renderHistory(histArg) {
  if (histArg === undefined) { chrome.storage.local.get(HISTORY_KEY, (data) => renderHistory(data[HISTORY_KEY] || [])); return; }
  const list = document.getElementById('historyList');
  if (!histArg.length) {
    const historyEmpty = (typeof t === 'function' ? t('history_empty') : 'No messages saved yet.');
    list.innerHTML = '<div class="empty-note">' + historyEmpty + '</div>';
    return;
  }
  list.innerHTML = '';
  histArg.forEach((entry) => {
    const item = document.createElement('div');
    item.className = 'history-item';

    const header = document.createElement('div');
    header.className = 'history-item-header';
    const dateEl = document.createElement('span');
    dateEl.className = 'history-item-date';
    dateEl.textContent = entry.date;
    const statsEl = document.createElement('span');
    statsEl.className = 'history-item-stats';
    statsEl.textContent = tfmt('history_entry_stats', {
      chars: entry.charCount,
      groups: entry.groupCount,
      link: entry.link ? t('history_link_suffix') : ''
    });
    header.appendChild(dateEl);
    header.appendChild(statsEl);

    const textEl = document.createElement('div');
    textEl.className = 'history-item-text';
    textEl.textContent = entry.text;

    const actions = document.createElement('div');
    actions.className = 'history-item-actions';

    const useBtn = document.createElement('button');
    useBtn.className = 'btn btn-primary btn-sm';
    useBtn.textContent = t('history_use_text');
    useBtn.addEventListener('click', () => {
      document.getElementById('editor').value = entry.text;
      updateCC();
      goTab('compose');
    });

    const copyBtn = document.createElement('button');
    copyBtn.className = 'btn btn-secondary btn-sm';
    copyBtn.textContent = t('history_copy');
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(entry.text).then(() => {
        const orig = copyBtn.textContent;
        copyBtn.textContent = t('copied');
        setTimeout(() => { copyBtn.textContent = orig; }, 2000);
      });
    });

    const delBtn = document.createElement('button');
    delBtn.className = 'btn btn-danger btn-sm';
    delBtn.textContent = 'X';
    delBtn.addEventListener('click', () => {
      chrome.storage.local.get(HISTORY_KEY, (data) => {
        const hist = (data[HISTORY_KEY] || []).filter(e => e.id !== entry.id);
        chrome.storage.local.set({ [HISTORY_KEY]: hist }, () => renderHistory(hist));
      });
    });

    actions.appendChild(useBtn);
    actions.appendChild(copyBtn);
    actions.appendChild(delBtn);
    item.appendChild(header);
    item.appendChild(textEl);
    item.appendChild(actions);
    list.appendChild(item);
  });
}

function clearHistory() {
  if (!confirm(t('confirm_clear_history'))) return;
  chrome.storage.local.remove(HISTORY_KEY, () => renderHistory([]));
}

let bridgeLanPollTimer = null;

function removeBridgeLanUICardIfRetailBuild() {
  if (isCommunityFreeBuild()) return;
  document.getElementById('bridgeLanCard')?.remove();
  if (bridgeLanPollTimer) {
    clearInterval(bridgeLanPollTimer);
    bridgeLanPollTimer = null;
  }
}

function decodeBridgeUtf8Base64Maybe(input) {
  const s = String(input || '').trim();
  if (!s || !/^[A-Za-z0-9+/=_-]+$/.test(s) || s.length < 16) return '';
  try {
    const normalized = s.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized + '='.repeat((4 - (normalized.length % 4 || 4)) % 4);
    const raw = atob(padded);
    const bytes = Uint8Array.from(raw, (ch) => ch.charCodeAt(0));
    const out = new TextDecoder('utf-8', { fatal: false }).decode(bytes).trim();
    return out;
  } catch {
    return '';
  }
}

function normalizeBridgeText(raw) {
  const text = String(raw || '');
  const trimmed = text.trim();
  if (!trimmed) return '';
  const b64Decoded = decodeBridgeUtf8Base64Maybe(trimmed);
  if (b64Decoded) return b64Decoded;
  if (/%[0-9a-fA-F]{2}/.test(trimmed)) {
    try {
      return decodeURIComponent(trimmed.replace(/\+/g, '%20')).trim();
    } catch {}
  }
  return trimmed;
}

function parseBridgeEnvelope(raw) {
  const txt = String(raw || '').trim();
  if (!txt) return null;
  let base64Payload = '';
  if (txt.startsWith('MM_PAYLOAD::')) {
    base64Payload = txt.slice('MM_PAYLOAD::'.length).trim();
  } else if (txt.startsWith('MM_POST::')) {
    base64Payload = txt.slice('MM_POST::'.length).trim();
  } else if (txt.startsWith('{') && txt.endsWith('}')) {
    try { return JSON.parse(txt); } catch { return null; }
  }
  if (!base64Payload) return null;
  const jsonText = decodeBridgeUtf8Base64Maybe(base64Payload);
  if (!jsonText) return null;
  try {
    return JSON.parse(jsonText);
  } catch {
    return null;
  }
}

function normalizeBridgeIncomingCompose(payload) {
  const envFromString = typeof payload === 'string' ? parseBridgeEnvelope(payload) : null;
  const p0 = (envFromString && typeof envFromString === 'object') ? envFromString : (payload && typeof payload === 'object' ? payload : {});
  const envInText = parseBridgeEnvelope(
    p0.text ?? p0.message ?? p0.caption ?? p0.postText ?? p0.body ?? ''
  );
  const p = (envInText && typeof envInText === 'object') ? envInText : p0;
  const text = normalizeBridgeText(
    p.text ?? p.message ?? p.caption ?? p.postText ?? p.body ?? ''
  );
  const rawImages = [];
  if (Array.isArray(p.images)) rawImages.push(...p.images);
  if (Array.isArray(p.imageList)) rawImages.push(...p.imageList);
  if (p.image != null) rawImages.push(p.image);
  if (p.imageDataUrl != null) rawImages.push(p.imageDataUrl);
  if (p.imageData != null) rawImages.push(p.imageData);
  if (p.imageBase64 != null) rawImages.push(p.imageBase64);
  if (p.image_data != null) rawImages.push(p.image_data);

  const images = rawImages
    .map((img, i) => {
      if (img && typeof img === 'object') {
        const val = String(img.dataUrl ?? img.base64 ?? img.imageBase64 ?? img.data ?? '').trim();
        if (!val) return null;
        const type = String((img.type ?? img.mimeType ?? p.imageMimeType ?? p.imageType) || 'image/jpeg');
        const name = String(img.name || `bridge-image-${i + 1}.jpg`);
        if (val.startsWith('data:image/')) return { dataUrl: val, type, name };
        if (!/^[A-Za-z0-9+/=_-]+$/.test(val.replace(/\s+/g, ''))) return null;
        return { dataUrl: `data:${type};base64,${val.replace(/\s+/g, '')}`, type, name };
      }
      const val = String(img || '').trim();
      if (!val) return null;
      if (val.startsWith('data:image/')) return { dataUrl: val, type: 'image/jpeg', name: `bridge-image-${i + 1}.jpg` };
      if (!/^[A-Za-z0-9+/=_-]+$/.test(val.replace(/\s+/g, ''))) return null;
      return { dataUrl: `data:image/jpeg;base64,${val.replace(/\s+/g, '')}`, type: 'image/jpeg', name: `bridge-image-${i + 1}.jpg` };
    })
    .filter(Boolean)
    .slice(0, MAX_IMAGES_PER_POST);

  return {
    text,
    images,
    mode: String(p.mode || '').trim(),
    postId: String(p.postId || p.id || '').trim()
  };
}

function applyBridgeComposeToEditor(payload) {
  const compose = normalizeBridgeIncomingCompose(payload);
  const isAppend = compose.mode === 'append_new_post';
  const blocks = document.querySelectorAll('#postsContainer .post-block');
  let targetIdx = 0;
  if (compose.postId && Number.isFinite(bridgePostIndexById[compose.postId])) {
    targetIdx = bridgePostIndexById[compose.postId];
  } else if (isAppend) {
    targetIdx = blocks.length;
    addPostBlock();
    if (compose.postId) bridgePostIndexById[compose.postId] = targetIdx;
  }
  const allBlocks = document.querySelectorAll('#postsContainer .post-block');
  const ed = (allBlocks[targetIdx] || allBlocks[0])?.querySelector('.post-editor');
  if (!ed) return;
  if (compose.text) ed.value = compose.text;
  if (Array.isArray(compose.images) && compose.images.length) {
    syncPostImagesSlots();
    postImages[targetIdx] = compose.images;
    renderPostImages(targetIdx);
    queueRunningPostsSync();
  }
  if (targetIdx === 0) updateCC();
  goTab('compose');
}

function syncComposeWithRunningPost(config, postIndex) {
  if (!isRunning) return;
  const cfg = config && typeof config === 'object' ? config : null;
  const posts = Array.isArray(cfg?.posts) ? cfg.posts : [];
  if (!posts.length) return;
  const idxRaw = Number(postIndex);
  const idx = Number.isFinite(idxRaw) ? Math.max(0, Math.min(posts.length - 1, idxRaw)) : 0;
  const p = posts[idx] || posts[0];
  if (!p) return;
  ensureComposeBlocksCount(posts.length);
  updatePostRemoveButtons();
  const blocks = document.querySelectorAll('#postsContainer .post-block');
  const ed = blocks[idx]?.querySelector('.post-editor');
  if (!ed) return;
  const nextText = String(p.text || '');
  if (ed.value !== nextText) ed.value = nextText;
  const nextImagesBase = (Array.isArray(p.images) ? p.images : [])
    .slice(0, MAX_IMAGES_PER_POST)
    .map((img, i) => ({
      dataUrl: String(img?.dataUrl || img?.thumbnail || ''),
      name: String(img?.name || `running-post-${idx + 1}-img-${i + 1}.jpg`),
      type: String(img?.type || 'image/jpeg')
    }));
  const applyImagesToCompose = (imgsCandidate) => {
    const imgs = (Array.isArray(imgsCandidate) ? imgsCandidate : [])
      .slice(0, MAX_IMAGES_PER_POST)
      .filter((img) => String(img?.dataUrl || '').startsWith('data:image/'));
    syncPostImagesSlots();
    const currentSig = JSON.stringify((postImages[idx] || []).map((x) => x.dataUrl || ''));
    const nextSig = JSON.stringify(imgs.map((x) => x.dataUrl || ''));
    if (currentSig !== nextSig) {
      postImages[idx] = imgs;
      renderPostImages(idx);
    }
    updateCC();
  };
  const hasInlineImages = nextImagesBase.some((img) => img.dataUrl.startsWith('data:image/'));
  if (hasInlineImages) {
    applyImagesToCompose(nextImagesBase);
    return;
  }
  loadPosterImageLayersForUi((layers) => {
    const row = Array.isArray(layers) ? layers[idx] : null;
    const hydrated = Array.isArray(row) ? row.map((img, i) => ({
      dataUrl: String(img?.dataUrl || ''),
      name: String(img?.name || `running-post-${idx + 1}-img-${i + 1}.jpg`),
      type: String(img?.type || 'image/jpeg')
    })) : [];
    applyImagesToCompose(hydrated.length ? hydrated : nextImagesBase);
  });
}

function flushPosterImageLayerWaiters(layers) {
  const cbs = posterImageLayersPendingCbs.slice();
  posterImageLayersPendingCbs = [];
  cbs.forEach((cb) => {
    try { cb(layers); } catch (e) {}
  });
}

function loadPosterImageLayersForUi(cb) {
  if (posterImageLayersCache && Array.isArray(posterImageLayersCache)) {
    cb(posterImageLayersCache);
    return;
  }
  posterImageLayersPendingCbs.push(cb);
  if (posterImageLayersLoading) return;
  posterImageLayersLoading = true;
  const sessionKey = (typeof POSTER_SESSION_IMAGES_KEY === 'string' && POSTER_SESSION_IMAGES_KEY)
    ? POSTER_SESSION_IMAGES_KEY
    : 'fartmily_poster_session_images';
  const localKey = (typeof POSTER_PERSISTED_IMAGES_KEY === 'string' && POSTER_PERSISTED_IMAGES_KEY)
    ? POSTER_PERSISTED_IMAGES_KEY
    : 'fartmily_poster_persisted_images';
  const finish = (layers) => {
    posterImageLayersLoading = false;
    posterImageLayersCache = Array.isArray(layers) ? layers : [];
    flushPosterImageLayerWaiters(posterImageLayersCache);
  };
  const trySessionLocal = () => {
    const fromPack = (pack) => {
      const layers = pack && Array.isArray(pack.layers) ? pack.layers : [];
      if (layers.length) return finish(layers);
      chrome.storage.local.get([localKey], (dLocal) => {
        const localPack = dLocal ? dLocal[localKey] : null;
        const localLayers = localPack && Array.isArray(localPack.layers) ? localPack.layers : [];
        finish(localLayers);
      });
    };
    if (!chrome.storage.session) {
      chrome.storage.local.get([localKey], (dLocal) => {
        const localPack = dLocal ? dLocal[localKey] : null;
        const localLayers = localPack && Array.isArray(localPack.layers) ? localPack.layers : [];
        finish(localLayers);
      });
      return;
    }
    chrome.storage.session.get([sessionKey], (dSession) => {
      const sessionPack = dSession ? dSession[sessionKey] : null;
      fromPack(sessionPack);
    });
  };
  if (typeof posterImageIdbLoadLayers === 'function') {
    posterImageIdbLoadLayers()
      .then((idlayers) => {
        if (idlayers && idlayers.length) finish(idlayers);
        else trySessionLocal();
      })
      .catch(() => trySessionLocal());
  } else {
    trySessionLocal();
  }
}

function ensureComposeBlocksCount(n) {
  const target = Math.max(1, Number(n) || 1);
  const container = document.getElementById('postsContainer');
  if (!container) return;
  while (container.querySelectorAll('.post-block').length < target) addPostBlock();
  while (container.querySelectorAll('.post-block').length > target) {
    const idx = container.querySelectorAll('.post-block').length - 1;
    removePostBlock(idx);
  }
}

function restoreComposeFromPosterConfig(config) {
  const cfg = config && typeof config === 'object' ? config : null;
  const posts = Array.isArray(cfg?.posts) && cfg.posts.length ? cfg.posts : [{
    text: String(cfg?.text || ''),
    images: Array.isArray(cfg?.images) ? cfg.images : []
  }];
  ensureComposeBlocksCount(posts.length);
  loadPosterImageLayersForUi((layers) => {
    syncPostImagesSlots();
    posts.forEach((p, idx) => {
      const blocks = document.querySelectorAll('#postsContainer .post-block');
      const ta = blocks[idx]?.querySelector('.post-editor');
      if (ta) ta.value = String(p?.text || '');
      let imgs = (Array.isArray(p?.images) ? p.images : []).map((img, i) => ({
        dataUrl: String(img?.dataUrl || ''),
        name: String(img?.name || `restored-post-${idx + 1}-img-${i + 1}.jpg`),
        type: String(img?.type || 'image/jpeg')
      })).filter((img) => img.dataUrl.startsWith('data:image/'));
      if (!imgs.length && Array.isArray(layers?.[idx])) {
        imgs = layers[idx].map((img, i) => ({
          dataUrl: String(img?.dataUrl || ''),
          name: String(img?.name || `restored-post-${idx + 1}-img-${i + 1}.jpg`),
          type: String(img?.type || 'image/jpeg')
        })).filter((img) => img.dataUrl.startsWith('data:image/'));
      }
      postImages[idx] = imgs.slice(0, MAX_IMAGES_PER_POST);
      renderPostImages(idx);
    });
    updateCC();
  });
}

function applyBridgeTextToCompose(text) {
  applyBridgeComposeToEditor({ text });
}

function loadBridgeLanForm() {
  chrome.storage.local.get([IRISHKA_BRIDGE_CFG_KEY], (d) => {
    const cfg = d[IRISHKA_BRIDGE_CFG_KEY] || {};
    const en = document.getElementById('bridgeLanEnabled');
    const bu = document.getElementById('bridgeLanBaseUrl');
    const di = document.getElementById('bridgeLanDeviceId');
    const se = document.getElementById('bridgeLanSecret');
    if (en) en.checked = !!cfg.enabled;
    if (bu) bu.value = cfg.baseUrl || '';
    if (di) di.value = cfg.deviceId || '';
    if (se) se.value = cfg.sharedSecret || '';
  });
}

function saveBridgeLanForm() {
  const cfg = {
    enabled: !!document.getElementById('bridgeLanEnabled')?.checked,
    baseUrl: document.getElementById('bridgeLanBaseUrl')?.value.trim().replace(/\/$/, '') || '',
    deviceId: document.getElementById('bridgeLanDeviceId')?.value.trim() || '',
    sharedSecret: document.getElementById('bridgeLanSecret')?.value || '',
  };
  chrome.storage.local.set({ [IRISHKA_BRIDGE_CFG_KEY]: cfg }, () => {
    const h = document.getElementById('bridgeLanSaveHint');
    if (h) h.textContent = t('bridge_lan_saved_hint') || 'Guardado.';
    setTimeout(() => {
      if (h) h.textContent = '';
    }, 2500);
    chrome.runtime.sendMessage({ action: 'irishkaBridgePollNow' }, () => {});
  });
}

function consumeBridgePendingOnLoad() {
  chrome.storage.local.get([IRISHKA_BRIDGE_PENDING_KEY], (d) => {
    const p = d[IRISHKA_BRIDGE_PENDING_KEY];
    if (!p || (!p.text && !Array.isArray(p.images))) return;
    chrome.storage.local.remove(IRISHKA_BRIDGE_PENDING_KEY, () => {});
    applyBridgeComposeToEditor(p);
  });
}

function getJoinQueueTail(st) {
  const urls = Array.isArray(st?.urls) ? st.urls : [];
  const cursor = Math.max(0, Number(st?.cursor) || 0);
  return urls.slice(cursor).filter(Boolean);
}

function refreshJoinQueueStatePanel() {
  const wrap = document.getElementById('joinQueueStatusWrap');
  const summary = document.getElementById('joinQueueStatusSummary');
  const list = document.getElementById('joinQueueRemainingList');
  if (!wrap || !summary || !list) return;
  chrome.storage.local.get([JOIN_QUEUE_STORAGE_KEY], (d) => {
    const st = d[JOIN_QUEUE_STORAGE_KEY];
    const active = !!(st && st.active);
    wrap.hidden = !active;
    if (!active) {
      summary.textContent = '';
      list.innerHTML = '';
      return;
    }
    const urls = Array.isArray(st.urls) ? st.urls : [];
    const cursor = Math.max(0, Number(st.cursor) || 0);
    const done = Math.min(cursor, urls.length);
    const pending = getJoinQueueTail(st);
    summary.textContent =
      `Joined ${done}/${urls.length} · Today ${Number(st.joinedToday) || 0}/${Math.max(1, Number(st.dailyMax) || 1)} · Pending ${pending.length}`;
    list.innerHTML = '';
    if (!pending.length) {
      const row = document.createElement('div');
      row.className = 'empty-note';
      row.textContent = 'No pending groups.';
      list.appendChild(row);
      return;
    }
    pending.slice(0, 25).forEach((url) => {
      const row = document.createElement('div');
      row.className = 'empty-note';
      row.style.margin = '0';
      row.style.padding = '6px 8px';
      row.style.border = '1px solid var(--border)';
      row.style.borderRadius = '7px';
      row.style.background = 'var(--panel)';
      row.textContent = String(url);
      list.appendChild(row);
    });
  });
}

function initIrishkaBridgeLan() {
  loadBridgeLanForm();
  consumeBridgePendingOnLoad();
  document.getElementById('btnBridgeLanSave')?.addEventListener('click', saveBridgeLanForm);
  if (bridgeLanPollTimer) clearInterval(bridgeLanPollTimer);
  bridgeLanPollTimer = setInterval(() => {
    if (document.visibilityState !== 'visible') return;
    chrome.storage.local.get([IRISHKA_BRIDGE_CFG_KEY], (d) => {
      const cfg = d[IRISHKA_BRIDGE_CFG_KEY];
      if (!cfg || !cfg.enabled) return;
      chrome.runtime.sendMessage({ action: 'irishkaBridgePollNow' }, () => {});
    });
  }, 8000);
}

// Helpers
function qTabs(patterns) { return new Promise(r => chrome.tabs.query({ url: patterns }, r)); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/** Espera en trozos para que `abortPoll` corte en ~80ms. */
async function sleepAbortable(ms, abortPoll) {
  const ap = typeof abortPoll === 'function' ? abortPoll : null;
  const chunk = 80;
  let left = Math.max(0, Number(ms) || 0);
  while (left > 0) {
    if (ap && ap()) return;
    const step = Math.min(chunk, left);
    await sleep(step);
    left -= step;
  }
}
function buildLangBar() {
  const bar = document.getElementById('langBar');
  if (!bar || typeof LANG_FLAGS === 'undefined') return;
  const langs = APP_LANG_CODES.map((code) => {
    const flag = LANG_FLAGS[code] || '';
    return [code, (flag ? flag + ' ' : '') + code.toUpperCase()];
  });
  const saved = normalizeFartmilyLangCode(localStorage.getItem('fartmily_lang'));
  const sel = document.createElement('select');
  sel.id = 'langSelect';
  langs.forEach(([code, label]) => {
    const opt = document.createElement('option');
    opt.value = code;
    opt.textContent = label;
    if (code === saved) opt.selected = true;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', () => {
    applyLang(sel.value);
    loadGroupSets();
    loadTextPresets();
  });
  bar.appendChild(sel);
}

async function focusAppTab() {
  try {
    const appUrl = chrome.runtime.getURL('app.html');
    const tabs = await new Promise(r => chrome.tabs.query({ url: appUrl }, r));
    if (tabs && tabs[0]?.id) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId) await chrome.windows.update(tabs[0].windowId, { focused: true });
    }
  } catch (e) {}
}
function showConnected(on) {
  document.getElementById('stateOff').style.display = on ? 'none' : 'block';
  document.getElementById('stateOn').style.display = on ? 'block' : 'none';
}
function setPill(cls, name) {
  document.getElementById('connPill').className = 'conn-pill ' + cls;
  document.getElementById('connName').textContent = name;
}

/** Sync connection pill text after language change (keeps class, updates labels). */
function syncConnectionPillForLang() {
  const pill = document.getElementById('connPill');
  const nameEl = document.getElementById('connName');
  if (!pill || !nameEl) return;
  if (pill.classList.contains('checking')) nameEl.textContent = t('verifying');
  else if (pill.classList.contains('online')) nameEl.textContent = t('online_label');
  else if (pill.classList.contains('offline')) nameEl.textContent = t('no_connection');
}
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
