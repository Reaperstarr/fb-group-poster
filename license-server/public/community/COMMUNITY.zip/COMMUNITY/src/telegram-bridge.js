// ============================================================
// Irishka Group Master — Telegram bridge (service worker helper)
// ============================================================
(function () {
  'use strict';

  const TG_API = 'https://api.telegram.org/bot';
  const POLL_ALARM = 'irishka_tg_poll';
  const STATE_KEY = 'irishka_tg_state';
  let _config = { enabled: false, token: '', chatId: '', instanceName: 'Irishka' };
  let _handler = null;

  function pollAlarmName() {
    return POLL_ALARM;
  }

  function instanceName() {
    return String(_config.instanceName || 'Irishka').trim() || 'Irishka';
  }

  function isEnabled() {
    return !!_config.enabled && !!_config.token && !!_config.chatId;
  }

  async function init(storage) {
    const d = await storage.get(['settings']);
    const s = d.settings || {};
    _config = {
      enabled: !!s.tgEnabled,
      token: String(s.tgBotToken || '').trim(),
      chatId: String(s.tgChatId || '').trim(),
      instanceName: String(s.tgInstanceName || '').trim() || 'Irishka',
    };
  }

  function on(handler) {
    _handler = typeof handler === 'function' ? handler : null;
  }

  async function startPolling(alarms) {
    if (!isEnabled()) {
      await alarms.clear(POLL_ALARM);
      return;
    }
    alarms.create(POLL_ALARM, { periodInMinutes: 0.5 });
  }

  async function stopPolling(alarms) {
    await alarms.clear(POLL_ALARM);
  }

  async function readState(storage) {
    const d = await storage.get([STATE_KEY]);
    const st = d[STATE_KEY];
    if (!st || typeof st !== 'object') return { offset: 0 };
    return { offset: Number(st.offset) || 0 };
  }

  async function writeState(storage, st) {
    await storage.set({ [STATE_KEY]: st });
  }

  async function tgFetch(method, body) {
    const url = `${TG_API}${_config.token}/${method}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(body || {}),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const j = await res.json();
    if (!j.ok) throw new Error(j.description || 'Telegram API error');
    return j.result;
  }

  function parseCommand(update) {
    const msg = update.message || update.edited_message || null;
    if (msg && typeof msg.text === 'string' && msg.text.trim().startsWith('/')) {
      const raw = msg.text.trim().slice(1).toLowerCase();
      const command = raw.split(/\s+/)[0].split('@')[0];
      return { command, raw: msg.text, messageId: msg.message_id };
    }
    const cq = update.callback_query;
    if (cq && cq.data) {
      const raw = String(cq.data);
      const command = raw.includes(':') ? raw.split(':').slice(1).join(':') : raw;
      return { command: command.toLowerCase(), raw, messageId: cq.message?.message_id };
    }
    return null;
  }

  async function pollNow() {
    if (!isEnabled()) return;
    const st = await readState(chrome.storage.local);
    const updates = await tgFetch('getUpdates', {
      offset: st.offset,
      timeout: 0,
      limit: 20,
      allowed_updates: ['message', 'callback_query'],
    });
    let nextOffset = st.offset;
    for (const up of updates || []) {
      nextOffset = Math.max(nextOffset, Number(up.update_id || 0) + 1);
      const cmd = parseCommand(up);
      if (cmd && _handler) {
        await _handler({ ...cmd, instanceName: instanceName() });
      }
    }
    if (nextOffset !== st.offset) {
      await writeState(chrome.storage.local, { offset: nextOffset });
    }
  }

  async function sendMessage(text, extra) {
    if (!isEnabled()) return { ok: false, error: 'telegram disabled' };
    try {
      await tgFetch('sendMessage', {
        chat_id: _config.chatId,
        text: String(text || ''),
        parse_mode: 'HTML',
        disable_web_page_preview: true,
        ...(extra || {}),
      });
      return { ok: true };
    } catch (e) {
      return { ok: false, error: String(e?.message || e) };
    }
  }

  async function sendButtons(rows) {
    return sendMessage('Actions:', {
      reply_markup: { inline_keyboard: Array.isArray(rows) ? rows : [] },
    });
  }

  async function notifyAlert({ title, body }) {
    return sendMessage(`<b>[${instanceName()}] ${escapeHtml(title || 'Info')}</b>\n${escapeHtml(body || '')}`);
  }

  async function testConnection() {
    if (!isEnabled()) return { ok: false, error: 'Enable Telegram + token + chat ID' };
    return sendMessage(
      `<b>[${instanceName()}]</b> Telegram bridge connected.\nCommands: /status /resume /stop /help`
    );
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  self.TG = {
    init,
    on,
    startPolling,
    stopPolling,
    pollNow,
    pollAlarmName,
    notifyAlert,
    sendButtons,
    testConnection,
    instanceName,
  };
})();
