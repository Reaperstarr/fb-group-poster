/** Runs inside facebook.com tab via chrome.scripting.executeScript */
function detectFBLogin() {
  try {
    if (document.querySelector('#email, input[name="email"], [data-testid="royal_email"]')) {
      return { loggedIn: false, reason: 'Login form visible' };
    }
    if (window.location.pathname.startsWith('/login')) {
      return { loggedIn: false, reason: 'Login page' };
    }
    var UI_LABEL_DENY = {
      'editar perfil': 1, 'edit profile': 1, 'editar tu perfil': 1, 'modifier le profil': 1,
      'modifier votre profil': 1, 'profil bearbeiten': 1, 'modifica profilo': 1,
      'редактировать профиль': 1, 'profiel bewerken': 1, 'edytuj profil': 1, 'profili düzenle': 1,
      'ver perfil': 1, 'view profile': 1, 'voir le profil': 1, 'mi perfil': 1, 'your profile': 1,
      'tu perfil': 1, 'mon profil': 1, 'verified': 1, 'verificado': 1, 'verificada': 1,
      'account': 1, 'cuenta': 1
    };
    function cleanText(t) {
      if (!t) return false;
      var s = t.trim();
      if (s.length < 2 || s.length >= 60) return false;
      var low = s.toLowerCase();
      if (UI_LABEL_DENY[low]) return false;
      if (s.indexOf('Facebook') !== -1 || /^\d/.test(s) || s.indexOf('·') !== -1) return false;
      low = s.toLowerCase();
      if (low.indexOf('search') !== -1 || low.indexOf('buscar') !== -1) return false;
      return true;
    }
    function nameFromProfileLinks() {
      var selList = ['a[href*="/me"]', 'a[href*="profile.php"]', 'a[href^="/profile/"]', 'a[href*="/profile/"]'];
      for (var li = 0; li < selList.length; li++) {
        var anchors = document.querySelectorAll(selList[li]);
        for (var ai = 0; ai < anchors.length; ai++) {
          var spans = anchors[ai].querySelectorAll('span');
          for (var si = 0; si < spans.length; si++) {
            var raw = spans[si].textContent && spans[si].textContent.trim();
            if (raw && cleanText(raw)) return raw;
          }
          var imgAlt = anchors[ai].querySelector('img[alt]');
          if (imgAlt) {
            var altT = imgAlt.getAttribute('alt') && imgAlt.getAttribute('alt').trim();
            if (altT && cleanText(altT)) return altT;
          }
        }
      }
      return null;
    }
    var fromMe = nameFromProfileLinks();
    if (fromMe) return { loggedIn: true, name: fromMe };
    var blueBar = document.querySelector('[data-testid="blue_bar_profile_link"]');
    if (blueBar) {
      var bs = blueBar.querySelectorAll('span');
      for (var bi = 0; bi < bs.length; bi++) {
        var br = bs[bi].textContent && bs[bi].textContent.trim();
        if (br && cleanText(br)) return { loggedIn: true, name: br };
      }
    }
    var profileSels = [
      'a[aria-label*="perfil"] span', 'a[aria-label*="profile"] span', 'a[aria-label*="cuenta"] span'
    ];
    for (var pi = 0; pi < profileSels.length; pi++) {
      var el = document.querySelector(profileSels[pi]);
      if (el && cleanText(el.textContent)) return { loggedIn: true, name: el.textContent.trim() };
    }
    var nav = document.querySelector('[role="banner"], [data-pagelet="NavBar"], header');
    if (nav) {
      var spans = nav.querySelectorAll('span');
      for (var ni = 0; ni < spans.length; ni++) {
        var t = spans[ni].textContent && spans[ni].textContent.trim();
        if (cleanText(t) && t.split(' ').length >= 1 && t.split(' ').length <= 5) {
          return { loggedIn: true, name: t };
        }
      }
    }
    var hasMain = document.querySelector(
      '[role="main"], [data-pagelet="GroupFeed"], [data-pagelet="ProfileTimeline"], [data-pagelet="Feed"]'
    );
    if (hasMain) return { loggedIn: true, name: null };
    if (document.cookie.includes('c_user=')) return { loggedIn: true, name: null };
    return { loggedIn: false, reason: 'Not logged in' };
  } catch (e) {
    return { loggedIn: false, reason: e.message };
  }
}

function detectGroupPostabilityInPage() {
  function countByPatterns(text, regexes) {
    let max = 0;
    (regexes || []).forEach(re => {
      const m = String(text || '').match(re);
      if (m) max = Math.max(max, Number(m[1]) || 0);
    });
    return max;
  }
  /** True if this node or an ancestor is explicitly disabled (composer bloqueado). */
  function isDisabledInChain(el, maxDepth) {
    let n = el;
    for (let d = 0; d < (maxDepth || 8) && n; d++) {
      if (n.getAttribute && n.getAttribute('aria-disabled') === 'true') return true;
      if (n.disabled) return true;
      n = n.parentElement;
    }
    return false;
  }
  function extractPendingPostsCount() {
    const samples = [];
    const nodes = document.querySelectorAll(
      'a[href*="pending"], a[href*="pending_posts"], [aria-label*="pendiente" i], [aria-label*="pending" i]'
    );
    nodes.forEach(n => {
      const t = ((n.textContent || '') + ' ' + (n.getAttribute('aria-label') || '')).trim();
      if (t) samples.push(t);
      const p = n.parentElement?.textContent || '';
      if (p) samples.push(p);
    });
    samples.push(document.body?.innerText || '');

    const patterns = [
      /publicaciones pendientes\D{0,25}(\d{1,4})/i,
      /pending posts\D{0,25}(\d{1,4})/i,
      /(\d{1,4})\D{0,25}publicaciones pendientes/i,
      /(\d{1,4})\D{0,25}pending posts/i
    ];
    let max = 0;
    for (const s of samples) {
      for (const re of patterns) {
        const m = s.match(re);
        if (m) max = Math.max(max, Number(m[1]) || 0);
      }
    }
    // If FB shows only text without number ("tienes publicaciones pendientes"), mark as 1.
    if (max === 0) {
      const joined = samples.join(' ').toLowerCase();
      if (
        joined.includes('publicaciones pendientes') ||
        joined.includes('publicacion pendiente') ||
        joined.includes('pending post') ||
        joined.includes('pending posts')
      ) {
        max = 1;
      }
    }
    return max;
  }

  const bodyText = (document.body?.innerText || '').slice(0, 120000).toLowerCase();
  const visibleButtons = Array.from(document.querySelectorAll('[role=button],button,a[role=button]')).filter((el) => el && el.offsetParent);
  const toBtnText = (el) => ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
  const joinHints = [
    'join group', 'join', 'request to join', 'ask to join', 'unirse', 'unirte al grupo',
    'unirse al grupo', 'solicitar unirse', 'participar', 'rejoindre', 'beitreten'
  ];
  const memberHints = [
    "you're a member", 'you are a member', 'member of this group', 'joined',
    'eres miembro', 'miembro del grupo', 'ya eres miembro', 'abandonar grupo',
    'leave group', 'salir del grupo'
  ];
  const joinControlVisible = visibleButtons.some((el) => {
    const txt = toBtnText(el);
    return joinHints.some((hint) => txt.includes(hint));
  });
  const memberHintVisible = visibleButtons.some((el) => {
    const txt = toBtnText(el);
    return memberHints.some((hint) => txt.includes(hint));
  });
  const memberHintInBody = memberHints.some((hint) => bodyText.includes(hint));
  const isMember = joinControlVisible ? false : ((memberHintVisible || memberHintInBody) ? true : null);
  const moderationStats = {
    pending: extractPendingPostsCount(),
    approved: countByPatterns(bodyText, [/aprobad[oa]s?\D{0,25}(\d{1,4})/i, /approved\D{0,25}(\d{1,4})/i]),
    rejected: countByPatterns(bodyText, [/rechazad[oa]s?\D{0,25}(\d{1,4})/i, /rejected\D{0,25}(\d{1,4})/i, /declined\D{0,25}(\d{1,4})/i]),
    deleted: countByPatterns(bodyText, [/eliminad[oa]s?\D{0,25}(\d{1,4})/i, /deleted\D{0,25}(\d{1,4})/i, /removed\D{0,25}(\d{1,4})/i])
  };

  // 1) Mensajes explícitos de que NO se puede publicar (prioridad sobre cualquier otro indicio).
  const cannotPostRes = [
    /only admins (and moderators)? can post/i,
    /only administrators can post/i,
    /only admins can share/i,
    /solo los administradores pueden publicar/i,
    /solo administradores pueden publicar/i,
    /solo admins? pueden publicar/i,
    /solo el (equipo de )?administraci[oó]n puede publicar/i,
    /posting (has been )?turned off/i,
    /publicar (est[aá] )?desactivad[oa]/i,
    /you can'?t post (here|in this group)/i,
    /no puedes publicar/i,
    /parece que no puedes publicar/i,
    /it looks like you can'?t post/i,
    /members can'?t post/i,
    /los miembros no pueden publicar/i,
    /participantes no pueden (crear )?publicaci[oó]n(es)?/i,
    /this group doesn'?t allow members to post/i,
    /este grupo no permite que (los )?miembros publiquen/i,
    /posting is (limited|disabled|off|closed)/i,
    /no se puede publicar (aqu[ií]|en este grupo)/i,
    /can'?t share (in|to) this group/i,
    /no se permite publicar/i,
    /group (posting )?is closed/i,
    /publicaciones? (cerradas|restringidas)/i,
    /you don'?t have permission to post/i,
    /no tienes permiso para publicar/i,
    /your ability to post has been turned off/i,
    /se ha desactivado tu capacidad de publicar/i,
    /apenas (admins|administradores) podem postar/i,
    /somente administradores podem publicar/i,
    /seuls les administrateurs peuvent publier/i,
    /nur admins? k[öo]nnen posten/i,
    /solo gli amministratori possono pubblicare/i,
    /только администраторы могут публиковать/i,
    /alleen (beheerders|admins) kunnen plaatsen/i,
    /tylko administratorzy mogą publikować/i,
    /yalnızca yöneticiler gönderebilir/i
  ];
  for (const re of cannotPostRes) {
    if (re.test(bodyText)) {
      return { canPost: false, isMember, pendingPostsCount: moderationStats.pending, moderationStats };
    }
  }
  const cannotSnippets = [
    'posting has been turned off for this group',
    'publicar está desactivado',
    'only admins can post in this group',
    'los administradores son los únicos que pueden publicar',
    'members aren’t allowed to post',
    'members are not allowed to post',
    'no puedes escribir en este grupo',
    'you’re not allowed to post',
    'you are not allowed to post',
    'posting is unavailable',
    'no está disponible publicar'
  ];
  for (const s of cannotSnippets) {
    if (bodyText.includes(s)) {
      return { canPost: false, isMember, pendingPostsCount: moderationStats.pending, moderationStats };
    }
  }

  const words = [
    'escribe algo', 'write something', 'create a post', 'crear publicación', 'crear publicacion',
    'nueva discusion', 'new discussion', "what's on your mind", 'qué estás pensando', 'que estas pensando',
    'photo/video', 'foto/vídeo', 'foto/video', 'publicar en el grupo', 'post in group'
  ];
  const selectors = ['[role=button]', '[role=textbox]', '[contenteditable=true]'];
  for (const sel of selectors) {
    const nodes = document.querySelectorAll(sel);
    for (const el of nodes) {
      if (!el.offsetParent) continue;
      if (isDisabledInChain(el)) continue;
      const txt = ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('data-placeholder') || '')).toLowerCase();
      if (words.some(w => txt.includes(w))) {
        return { canPost: true, isMember, pendingPostsCount: moderationStats.pending, moderationStats };
      }
    }
  }

  // Sin el antiguo fallback "eres miembro" → evita marcar OK grupos donde solo admins publican.

  return { canPost: false, isMember, pendingPostsCount: moderationStats.pending, moderationStats };
}
