/* global LEGAL_I18N */
(function () {
  'use strict';

  const LANG_KEY = 'fartmily_lang';
  const LANG_ORDER = [
    'en', 'es', 'pt', 'fr', 'de', 'it', 'ru', 'nl', 'pl', 'tr',
    'hi', 'tl', 'ur', 'bn', 'id', 'ha', 'ar', 'vi', 'ro'
  ];

  function normalizeLegalLang(code) {
    const c = String(code || '').toLowerCase();
    if (LANG_ORDER.indexOf(c) !== -1) return c;
    return 'en';
  }

  function getLang() {
    const params = new URLSearchParams(window.location.search || '');
    const q = normalizeLegalLang(params.get('lang') || '');
    if (q && LEGAL_I18N[q]) return q;
    try {
      const s = normalizeLegalLang(localStorage.getItem(LANG_KEY));
      if (LEGAL_I18N[s]) return s;
    } catch (e) {}
    return 'en';
  }

  function renderLegal(lang) {
    const L = LEGAL_I18N[lang] || LEGAL_I18N.en;
    document.documentElement.lang = lang;
    document.title = L.pageTitle;

    const h1 = document.getElementById('legalH1');
    if (h1) h1.textContent = L.h1;

    const nav = document.getElementById('legalNav');
    if (nav) {
      nav.innerHTML =
        '<a href="#terminos">' +
        escapeHtml(L.navTerms) +
        '</a>' +
        '<a href="#aviso">' +
        escapeHtml(L.navDisclaimer) +
        '</a>' +
        '<a href="#privacidad">' +
        escapeHtml(L.navPrivacy) +
        '</a>';
    }

    const meta = document.getElementById('legalMeta');
    if (meta) meta.textContent = L.meta;

    const secT = document.getElementById('terminos');
    if (secT) secT.innerHTML = L.termsHtml || '';
    const secA = document.getElementById('aviso');
    if (secA) secA.innerHTML = L.disclaimerHtml || '';
    const secP = document.getElementById('privacidad');
    if (secP) secP.innerHTML = L.privacyHtml || '';

    const back = document.getElementById('legalBack');
    if (back) {
      back.textContent = L.backApp;
      back.href = 'app.html';
    }
  }

  function escapeHtml(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function buildLangBar(current) {
    const bar = document.getElementById('legalLangBar');
    if (!bar) return;
    bar.className = 'legal-lang-bar';
    bar.innerHTML = '';
    const label = document.createElement('span');
    label.className = 'legal-lang-bar-label';
    label.textContent =
      (LEGAL_I18N[current] && LEGAL_I18N[current].langPickerLabel) || 'Language';
    bar.appendChild(label);
    LANG_ORDER.forEach((code) => {
      if (!LEGAL_I18N[code]) return;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'legal-lang-btn' + (code === current ? ' legal-lang-btn--active' : '');
      btn.dataset.lang = code;
      btn.textContent = (typeof LANG_FLAGS !== 'undefined' && LANG_FLAGS[code] ? LANG_FLAGS[code] + ' ' : '') + code.toUpperCase();
      btn.addEventListener('click', () => {
        try {
          localStorage.setItem(LANG_KEY, code);
        } catch (e) {}
        try {
          chrome.storage.local.set({ [LANG_KEY]: code });
        } catch (e) {}
        renderLegal(code);
        buildLangBar(code);
        try {
          const u = new URL(window.location.href);
          u.searchParams.set('lang', code);
          window.history.replaceState({}, '', u.pathname + u.search);
        } catch (e) {}
      });
      bar.appendChild(btn);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    const lang = getLang();
    renderLegal(lang);
    buildLangBar(lang);
  });
})();
