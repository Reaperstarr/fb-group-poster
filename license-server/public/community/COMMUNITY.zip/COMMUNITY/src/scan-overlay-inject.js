/* Injected into Facebook tabs during group scan (executeScript files). */
(function () {
  if (window.fartmilyScanOverlayInit) return;

  window.fartmilyScanOverlayInit = function (pleaseWait, detLab, timeLab, deadlineMs) {
    var rid = 'igs-scan-overlay';
    if (document.getElementById(rid)) return;
    if (window.__igsScanIv) {
      clearInterval(window.__igsScanIv);
      window.__igsScanIv = null;
    }
    var root = document.createElement('div');
    root.id = rid;
    root.style.cssText = 'position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;background:rgba(6,22,58,.72);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)';
    var box = document.createElement('div');
    box.style.cssText = 'background:linear-gradient(180deg,rgba(10,28,70,.98),rgba(10,18,42,.98));color:#eef4ff;border:2px solid rgba(59,130,246,.95);border-radius:16px;padding:28px 36px;min-width:min(360px,92vw);max-width:92vw;text-align:center;box-shadow:0 20px 56px rgba(0,0,0,.55),0 0 0 2px rgba(96,165,250,.25) inset;font:15px/1.5 system-ui,Segoe UI,Roboto,sans-serif';
    var h = document.createElement('div');
    h.style.cssText = 'font-weight:800;font-size:18px;color:#93c5fd;margin-bottom:14px';
    h.textContent = pleaseWait;
    var det = document.createElement('div');
    det.id = 'igs-scan-groups';
    det.style.cssText = 'margin-top:6px;color:#c9dcff;font-size:14px';
    det.textContent = detLab + ' 0';
    var timeRow = document.createElement('div');
    timeRow.style.cssText = 'margin-top:16px;font-size:15px;font-weight:700;color:#bfdbfe';
    var spanLabel = document.createElement('span');
    spanLabel.textContent = timeLab + ' ';
    var spanSec = document.createElement('span');
    spanSec.id = 'igs-scan-sec';
    spanSec.style.cssText = 'font-variant-numeric:tabular-nums;font-size:24px;color:#ffffff';
    spanSec.textContent = '—';
    var spanSuf = document.createElement('span');
    spanSuf.textContent = ' s';
    timeRow.appendChild(spanLabel);
    timeRow.appendChild(spanSec);
    timeRow.appendChild(spanSuf);
    box.appendChild(h);
    box.appendChild(det);
    box.appendChild(timeRow);
    root.appendChild(box);
    document.body.appendChild(root);
    var tick = function () {
      var leftSec = (deadlineMs - Date.now()) / 1000;
      var disp = leftSec <= 0 ? 0 : Math.ceil(leftSec);
      var s = document.getElementById('igs-scan-sec');
      if (s) s.textContent = String(disp);
      if (leftSec <= 0 && window.__igsScanIv) {
        clearInterval(window.__igsScanIv);
        window.__igsScanIv = null;
      }
    };
    window.__igsScanIv = setInterval(tick, 250);
    tick();
  };

  window.fartmilyScanOverlayUpdateDetected = function (count, detLab) {
    var g = document.getElementById('igs-scan-groups');
    if (g) g.textContent = detLab + ' ' + count;
  };

  window.fartmilyScanOverlayRemove = function () {
    try {
      if (window.__igsScanIv) {
        clearInterval(window.__igsScanIv);
        window.__igsScanIv = null;
      }
    } catch (e) {}
    var b = document.getElementById('igs-scan-overlay');
    if (b) b.remove();
  };
})();
