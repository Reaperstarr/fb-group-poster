/**
 * Build community (privada): IGM_COMMUNITY_FREE=true.
 * El script package-irishka-community.sh copia esto como build-flags.js dentro del zip.
 */
var IGM_COMMUNITY_FREE = true;
