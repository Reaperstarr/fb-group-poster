/**
 * Persistencia de capas de imágenes del poster en IndexedDB (mismo origen chrome-extension://).
 * Sobrevive a actualización/reload de la extensión y evita el techo de cuota de chrome.storage.local.
 * Usable desde service worker (background) y páginas de extensión (app.html, popup).
 */
(function (root) {
  var DB_NAME = 'irishka_poster_layers_v1';
  var DB_VERSION = 1;
  var STORE = 'layers';
  var KEY_CURRENT = 'current';

  function openDb() {
    return new Promise(function (resolve, reject) {
      try {
        var idb = root.indexedDB;
        if (!idb) {
          reject(new Error('indexeddb_unavailable'));
          return;
        }
        var req = idb.open(DB_NAME, DB_VERSION);
        req.onerror = function () {
          reject(req.error || new Error('idb_open_failed'));
        };
        req.onupgradeneeded = function () {
          var db = req.result;
          if (!db.objectStoreNames.contains(STORE)) {
            db.createObjectStore(STORE);
          }
        };
        req.onsuccess = function () {
          resolve(req.result);
        };
      } catch (e) {
        reject(e);
      }
    });
  }

  function posterImageIdbSaveLayers(layers) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          tx.oncomplete = function () {
            try {
              db.close();
            } catch (_) {}
            resolve(true);
          };
          tx.onerror = function () {
            try {
              db.close();
            } catch (_) {}
            reject(tx.error || new Error('idb_tx_failed'));
          };
          tx.objectStore(STORE).put({ layers: layers, savedAt: Date.now() }, KEY_CURRENT);
        } catch (e) {
          try {
            db.close();
          } catch (_) {}
          reject(e);
        }
      });
    });
  }

  function posterImageIdbLoadLayers() {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        try {
          var tx = db.transaction(STORE, 'readonly');
          var req = tx.objectStore(STORE).get(KEY_CURRENT);
          req.onsuccess = function () {
            var rec = req.result;
            var layers = rec && Array.isArray(rec.layers) ? rec.layers : null;
            try {
              db.close();
            } catch (_) {}
            resolve(layers && layers.length ? layers : null);
          };
          req.onerror = function () {
            try {
              db.close();
            } catch (_) {}
            reject(req.error || new Error('idb_get_failed'));
          };
        } catch (e) {
          try {
            db.close();
          } catch (_) {}
          reject(e);
        }
      });
    });
  }

  function posterImageIdbClear() {
    return openDb().then(function (db) {
      return new Promise(function (resolve) {
        try {
          var tx = db.transaction(STORE, 'readwrite');
          tx.oncomplete = function () {
            try {
              db.close();
            } catch (_) {}
            resolve(true);
          };
          tx.onerror = function () {
            try {
              db.close();
            } catch (_) {}
            resolve(false);
          };
          tx.objectStore(STORE).delete(KEY_CURRENT);
        } catch (e) {
          try {
            db.close();
          } catch (_) {}
          resolve(false);
        }
      });
    });
  }

  root.posterImageIdbSaveLayers = posterImageIdbSaveLayers;
  root.posterImageIdbLoadLayers = posterImageIdbLoadLayers;
  root.posterImageIdbClear = posterImageIdbClear;
})(typeof self !== 'undefined' ? self : this);
