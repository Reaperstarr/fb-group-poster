/**
 * Hosts used for chrome.tabs.query. Apex (facebook.com) and m.facebook.com were missing,
 * so users with those URLs open saw "no Facebook tab" even when logged in.
 */
var FACEBOOK_TAB_URL_PATTERNS = [
  '*://www.facebook.com/*',
  '*://web.facebook.com/*',
  '*://facebook.com/*',
  '*://m.facebook.com/*'
];

function pickBestFacebookTabSync(tabs, activeTab) {
  if (!tabs || !tabs.length) return null;
  if (activeTab && activeTab.id != null) {
    for (var i = 0; i < tabs.length; i++) {
      if (tabs[i].id === activeTab.id) return activeTab;
    }
  }
  var sorted = tabs.slice().sort(function (a, b) {
    return (b.lastAccessed || 0) - (a.lastAccessed || 0);
  });
  return sorted[0] || tabs[0];
}

/** Prefer the focused Facebook tab in this window, else most recently used. */
function pickBestFacebookTab(tabs) {
  if (!tabs || !tabs.length) return Promise.resolve(null);
  return new Promise(function (resolve) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (aw) {
      resolve(pickBestFacebookTabSync(tabs, aw && aw[0]));
    });
  });
}
