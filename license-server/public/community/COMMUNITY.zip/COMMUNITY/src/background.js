importScripts('build-flags.js');
importScripts('poster-image-idb.js');
importScripts('facebook-host.js');
importScripts('facebook-detect.js');
importScripts('telegram-bridge.js');
importScripts('fleet-hub-client.js');

function isCommunityFreeBuildBg() {
  return typeof IGM_COMMUNITY_FREE !== 'undefined' && IGM_COMMUNITY_FREE;
}

/** Primero timeline del usuario (facebook.com/me); solo build community. */
function makeProfileTimelineSlotBg() {
  return {
    name: 'My profile (timeline)',
    url: 'https://www.facebook.com/me',
    selected: true,
    canPost: true,
    isProfileTimelineSlot: true
  };
}

function groupsForProgressBroadcast(groups) {
  if (!Array.isArray(groups)) return [];
  return groups.map((g) => ({
    name: g.name,
    url: g.url,
    isProfileTimelineSlot: !!g.isProfileTimelineSlot
  }));
}

/** Same key as src/i18n.js — synced when user changes language in the app. */
const LANG_KEY_BG = 'fartmily_lang';
const MAX_POST_IMAGES = 3;

function notificationFinishMessage(lang, ok, total) {
  const M = {
    en: 'Done: {ok}/{total} posts published.',
    es: 'Completado: {ok}/{total} posts publicados.',
    pt: 'Concluído: {ok}/{total} posts publicados.',
    fr: 'Terminé : {ok}/{total} posts publiés.',
    de: 'Fertig: {ok}/{total} Beiträge veröffentlicht.',
    it: 'Completato: {ok}/{total} post pubblicati.',
    ru: 'Готово: {ok}/{total} публикаций.',
    nl: 'Klaar: {ok}/{total} posts gepubliceerd.',
    pl: 'Gotowe: {ok}/{total} postów opublikowanych.',
    tr: 'Tamamlandı: {ok}/{total} gönderi yayınlandı.',
    hi: 'पूर्ण: {ok}/{total} पोस्ट प्रकाशित।',
    tl: 'Tapos: {ok}/{total} na-publish na post.',
    ur: 'مکمل: {ok}/{total} پوسٹس شائع ہوئیں۔',
    bn: 'সম্পন্ন: {ok}/{total}টি পোস্ট প্রকাশিত।',
    id: 'Selesai: {ok}/{total} postingan dipublikasikan.',
    ha: 'An gama: {ok}/{total} posts an wallafa.',
    ar: 'تم: تم نشر {ok}/{total} من المنشورات.',
    vi: 'Xong: đã đăng {ok}/{total} bài.',
    ro: 'Gata: {ok}/{total} postări publicate.'
  };
  return (M[lang] || M.en).replace(/\{ok\}/g, String(ok)).replace(/\{total\}/g, String(total));
}

const PENDING_UPDATE_RELOAD_KEY = 'fartmily_pending_update_reload';
const UPDATE_FROM_VER_KEY = 'fartmily_update_from_version';

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason !== 'update') return;
  const to = chrome.runtime.getManifest().version;
  const from = details.previousVersion || '';
  chrome.storage.local.set({
    [PENDING_UPDATE_RELOAD_KEY]: true,
    [UPDATE_FROM_VER_KEY]: from,
    fartmily_update_to_version: to
  });
});

// Open app as tab when icon clicked
chrome.action.onClicked.addListener(() => {
  const appUrl = chrome.runtime.getURL('app.html');
  chrome.tabs.query({ url: appUrl }, (tabs) => {
    if (tabs.length > 0) {
      chrome.tabs.update(tabs[0].id, { active: true });
      chrome.windows.update(tabs[0].windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: appUrl, active: true });
    }
  });
});

// Spintax engine
function spinText(text) {
  let result = text, passes = 20;
  while (passes-- > 0) {
    const prev = result;
    result = result.replace(/\{([^{}]+)\}/g, (_, inner) => {
      const opts = inner.split('|');
      return opts[Math.floor(Math.random() * opts.length)];
    });
    if (result === prev) break;
  }
  return result;
}

let posterRunning = false;
let stopRequested = false;
let runState = null;
const RUNSTATE_KEY = 'poster_run_state';
/** Cola de “Unirse a grupos” con tope diario y reanudación a la hora fija. */
const JOIN_QUEUE_KEY = 'irishka_join_queue_v1';
/** Imágenes grandes: payload en session storage; local solo metadatos (evita kQuotaBytes). */
const POSTER_SESSION_IMAGES_KEY = 'fartmily_poster_session_images';
/** Respaldo durable para sobrevivir reload/update de extensión. */
const POSTER_PERSISTED_IMAGES_KEY = 'fartmily_poster_persisted_images';
const PAUSE_BEFORE_PUBLISH = false; // Pausa desactivada por defecto.
const LICENSE_BG_LICENSE_KEY = 'proLicenseKey';
const LICENSE_BG_STATUS_KEY = 'proLicenseStatus';
const LICENSE_BG_INSTALL_KEY = 'installDeviceId';
const LICENSE_BG_VALIDATE_URL = 'https://fb-group-poster-production.up.railway.app/api/license/validate';

function bgNormalizeLicenseKey(input) {
  const hex = String(input || '').replace(/[^0-9a-fA-F]/g, '').toUpperCase();
  if (hex.length === 16) return hex;
  if (hex.length > 16) return hex.slice(0, 16);
  return '';
}

function bgMakeInstallId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function bgGetOrCreateInstallId() {
  const data = await chrome.storage.local.get([LICENSE_BG_INSTALL_KEY]);
  let id = String(data[LICENSE_BG_INSTALL_KEY] || '').trim();
  if (!id) {
    id = bgMakeInstallId();
    await chrome.storage.local.set({ [LICENSE_BG_INSTALL_KEY]: id });
  }
  return id;
}

async function runLicenseCheckAlarm() {
  if (typeof IGM_COMMUNITY_FREE !== 'undefined' && IGM_COMMUNITY_FREE) return;
  const data = await chrome.storage.local.get([LICENSE_BG_LICENSE_KEY]);
  const key = bgNormalizeLicenseKey(data[LICENSE_BG_LICENSE_KEY] || '');
  if (!key) return;
  const deviceId = await bgGetOrCreateInstallId();
  const ctrl = new AbortController();
  const timeout = setTimeout(() => ctrl.abort(), 12000);
  let res;
  try {
    res = await fetch(LICENSE_BG_VALIDATE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        licenseKey: key,
        deviceId,
        app: 'irishka-group-master',
        source: 'chrome-extension'
      }),
      signal: ctrl.signal
    });
  } catch {
    clearTimeout(timeout);
    return;
  }
  clearTimeout(timeout);
  if (!res.ok) return;
  let j = {};
  try {
    j = await res.json();
  } catch {
    return;
  }
  const valid = Boolean(j.valid ?? j.ok ?? j.active);
  const status = {
    valid,
    checkedAt: new Date().toISOString(),
    plan: j.plan || j.tier || '',
    message: j.message || '',
    code: j.code || ''
  };
  await chrome.storage.local.set({ [LICENSE_BG_LICENSE_KEY]: key, [LICENSE_BG_STATUS_KEY]: status });
}

function ensureLicenseRecheckAlarm() {
  if (typeof IGM_COMMUNITY_FREE !== 'undefined' && IGM_COMMUNITY_FREE) {
    chrome.alarms.clear('irishka_license_check');
    return;
  }
  chrome.alarms.create('irishka_license_check', { periodInMinutes: 15 });
}

chrome.runtime.onInstalled.addListener(() => {
  ensureLicenseRecheckAlarm();
  scheduleIrishkaBridgeAlarm().catch(() => {});
  recoverPostingAfterExtensionReload().catch(() => {});
  initRemoteControl().catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  ensureLicenseRecheckAlarm();
  scheduleIrishkaBridgeAlarm().catch(() => {});
  recoverPostingAfterExtensionReload().catch(() => {});
  initRemoteControl().catch(() => {});
});

async function isFleetHubMode() {
  const d = await chrome.storage.local.get(['settings']);
  return !!(d.settings || {}).fleetHubEnabled;
}

async function initRemoteControl() {
  if (typeof FLEET !== 'undefined') {
    await FLEET.init(chrome.storage.local);
    FLEET.onCommand(handleFleetCommand);
    if (FLEET.isEnabled()) {
      if (typeof TG !== 'undefined') await TG.stopPolling(chrome.alarms);
      await FLEET.startSync(chrome.alarms);
      const ver = chrome.runtime.getManifest().version;
      FLEET.syncNow(chrome.storage.local, RUNSTATE_KEY, ver).catch(() => {});
      return;
    }
    await FLEET.stopSync(chrome.alarms);
  }
  await initTelegramBridge();
}

async function initTelegramBridge() {
  if (typeof TG === 'undefined') return;
  if (await isFleetHubMode()) return;
  await TG.init(chrome.storage.local);
  TG.on(handleTelegramCommand);
  await TG.startPolling(chrome.alarms);
}

async function queryFacebookTabs() {
  return chrome.tabs.query({ url: FACEBOOK_TAB_URL_PATTERNS });
}

/** Cierra pestañas Facebook duplicadas; deja una (worker si publica, si no la más reciente). */
async function consolidateFacebookTabs(preferredTabId) {
  const tabs = await queryFacebookTabs();
  if (tabs.length <= 1) {
    return { kept: tabs[0] || null, closed: 0, tabCount: tabs.length };
  }
  const workerId = runState?.workerTabId || null;
  let keep = null;
  if (workerId && posterRunning) {
    keep = tabs.find((t) => t.id === workerId) || null;
  }
  if (!keep && preferredTabId) {
    keep = tabs.find((t) => t.id === preferredTabId) || null;
  }
  if (!keep) {
    keep = await pickBestFacebookTab(tabs);
  }
  if (!keep?.id) {
    return { kept: null, closed: 0, tabCount: tabs.length };
  }
  let closed = 0;
  for (const t of tabs) {
    if (!t?.id || t.id === keep.id) continue;
    try {
      await chrome.tabs.remove(t.id);
      closed++;
    } catch (_) {}
  }
  return { kept: keep, closed, tabCount: Math.max(1, tabs.length - closed) };
}

async function probeFacebookForFleet() {
  try {
    let tabs = await queryFacebookTabs();
    if (tabs.length > 1) {
      const pref = runState?.workerTabId || null;
      await consolidateFacebookTabs(pref);
      tabs = await queryFacebookTabs();
    }
    if (!tabs.length) {
      return { connected: false, userName: '', tabCount: 0, reason: 'No Facebook tab open' };
    }
    const tab = await pickBestFacebookTab(tabs);
    if (!tab?.id) {
      return { connected: false, userName: '', tabCount: tabs.length, reason: 'No Facebook tab' };
    }
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: detectFBLogin,
    });
    const loginInfo = res?.[0]?.result;
    if (loginInfo?.loggedIn) {
      return {
        connected: true,
        userName: loginInfo.name || '',
        tabCount: tabs.length,
        tabId: tab.id,
        windowId: tab.windowId,
        reason: '',
      };
    }
    return {
      connected: false,
      userName: '',
      tabCount: tabs.length,
      reason: loginInfo?.reason || 'Not logged in',
    };
  } catch (e) {
    return { connected: false, userName: '', tabCount: 0, reason: String(e?.message || e).slice(0, 120) };
  }
}

const FLEET_SCREENSHOT_MAX_B64 = 900000;

async function sleepMs(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function chromeErrMsg(err) {
  return String(err?.message || err || '');
}

function isTabEditBlockedMsg(msg) {
  return /cannot be edited|dragging a tab/i.test(String(msg || ''));
}

function chromeTabsApi(apiFn, ...args) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const done = (fn, val) => {
      if (settled) return;
      settled = true;
      fn(val);
    };
    try {
      const ret = apiFn(...args, (result) => {
        const err = chrome.runtime.lastError;
        if (err) done(reject, new Error(err.message));
        else done(resolve, result);
      });
      if (ret && typeof ret.then === 'function') {
        ret.then((v) => done(resolve, v)).catch((e) => done(reject, e));
      }
    } catch (e) {
      done(reject, e);
    }
  });
}

async function tryCaptureTabDirect(tabId, quality) {
  if (typeof chrome.tabs.captureTab !== 'function') {
    return { dataUrl: null, err: 'captureTab unavailable' };
  }
  const options = { format: 'jpeg', quality };
  try {
    const maybe = chrome.tabs.captureTab(tabId, options);
    if (maybe && typeof maybe.then === 'function') {
      const dataUrl = await maybe;
      if (dataUrl && typeof dataUrl === 'string') return { dataUrl, err: null };
    }
  } catch (e) {
    const msg = chromeErrMsg(e);
    if (msg) return { dataUrl: null, err: msg };
  }
  try {
    const dataUrl = await chromeTabsApi(chrome.tabs.captureTab, tabId, options);
    if (dataUrl && typeof dataUrl === 'string') return { dataUrl, err: null };
    return { dataUrl: null, err: 'empty captureTab result' };
  } catch (e) {
    return { dataUrl: null, err: chromeErrMsg(e) || 'captureTab failed' };
  }
}

async function tryCaptureVisibleWindow(tab, quality) {
  if (tab.windowId == null) return { dataUrl: null, err: 'missing windowId' };
  try {
    const dataUrl = await chromeTabsApi(
      chrome.tabs.captureVisibleTab,
      tab.windowId,
      { format: 'jpeg', quality }
    );
    if (dataUrl && typeof dataUrl === 'string') return { dataUrl, err: null };
    return { dataUrl: null, err: 'empty captureVisibleTab result' };
  } catch (e) {
    return { dataUrl: null, err: chromeErrMsg(e) || 'captureVisibleTab failed' };
  }
}

async function waitTabReady(tabId, maxMs = 10000) {
  let tab = await chrome.tabs.get(tabId);
  if (tab.status === 'complete') return tab;
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(onUpd);
      clearTimeout(timer);
      chrome.tabs.get(tabId).then(resolve).catch(() => resolve(tab));
    };
    const onUpd = (id, info) => {
      if (id === tabId && info.status === 'complete') finish();
    };
    chrome.tabs.onUpdated.addListener(onUpd);
    const timer = setTimeout(finish, maxMs);
  });
}

async function prepareWindowAndTabForCapture(tab) {
  let current = tab;
  if (current.windowId != null) {
    try {
      const win = await chrome.windows.get(current.windowId);
      if (win.state === 'minimized') {
        await chromeTabsApi(chrome.windows.update, current.windowId, { state: 'normal', focused: true });
        await sleepMs(500);
      } else {
        await chromeTabsApi(chrome.windows.update, current.windowId, { focused: true, drawAttention: false });
        await sleepMs(300);
      }
    } catch (e) {
      if (!isTabEditBlockedMsg(chromeErrMsg(e))) throw e;
      await sleepMs(700);
    }
  }
  current = await activateTabForCapture(current);
  current = await waitTabReady(current.id);
  await sleepMs(900);
  return current;
}

async function activateTabForCapture(tab) {
  let current = tab;
  for (let attempt = 0; attempt < 6; attempt++) {
    try {
      current = await chrome.tabs.get(current.id);
    } catch (e) {
      throw new Error(chromeErrMsg(e) || 'Tab closed');
    }
    if (current.active) return current;
    try {
      await chromeTabsApi(chrome.tabs.update, current.id, { active: true });
      await sleepMs(250 + attempt * 200);
      current = await chrome.tabs.get(current.id);
      if (current.active) return current;
    } catch (e) {
      const msg = chromeErrMsg(e);
      if (isTabEditBlockedMsg(msg) && attempt < 5) {
        await sleepMs(500 + attempt * 350);
        continue;
      }
      throw e;
    }
  }
  return current;
}

async function captureTabImage(tab, quality) {
  const attempts = [];
  let direct = await tryCaptureTabDirect(tab.id, quality);
  if (direct.dataUrl) return direct.dataUrl;
  if (direct.err) attempts.push(`captureTab: ${direct.err}`);

  if (tab.active) {
    const visible = await tryCaptureVisibleWindow(tab, quality);
    if (visible.dataUrl) return visible.dataUrl;
    if (visible.err) attempts.push(`visible(active): ${visible.err}`);
  }

  const readyTab = await prepareWindowAndTabForCapture(tab);

  direct = await tryCaptureTabDirect(readyTab.id, quality);
  if (direct.dataUrl) return direct.dataUrl;
  if (direct.err) attempts.push(`captureTab(focused): ${direct.err}`);

  const visibleAfter = await tryCaptureVisibleWindow(readyTab, quality);
  if (visibleAfter.dataUrl) return visibleAfter.dataUrl;
  if (visibleAfter.err) attempts.push(`visible(focused): ${visibleAfter.err}`);

  throw new Error(attempts.join(' · ') || 'Capture failed — keep Facebook visible and retry');
}

async function captureFacebookScreenshot(fbProbe) {
  let lastErr = '';
  try {
    const pref = runState?.workerTabId || fbProbe?.tabId || null;
    const merged = await consolidateFacebookTabs(pref);
    let tabs = await queryFacebookTabs();
    if (!tabs.length && merged.kept?.id) {
      try {
        tabs = [await chrome.tabs.get(merged.kept.id)];
      } catch (_) {}
    }
    if (!tabs.length) return { ok: false, error: 'No Facebook tab open' };

    const ordered = tabs.slice().sort((a, b) => {
      const workerId = runState?.workerTabId;
      if (workerId) {
        if (a.id === workerId) return -1;
        if (b.id === workerId) return 1;
      }
      if (a.active !== b.active) return a.active ? -1 : 1;
      return (b.lastAccessed || 0) - (a.lastAccessed || 0);
    });

    for (const tab of ordered) {
      if (!tab?.id) continue;
      const qualities = [32, 24, 18, 12, 8];
      for (const q of qualities) {
        try {
          const dataUrl = await captureTabImage(tab, q);
          if (!dataUrl || typeof dataUrl !== 'string') continue;
          const b64Len = dataUrl.replace(/^data:image\/\w+;base64,/, '').length;
          if (b64Len <= FLEET_SCREENSHOT_MAX_B64) return { ok: true, dataUrl };
          lastErr = `Image too large (${Math.round(b64Len / 1024)}KB) at q=${q}`;
        } catch (e) {
          lastErr = chromeErrMsg(e).slice(0, 180);
          if (isTabEditBlockedMsg(lastErr)) {
            lastErr = 'Chrome blocked tab switch — release tab drag, click Facebook, retry';
          }
        }
      }
    }

    if (fbProbe?.tabId) {
      try {
        const tab = await chrome.tabs.get(fbProbe.tabId);
        const dataUrl = await captureTabImage(tab, 8);
        if (dataUrl) return { ok: true, dataUrl };
      } catch (e) {
        lastErr = chromeErrMsg(e).slice(0, 180);
      }
    }

    return { ok: false, error: lastErr || 'Capture failed — keep Facebook visible and retry' };
  } catch (e) {
    return { ok: false, error: chromeErrMsg(e).slice(0, 180) };
  }
}

async function doFleetSkipGroupAndResume() {
  const d = await chrome.storage.local.get([RUNSTATE_KEY, 'posterResults']);
  const saved = runState || d[RUNSTATE_KEY];
  if (!saved?.config) {
    return { ok: false, message: 'No saved run state' };
  }
  runState = { ...saved };
  const total = runState.config.groups?.length || 0;
  if (total && runState.index < total) {
    runState.index = Math.min(total, Number(runState.index || 0) + 1);
    persistRunState();
  }
  const ok = await doResumePostingAfterPause();
  return { ok, message: ok ? 'Skipped group + resumed' : 'Could not resume' };
}

async function fleetVisionCaptureAfterPause(stopReason, pauseDetail) {
  try {
    if (typeof FLEET === 'undefined') return;
    await FLEET.init(chrome.storage.local);
    if (!FLEET.isEnabled()) return;
    if (stopReason !== 'post_failure_pause') return;
    await sleep(1800);
    const fb = await probeFacebookForFleet();
    if (!fb.connected) return;
    let domHint = '';
    if (fb.tabId) {
      try {
        const inj = await chrome.scripting.executeScript({
          target: { tabId: fb.tabId },
          func: () => {
            const t = (document.body?.innerText || '').slice(0, 5000).toLowerCase();
            const hits = [];
            if (/automat(ed|ic)|automated behavior|actividad automatizada|comportamiento automatizado/.test(t)) {
              hits.push('automation_text');
            }
            if (/only admins can post|solo los administradores pueden publicar|solo administradores/.test(t)) {
              hits.push('admin_only');
            }
            if (/can'?t post|no puedes publicar|cannot post|no se puede publicar/.test(t)) {
              hits.push('cannot_post');
            }
            if (/checkpoint|confirm your identity|captcha|unusual activity/.test(t)) {
              hits.push('checkpoint');
            }
            if (/content not found|group isn'?t available|grupo no est/.test(t)) {
              hits.push('group_gone');
            }
            return hits.join(',');
          },
        });
        domHint = String(inj?.[0]?.result || '');
      } catch (_) {}
    }
    const shot = await Promise.race([
      captureFacebookScreenshot(fb),
      sleepMs(25000).then(() => ({ ok: false, error: 'timeout' })),
    ]);
    if (!shot.ok) return;
    await FLEET.uploadScreenshot(shot.dataUrl, {
      visionGuard: true,
      pauseContext: {
        stopReason,
        groupName: String(pauseDetail?.groupName || '').slice(0, 120),
        lastError: String(pauseDetail?.error || '').slice(0, 240),
        domHint,
      },
    });
    const ver = chrome.runtime.getManifest().version;
    if (typeof FLEET.syncNow === 'function') {
      await FLEET.syncNow(chrome.storage.local, RUNSTATE_KEY, ver);
    }
  } catch (_) {}
}

async function doFleetPausePosting() {
    if (posterRunning && runState) {
    stopRequested = true;
    runState.stopReason = 'user_pause';
    runState.resumeHint = 'user_pause';
    return { ok: true, message: 'Pausing…' };
  }
  const d = await chrome.storage.local.get([RUNSTATE_KEY]);
  const saved = runState || d[RUNSTATE_KEY];
  if (saved?.config) {
    runState = { ...saved, stopReason: 'user_pause', resumeHint: 'user_pause' };
    stopRequested = true;
    posterRunning = false;
    await chrome.storage.local.set({ posterRunning: false });
    persistRunState();
    broadcastToApp({ action: 'postingStopped', stopReason: 'user_pause' });
    return { ok: true, message: 'Paused' };
  }
  posterRunning = false;
  await chrome.storage.local.set({ posterRunning: false });
  return { ok: true, message: 'Already idle' };
}

async function handleFleetCommand(cmd) {
  const command = String(cmd?.command || '').toLowerCase();
  if (!command) return { ok: false, message: 'empty command' };
  try {
    if (command === 'stop') {
      return await doFleetPausePosting();
    }
    if (command === 'resume') {
      const ok = await doResumePostingAfterPause();
      return { ok, message: ok ? 'Resumed' : 'No saved run state — start posting in Irishka first' };
    }
    if (command === 'skip_group') {
      return await doFleetSkipGroupAndResume();
    }
    if (command === 'reload_extension') {
      setTimeout(() => { chrome.runtime.reload(); }, 300);
      return { ok: true, message: 'Reloading extension' };
    }
    if (command === 'status') {
      const d = await chrome.storage.local.get(['posterRunning', RUNSTATE_KEY, 'posterResults']);
      const running = !!d.posterRunning;
      const rs = d[RUNSTATE_KEY] || null;
      const results = d.posterResults || rs?.results || [];
      const total = rs?.config?.groups?.length || 0;
      const done = results.length;
      const ok = results.filter((r) => r.success).length;
      const fb = await probeFacebookForFleet();
      const fbLabel = fb.connected ? (fb.userName || 'connected') : (fb.reason || 'offline');
      return {
        ok: true,
        message: `${running ? 'posting' : rs ? 'paused' : 'idle'} ${done}/${total} ok=${ok} | FB: ${fbLabel}`,
      };
    }
    if (command === 'screenshot') {
      const fb = await probeFacebookForFleet();
      if (!fb.connected) {
        return { ok: false, message: fb.reason || 'Facebook not connected' };
      }
      const shot = await Promise.race([
        captureFacebookScreenshot(fb),
        sleepMs(25000).then(() => ({ ok: false, error: 'Capture timeout (25s)' })),
      ]);
      if (!shot.ok) {
        const hint = /blocked tab switch|dragging a tab/i.test(shot.error || '')
          ? ' — si Facebook pide confirmar salir de la página, haz clic en la pestaña FB y acepta una vez'
          : '';
        return { ok: false, message: (shot.error || 'Capture failed') + hint };
      }
      if (typeof FLEET !== 'undefined') {
        const d = await chrome.storage.local.get([RUNSTATE_KEY]);
        const rs = runState || d[RUNSTATE_KEY];
        const last = rs?.results?.length ? rs.results[rs.results.length - 1] : null;
        const visionMeta = cmd?.meta?.visionGuard
          ? {
              visionGuard: true,
              pauseContext: {
                stopReason: rs?.stopReason || cmd.meta.stopReason || 'post_failure_pause',
                groupName: last?.name || rs?.progress?.currentGroup || '',
                lastError: last?.error || '',
                domHint: '',
              },
            }
          : undefined;
        const up = await FLEET.uploadScreenshot(shot.dataUrl, visionMeta);
        return { ok: up.ok, message: up.ok ? 'Screenshot sent' : (up.message || 'Upload failed') };
      }
      return { ok: false, message: 'Fleet client missing' };
    }
    if (command === 'consolidate_fb' || command === 'cleanfb') {
      const fb = await probeFacebookForFleet();
      const before = fb.tabCount || 0;
      const r = await consolidateFacebookTabs(runState?.workerTabId || fb.tabId || null);
      const afterTabs = await queryFacebookTabs();
      const msg = r.closed > 0
        ? `Cerradas ${r.closed} pestaña(s) FB — quedan ${afterTabs.length}`
        : (before > 1 ? `${before} pestañas FB — cierra manualmente si Facebook pide confirmar` : 'Ya hay una sola pestaña FB');
      return { ok: true, message: msg };
    }
    return { ok: false, message: 'Unknown command' };
  } catch (e) {
    return { ok: false, message: String(e?.message || e).slice(0, 120) };
  }
}

function doStopPosting(stopReason) {
  stopRequested = true;
  posterRunning = false;
  runState = null;
  chrome.alarms.clear('fartmily_resume');
  chrome.storage.local.remove(RUNSTATE_KEY);
  chrome.storage.local.remove(['fartmily_pending_images']);
  clearPosterSessionStorage();
  chrome.storage.local.set({ posterRunning: false });
  broadcastToApp({ action: 'postingStopped', stopReason: stopReason || 'user_stop' });
}

async function ensureRunStateForConfigPatch() {
  if (runState && runState.config) return true;
  const d = await chrome.storage.local.get([RUNSTATE_KEY]);
  const saved = d[RUNSTATE_KEY];
  if (!saved || !saved.config) return false;
  runState = { ...saved };
  if (runState.postIndex === undefined) runState.postIndex = 0;
  return true;
}

async function doResumePostingAfterPause() {
  try {
    const d = await chrome.storage.local.get([RUNSTATE_KEY]);
    const saved = runState || d[RUNSTATE_KEY];
    if (!saved || !saved.config) return false;
    runState = { ...saved, stopReason: null };
    delete runState.resumeHint;
    stopRequested = false;
    posterRunning = true;
    await syncRunningConfigFromStorage(runState.config);
    await chrome.storage.local.set({ posterRunning: true });
    persistRunState();
    const numPosts = normalizePosts(runState.config).length;
    broadcastToApp({
      action: 'postRunStateResumed',
      groupsForProgress: groupsForProgressBroadcast(runState.config.groups || []),
      postIndex: runState.postIndex || 0,
      totalPosts: numPosts,
      loopInfinite: !!runState.config.loopInfinite,
    });
    await hydratePosterImagesFromSession(runState.config);
    runPostingLoop().catch(() => {});
    return true;
  } catch (e) {
    return false;
  }
}

async function handleTelegramCommand(payload) {
  const cmd = String(payload?.command || '').toLowerCase();
  if (!cmd || typeof TG === 'undefined') return;
  try {
    if (cmd === 'stop' || cmd === 'stop_all') {
      doStopPosting('user_stop_remote');
      await TG.notifyAlert({ title: 'Stopped', body: `Posting stopped on [${TG.instanceName()}].` });
      return;
    }
    if (cmd === 'resume' || cmd === 'resume_all') {
      const ok = await doResumePostingAfterPause();
      await TG.notifyAlert({
        title: ok ? 'Resumed' : 'Resume failed',
        body: ok ? `Posting resumed on [${TG.instanceName()}].` : `No saved run state found on [${TG.instanceName()}].`,
      });
      return;
    }
    if (cmd === 'status' || cmd === 'active' || cmd === 'help' || cmd === 'start') {
      const d = await chrome.storage.local.get(['posterRunning', RUNSTATE_KEY, 'posterResults']);
      const running = !!d.posterRunning;
      const rs = d[RUNSTATE_KEY] || null;
      const results = d.posterResults || rs?.results || [];
      const total = rs?.config?.groups?.length || 0;
      const done = results.length;
      const ok = results.filter((r) => r.success).length;
      await TG.notifyAlert({
        title: `Status [${TG.instanceName()}]`,
        body:
          `State: ${running ? 'posting' : rs ? 'paused' : 'idle'}\n` +
          `Progress: ${done}/${total}\n` +
          `Successful: ${ok}\n` +
          'Commands: /status /resume /stop',
      });
    }
  } catch (e) {
    try {
      await TG.notifyAlert({ title: 'Command error', body: String(e?.message || e).slice(0, 180) });
    } catch (_) {}
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === 'startPosting') {
    // return true + sendResponse when done keeps the MV3 service worker alive for the whole run.
    // Config se lee desde storage (evita límite/tamaño de sendMessage con posts + data URLs).
    startPostingProcess(msg.config, msg.groupsSnapshot)
      .then(() => {
        try {
          sendResponse({ ok: true });
        } catch (_) {}
      })
      .catch(() => {
        try {
          sendResponse({ ok: false });
        } catch (_) {}
      });
    return true;
  }
  if (msg.action === 'stopPosting') {
    const stopReason = (msg && msg.stopReason) || 'user_stop';
    stopRequested = true;
    if (stopReason === 'user_pause') {
      if (runState) {
        runState.stopReason = 'user_pause';
        runState.resumeHint = 'user_pause';
      }
      posterRunning = false;
      chrome.storage.local.set({ posterRunning: false });
      persistRunState();
    } else {
      posterRunning = false;
      runState = null;
      chrome.alarms.clear('fartmily_resume');
      chrome.storage.local.remove(RUNSTATE_KEY);
      chrome.storage.local.remove(['fartmily_pending_images']);
      clearPosterSessionStorage();
      chrome.storage.local.set({ posterRunning: false });
      broadcastToApp({ action: 'postingStopped', stopReason });
    }
  }
  if (msg.action === 'resumePostingAfterPause') {
    doResumePostingAfterPause()
      .then((ok) => {
        try { sendResponse({ ok: !!ok }); } catch (_) {}
      })
      .catch(() => {
        try { sendResponse({ ok: false }); } catch (_) {}
      });
    return true;
  }
  if (msg.action === 'resumeProgrammedPosting') {
    resumePostingFromStoredRunState()
      .then((r) => {
        try {
          sendResponse(r);
        } catch (_) {}
      })
      .catch(() => {
        try {
          sendResponse({ ok: false, error: 'exception' });
        } catch (_) {}
      });
    return true;
  }
  if (msg.action === 'startJoinQueue') {
    (async () => {
      try {
        const r = await beginJoinQueueFromMessage(msg);
        try {
          sendResponse(r);
        } catch (_) {}
      } catch (e) {
        try {
          sendResponse({ ok: false, error: String(e && e.message ? e.message : e) });
        } catch (_) {}
      }
    })();
    return true;
  }
  if (msg.action === 'stopJoinQueue') {
    chrome.alarms.clear('irishka_join_resume');
    chrome.storage.local.remove([JOIN_QUEUE_KEY], () => {
      try {
        sendResponse({ ok: true });
      } catch (_) {}
    });
    return true;
  }
  if (msg.action === 'irishkaBridgePollNow') {
    if (!isCommunityFreeBuildBg()) {
      try {
        sendResponse({ ok: false });
      } catch (_) {}
      return false;
    }
    pollIrishkaBridgeOnce()
      .then(() => {
        try {
          sendResponse({ ok: true });
        } catch (_) {}
      })
      .catch(() => {
        try {
          sendResponse({ ok: false });
        } catch (_) {}
      });
    return true;
  }
  if (msg.action === 'schedulePostingAt') {
    schedulePostingAtFromApp(Number(msg.atMs))
      .then((r) => {
        try {
          sendResponse(r);
        } catch (_) {}
      })
      .catch(() => {
        try {
          sendResponse({ ok: false, error: 'exception' });
        } catch (_) {}
      });
    return true;
  }
  if (msg.action === 'cancelScheduledPosting') {
    (async () => {
      const r = await cancelScheduledPostingFromApp();
      try {
        sendResponse(r);
      } catch (_) {}
    })();
    return true;
  }
  if (msg.action === 'setPosterLoopInfinite') {
    (async () => {
      const r = await setPosterLoopInfiniteFromApp(Boolean(msg.loopInfinite));
      try {
        sendResponse(r);
      } catch (_) {}
    })();
    return true;
  }
  if (msg.action === 'skipCurrentPosterPost') {
    (async () => {
      const r = await requestSkipCurrentPosterPost();
      try {
        sendResponse(r);
      } catch (_) {}
    })();
    return true;
  }
  if (msg.action === 'appendPostToRunningLoop') {
    (async () => {
      const r = await appendPostToRunningLoopFromMessage(msg.post);
      try {
        sendResponse(r);
      } catch (_) {}
    })();
    return true;
  }
  if (msg.action === 'tgTestConnection') {
    (async () => {
      try {
        await TG.init(chrome.storage.local);
        const r = await TG.testConnection();
        sendResponse(r);
      } catch (e) {
        try { sendResponse({ ok: false, error: String(e?.message || e) }); } catch (_) {}
      }
    })();
    return true;
  }
  if (msg.action === 'tgSettingsChanged') {
    (async () => {
      try {
        await initRemoteControl();
        sendResponse({ ok: true });
      } catch (e) {
        try { sendResponse({ ok: false, error: String(e?.message || e) }); } catch (_) {}
      }
    })();
    return true;
  }
  if (msg.action === 'fleetHubSettingsChanged') {
    (async () => {
      try {
        await initRemoteControl();
        sendResponse({ ok: true });
      } catch (e) {
        try { sendResponse({ ok: false, error: String(e?.message || e) }); } catch (_) {}
      }
    })();
    return true;
  }
  if (msg.action === 'fleetHubTest') {
    (async () => {
      try {
        if (typeof FLEET === 'undefined') {
          sendResponse({ ok: false, error: 'Fleet client missing' });
          return;
        }
        await FLEET.init(chrome.storage.local);
        if (!FLEET.isEnabled()) {
          sendResponse({ ok: false, error: 'Enable Fleet Hub + secret' });
          return;
        }
        const ver = chrome.runtime.getManifest().version;
        const hb = await FLEET.sendHeartbeat(chrome.storage.local, RUNSTATE_KEY, ver);
        sendResponse({ ok: !!hb?.ok, error: hb?.ok ? '' : 'Heartbeat failed — check secret/URL' });
      } catch (e) {
        try { sendResponse({ ok: false, error: String(e?.message || e) }); } catch (_) {}
      }
    })();
    return true;
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (typeof FLEET !== 'undefined' && alarm.name === FLEET.fastAlarmName()) {
    const ver = chrome.runtime.getManifest().version;
    FLEET.tickFast(chrome.storage.local, RUNSTATE_KEY, ver, chrome.alarms).catch(() => {});
    return;
  }
  if (typeof FLEET !== 'undefined' && alarm.name === FLEET.alarmName()) {
    const ver = chrome.runtime.getManifest().version;
    FLEET.syncNow(chrome.storage.local, RUNSTATE_KEY, ver).catch(() => {});
    FLEET.scheduleFastPoll(chrome.alarms).catch(() => {});
    return;
  }
  if (typeof TG !== 'undefined' && alarm.name === TG.pollAlarmName()) {
    TG.pollNow().catch(() => {});
    return;
  }
  if (alarm.name === 'irishka_license_check') {
    if (typeof IGM_COMMUNITY_FREE !== 'undefined' && IGM_COMMUNITY_FREE) return;
    runLicenseCheckAlarm().catch(() => {});
    return;
  }
  if (alarm.name === 'irishka_bridge_poll') {
    if (isCommunityFreeBuildBg()) pollIrishkaBridgeOnce().catch(() => {});
    return;
  }
  if (alarm.name === 'irishka_join_resume') {
    runJoinQueueChunk().catch(() => {});
    return;
  }
  if (alarm.name !== 'fartmily_resume') return;

  // In MV3, the service worker can be suspended; in that case, runState in memory is lost.
  // Rehydrate the state from storage, then resume. (No exigir posterRunning: al pausar por límite
  // diario se pone posterRunning false pero RUNSTATE_KEY sigue guardado para reanudar.)
  resumePostingFromStoredRunState().catch(() => {});
});

async function startPostingProcess(msgConfig, groupsSnapshot) {
  const stored = await chrome.storage.local.get(['posterConfig']);
  const base = stored.posterConfig && typeof stored.posterConfig === 'object' ? { ...stored.posterConfig } : {};
  const config = { ...base };
  if (Array.isArray(groupsSnapshot) && groupsSnapshot.length > 0) {
    config.groups = groupsSnapshot;
  }
  if (!Array.isArray(config.groups) || config.groups.length === 0) {
    const mc = msgConfig && typeof msgConfig === 'object' ? msgConfig : null;
    if (mc && Array.isArray(mc.groups) && mc.groups.length > 0) {
      Object.assign(config, mc);
      config.groups = mc.groups;
    }
  }
  if (!Array.isArray(config.groups) || config.groups.length === 0) {
    posterRunning = false;
    await chrome.storage.local.set({ posterRunning: false });
    broadcastToApp({ action: 'postingStopped', stopReason: 'bad_config' });
    return;
  }

  if (isCommunityFreeBuildBg() && config.communityProfileFirst !== false) {
    config.groups = [makeProfileTimelineSlotBg(), ...config.groups];
  }

  await hydratePosterImagesFromSession(config);

  posterRunning = true;
  stopRequested = false;
  chrome.alarms.clear('fartmily_resume');
  chrome.storage.local.remove(RUNSTATE_KEY);
  const now = Date.now();
  const plannedStartAt = null;
  runState = {
    config,
    results: [],
    index: 0,
    postIndex: 0,
    dailySuccessCount: 0,
    dailyKey: dayKey(now),
    startedOnce: false,
    plannedStartAt,
    stopReason: null,
    workerTabId: null
  };
  chrome.storage.local.set({ posterRunning: true, posterResults: [] });
  persistRunState();
  await runPostingLoop();
}

/** Re-read checked groups from storage each loop round (same rules as app start). */
async function refreshGroupsForLoop(config) {
  const d = await chrome.storage.local.get(['fbGroups']);
  const raw = d.fbGroups || [];
  let sel = raw.filter(g => g.selected);
  if (config.verifiedOnlyEnabled) {
    sel = sel.filter(g => g.canPost === true);
  }
  // If storage is empty or not flushed yet (race with UI), use groups from the start message.
  if (!sel.length && Array.isArray(config.groups) && config.groups.length) {
    sel = config.verifiedOnlyEnabled
      ? config.groups.filter(g => g.canPost === true)
      : [...config.groups];
  }
  return sel;
}

async function verifyUnverifiedGroupsForInfiniteLoop(tabId, config) {
  const d = await chrome.storage.local.get(['fbGroups']);
  const groups = Array.isArray(d.fbGroups) ? d.fbGroups.map((g) => ({ ...g })) : [];
  const targets = groups
    .map((g, i) => ({ g, i }))
    .filter(({ g }) => g && g.selected && g.canPost !== true && g.canPost !== false);
  if (!targets.length) return { checked: 0, newlyVerified: 0 };

  broadcastToApp({
    action: 'loopVerifyProgress',
    current: 0,
    total: targets.length,
    groupName: '',
  });

  let newlyVerified = 0;
  for (let k = 0; k < targets.length; k++) {
    if (stopRequested) break;
    const { g, i } = targets[k];
    broadcastToApp({
      action: 'loopVerifyProgress',
      current: k + 1,
      total: targets.length,
      groupName: g.name || g.url || '',
    });
    try {
      await navigateWorker(tabId, g.url, config);
      await sleep(5200);
      const inj = await chrome.scripting.executeScript({
        target: { tabId },
        func: detectGroupPostabilityInPage,
      });
      const result = inj?.[0]?.result || {};
      groups[i].canPost = !!result.canPost;
      if (typeof result.isMember === 'boolean') groups[i].isMember = result.isMember;
      groups[i].postabilityCheckedAt = Date.now();
      if (groups[i].canPost) newlyVerified++;
    } catch (_) {}
  }
  await chrome.storage.local.set({ fbGroups: groups });
  broadcastToApp({ action: 'groupsListChanged' });
  return { checked: targets.length, newlyVerified };
}

async function applyRefreshedGroupsForNextLoop(config) {
  const fresh = await refreshGroupsForLoop(config);
  if (!fresh.length) return [];
  let groupsForRun = fresh;
  if (isCommunityFreeBuildBg() && config.communityProfileFirst !== false) {
    groupsForRun = [makeProfileTimelineSlotBg(), ...fresh];
  }
  runState.config.groups = groupsForRun;
  await mergePosterConfigGroups(fresh);
  persistRunState();
  return groupsForRun;
}

/** Al cerrar una vuelta del loop infinito: verifica grupos pendientes y actualiza la cola. */
async function finalizeInfiniteLoopRound(workerTab, config) {
  const verifyStats = await verifyUnverifiedGroupsForInfiniteLoop(workerTab.id, config);
  const groupsForRun = await applyRefreshedGroupsForNextLoop(config);
  return { groupsForRun, verifyStats };
}

async function mergePosterConfigGroups(groups) {
  const d = await chrome.storage.local.get(['posterConfig']);
  const pc = { ...(d.posterConfig || {}), groups };
  await chrome.storage.local.set({ posterConfig: pc });
}

/** Pull current posts + loop flags from storage so resume/pause stays in sync with the app UI. */
async function syncRunningConfigFromStorage(config) {
  if (!config || typeof config !== 'object') return config;
  const d = await chrome.storage.local.get(['posterConfig']);
  const pc = d.posterConfig && typeof d.posterConfig === 'object' ? d.posterConfig : null;
  if (!pc) return config;

  if (typeof pc.loopInfinite === 'boolean') config.loopInfinite = pc.loopInfinite;
  if (typeof pc.verifiedOnlyEnabled === 'boolean') config.verifiedOnlyEnabled = pc.verifiedOnlyEnabled;
  if (typeof pc.pauseOnFailedPublication === 'boolean') {
    config.pauseOnFailedPublication = pc.pauseOnFailedPublication;
  }

  const existingPosts = Array.isArray(config.posts) ? config.posts.length : 0;
  if (Array.isArray(pc.posts) && pc.posts.length) {
    config.posts = pc.posts.map((p) => ({
      text: String((p && p.text) || ''),
      images: (p && Array.isArray(p.images) ? p.images : []).map((img) => ({
        name: (img && img.name) || '',
        type: (img && img.type) || 'image/jpeg',
        dataUrl: (img && img.dataUrl) || ''
      }))
    }));
    config.text = String(config.posts[0]?.text || '');
    config.images = (config.posts[0]?.images || []).slice(0, MAX_POST_IMAGES);
    await hydratePosterImagesFromSession(config);
    return config;
  }
  if (existingPosts <= 1 && typeof pc.text === 'string') {
    config.posts = [{
      text: String(pc.text || ''),
      images: Array.isArray(pc.images) ? pc.images.slice(0, MAX_POST_IMAGES) : []
    }];
    config.text = config.posts[0].text;
    config.images = config.posts[0].images;
    await hydratePosterImagesFromSession(config);
  }
  return config;
}

/** Pull current posts from storage so newly added posts join the running queue in real time. */
async function refreshPostsForLoop(config) {
  return syncRunningConfigFromStorage(config);
}

function normalizePosts(config) {
  if (Array.isArray(config.posts) && config.posts.length) {
    return config.posts.map(p => ({
      text: String(p.text || ''),
      images: (p.images || []).slice(0, MAX_POST_IMAGES).map(img => ({
        dataUrl: img.dataUrl,
        name: img.name || '',
        type: img.type || 'image/jpeg'
      }))
    }));
  }
  return [{
    text: String(config.text || ''),
    images: (config.images || []).slice(0, MAX_POST_IMAGES).map(img => ({
      dataUrl: img.dataUrl,
      name: img.name || '',
      type: img.type || 'image/jpeg'
    }))
  }];
}

async function runPostingLoop() {
  if (!runState || !posterRunning || stopRequested) return;
  if (runState.postIndex === undefined) runState.postIndex = 0;

  let config = runState.config;

  let workerTab = null;
  const savedTabId = runState.workerTabId;
  if (savedTabId != null) {
    try {
      const ex = await chrome.tabs.get(savedTabId);
      if (ex && ex.id) workerTab = ex;
    } catch (_) {}
  }
  try {
    if (!workerTab) {
      workerTab = await getOrCreateWorkerTab(config);
      runState.workerTabId = workerTab.id;
      persistRunState();
    }
  } catch (e) {
    posterRunning = false;
    chrome.storage.local.set({ posterRunning: false });
    const errLine = '[BG] No se pudo abrir la pestaña de Facebook: ' + (e && e.message ? e.message : String(e));
    const r = [{ name: '—', url: '', success: false, error: e && e.message ? e.message : 'Tab error', log: [errLine] }];
    const n = (config.groups && config.groups.length) || 1;
    broadcastToApp({ action: 'postingFinished', results: r, total: n, notifyEnd: config.notifyEnd });
    return;
  }

  while (!stopRequested) {
    config = runState.config;
    await syncRunningConfigFromStorage(config);
    runState.config = config;
    persistRunState();
    const posts = normalizePosts(config);
    const numPosts = posts.length;
    if (!numPosts) break;

    const pi = runState.postIndex;
    if (pi >= numPosts) {
      if (config.loopInfinite && numPosts > 0) {
        runState.postIndex = 0;
        runState.results = [];
        runState.index = 0;
        persistRunState();
        await chrome.storage.local.set({ posterResults: [] });
        const { groupsForRun, verifyStats } = await finalizeInfiniteLoopRound(workerTab, config);
        broadcastToApp({
          action: 'loopRoundRestart',
          total: groupsForRun.length,
          groupsForProgress: groupsForProgressBroadcast(groupsForRun),
          verifyChecked: verifyStats.checked,
          newlyVerified: verifyStats.newlyVerified,
        });
        const waitSec = computeWaitSeconds(config);
        const tg = groupsForRun.length || runState.config.groups?.length || 0;
        for (let left = waitSec; left > 0; left--) {
          if (stopRequested) break;
          if (runState?.skipCurrentPostSweep) break;
          broadcastToApp({
            action: 'progressUpdate',
            results: [],
            total: tg,
            countdown: left,
            postIndex: 0,
            totalPosts: numPosts
          });
          await sleep(1000);
        }
        if (stopRequested) break;
        if (runState?.skipCurrentPostSweep) runState.skipCurrentPostSweep = false;
        continue;
      }
      break;
    }

    const currentPost = posts[pi];
    const results = runState.results;
    const startingFreshSweep = (runState.index === 0 && results.length === 0);

    if (startingFreshSweep) {
      const fresh = await refreshGroupsForLoop(config);
      if (!fresh.length) {
        stopRequested = true;
        if (runState) runState.stopReason = 'no_groups';
        break;
      }
      let groupsForRun = fresh;
      if (isCommunityFreeBuildBg() && config.communityProfileFirst !== false) {
        groupsForRun = [makeProfileTimelineSlotBg(), ...fresh];
      }
      runState.config.groups = groupsForRun;
      await mergePosterConfigGroups(fresh);
    }

    const total = runState.config.groups.length;
    if (!total) {
      stopRequested = true;
      if (runState) runState.stopReason = 'no_groups';
      break;
    }

    if (startingFreshSweep) {
      broadcastToApp({
        action: 'postSweepStart',
        postIndex: pi,
        totalPosts: numPosts,
        total: total,
        groupsForProgress: groupsForProgressBroadcast(runState.config.groups)
      });
    }
    broadcastToApp({
      action: 'progressUpdate',
      results: [...results],
      total,
      countdown: 0,
      postIndex: pi,
      totalPosts: numPosts
    });

    for (let i = runState.index; i < total; i++) {
      if (stopRequested) break;
      if (runState.skipCurrentPostSweep) {
        runState.skipCurrentPostSweep = false;
        for (let j = i; j < total; j++) {
          const g = runState.config.groups[j];
          results.push({
            name: g.name || '—',
            url: g.url || '',
            success: false,
            error: 'skipped_by_user',
            log: []
          });
        }
        runState.index = total;
        chrome.storage.local.set({ posterResults: results });
        persistRunState();
        broadcastToApp({
          action: 'progressUpdate',
          results: [...results],
          total,
          countdown: 0,
          postIndex: pi,
          totalPosts: numPosts
        });
        break;
      }

      resetDailyCounterIfNeeded();
      const dailyLimit = Number(config.dailySuccessLimit);
      if (config.dailyLimitEnabled && Number.isFinite(dailyLimit) && dailyLimit >= 1
          && runState.dailySuccessCount >= dailyLimit) {
        const resumeAt = computeNextDailyResume(config.dailyResumeTime || '09:00');
        runState.plannedStartAt = resumeAt;
        runState.resumeHint = 'daily_limit';
        persistRunState();
        scheduleResume(resumeAt, 'Pausa diaria por limite alcanzado');
        posterRunning = false;
        chrome.storage.local.set({ posterRunning: false });
        broadcastToApp({ action: 'postingStopped', stopReason: 'daily_limit' });
        runState = null;
        return;
      }

      runState.index = i;
      const group = runState.config.groups[i];
      const postText = config.useSpintax ? spinText(currentPost.text) : currentPost.text;
      const imagesToPass = (currentPost.images || []).slice(0, MAX_POST_IMAGES).map(img => ({
        dataUrl: img.dataUrl,
        name: img.name,
        type: img.type
      }));
      await setPendingImagesForInject(imagesToPass);

      broadcastToApp({
        action: 'progressUpdate',
        results: [...results],
        total,
        countdown: 0,
        postIndex: pi,
        totalPosts: numPosts
      });

      let success = false, error = '', log = [];
      let pausedBeforePublish = false;
      const bgLog = [];
      const bg = (m) => bgLog.push('[BG] ' + m);

      try {
        bg('Grupo: ' + (group.name || '') + ' | tabId=' + workerTab.id);
        bg('URL destino: ' + (group.url || '').slice(0, 120));
        await navigateWorker(workerTab.id, group.url, config);
        bg('Navegación enviada');
        await focusWorkerWindow(workerTab.id, config);
        bg(config.bgTabsEnabled ? 'Modo silencioso: sin foco en FB' : 'Pestaña enfocada');
        await sleep(7000);
        if (stopRequested) break;

        await focusWorkerWindow(workerTab.id, config);
        await sleep(400);

        const expectedImgN = imagesToPass.length;
        let inlineImgs = imagesToPass;
        const imgBytesEst = imagesToPass.reduce((s, x) => s + String(x?.dataUrl || '').length, 0);
        if (imgBytesEst > 1_200_000) {
          inlineImgs = [];
          bg('Imágenes demasiado grandes para args (' + imgBytesEst + ' chars dataUrl); fallback storage en página');
        } else if (expectedImgN) {
          bg('Pasar ' + expectedImgN + ' imagen(es) en args de inyección');
        }

        bg('Ejecutando fbPostInPage…');
        const injResult = await withTimeout(
          chrome.scripting.executeScript({
            target: { tabId: workerTab.id },
            func: fbPostInPage,
            args: [postText, inlineImgs, PAUSE_BEFORE_PUBLISH, expectedImgN]
          }),
          60000,
          'Automation timeout (grupo sin respuesta)'
        );

        const raw = injResult?.[0];
        bg('Resultado inject: err=' + (raw?.error || 'ninguno') + ' hasResult=' + (raw?.result != null));
        const res = raw?.result;
        if (res == null && raw?.error) {
          error = String(raw.error);
          success = false;
          log = [...bgLog, '[BG] Fallo capa inject: ' + raw.error];
        } else {
          success = res?.success === true;
          error = res?.error || (success ? '' : 'Sin resultado');
          const pageLog = Array.isArray(res?.log) ? res.log.map((x) => String(x)) : [];
          if (!pageLog.length && res != null) bg('(Script sin array log; revisa consola de la pestaña Facebook)');
          log = [...bgLog, ...pageLog];
          if (res == null) log.push('[BG] result es null (¿error de serialización o script sin retorno?)');
          if (res?.pausedBeforePublish) {
            pausedBeforePublish = true;
            stopRequested = true;
            success = false;
            error = res?.error || 'Pausa de seguridad antes de publicar';
            runState.stopReason = 'post_failure_pause';
          }
        }
      } catch (e) {
        error = e.message || 'Error de inyeccion';
        success = false;
        log = [...bgLog, '[BG] Excepción: ' + (e.message || e)];
      }

      results.push({ name: group.name, url: group.url, success, error, log });
      if (success) runState.dailySuccessCount++;
      if (config.pauseOnFailedPublication !== false && !success) {
        stopRequested = true;
        runState.stopReason = 'post_failure_pause';
      }
      runState.index = i + 1;
      chrome.storage.local.set({ posterResults: results });
      persistRunState();
      broadcastToApp({
        action: 'progressUpdate',
        results: [...results],
        total,
        countdown: 0,
        postIndex: pi,
        totalPosts: numPosts
      });

      if (pausedBeforePublish) break;
      if (stopRequested) break;

      if (i < total - 1 && !stopRequested) {
        const waitSec = computeWaitSeconds(config);
        for (let left = waitSec; left > 0; left--) {
          if (stopRequested) break;
          if (runState?.skipCurrentPostSweep) break;
          broadcastToApp({
            action: 'progressUpdate',
            results: [...results],
            total,
            countdown: left,
            postIndex: pi,
            totalPosts: numPosts
          });
          await sleep(1000);
        }
      }
    }

    if (stopRequested) break;

    runState.postIndex += 1;

    if (runState.postIndex >= numPosts) {
      if (config.loopInfinite && numPosts > 0) {
        runState.postIndex = 0;
        runState.results = [];
        runState.index = 0;
        persistRunState();
        await chrome.storage.local.set({ posterResults: [] });
        const { groupsForRun, verifyStats } = await finalizeInfiniteLoopRound(workerTab, config);
        broadcastToApp({
          action: 'loopRoundRestart',
          total: groupsForRun.length,
          groupsForProgress: groupsForProgressBroadcast(groupsForRun),
          verifyChecked: verifyStats.checked,
          newlyVerified: verifyStats.newlyVerified,
        });
        const waitSec = computeWaitSeconds(config);
        const tg = groupsForRun.length || runState.config.groups?.length || 0;
        for (let left = waitSec; left > 0; left--) {
          if (stopRequested) break;
          if (runState?.skipCurrentPostSweep) break;
          broadcastToApp({
            action: 'progressUpdate',
            results: [],
            total: tg,
            countdown: left,
            postIndex: 0,
            totalPosts: numPosts
          });
          await sleep(1000);
        }
        if (stopRequested) break;
        if (runState?.skipCurrentPostSweep) runState.skipCurrentPostSweep = false;
        continue;
      }
      break;
    }

    runState.results = [];
    runState.index = 0;
    persistRunState();
    await chrome.storage.local.set({ posterResults: [] });

    const waitBetweenPosts = computeWaitSeconds(config);
    for (let left = waitBetweenPosts; left > 0; left--) {
      if (stopRequested) break;
      if (runState?.skipCurrentPostSweep) break;
      broadcastToApp({
        action: 'progressUpdate',
        results: [],
        total,
        countdown: left,
        postIndex: runState.postIndex,
        totalPosts: numPosts
      });
      await sleep(1000);
    }
  }

  if (stopRequested) {
    posterRunning = false;
    chrome.storage.local.set({ posterRunning: false });
    const stopReason = runState?.stopReason || 'session_interrupted';
    const pauseDetail = stopReason === 'post_failure_pause' && runState?.results?.length
      ? (() => {
          const last = runState.results[runState.results.length - 1];
          return {
            groupName: last.name || '',
            groupUrl: last.url || '',
            error: last.error || ''
          };
        })()
      : null;
    const keepRunState = stopReason === 'post_failure_pause' || stopReason === 'user_pause';
    if (!keepRunState) {
      chrome.storage.local.remove(['fartmily_pending_images']);
      clearPosterSessionStorage();
      runState = null;
    } else {
      if (stopReason === 'user_pause') runState.resumeHint = 'user_pause';
      else if (stopReason === 'post_failure_pause') runState.resumeHint = 'post_failure_pause';
      persistRunState();
    }
    if (runState) runState.stopReason = null;
    broadcastToApp({
      action: 'postingStopped',
      stopReason,
      pauseDetail
    });
    void fleetVisionCaptureAfterPause(stopReason, pauseDetail);
    return;
  }

  const results = runState.results;
  const cfg = runState.config;
  posterRunning = false;
  chrome.storage.local.remove(RUNSTATE_KEY);
  runState = null;
  chrome.storage.local.set({ posterRunning: false });
  chrome.storage.local.remove(['fartmily_pending_images']);
  clearPosterSessionStorage();
  broadcastToApp({ action: 'postingFinished', results, total: results.length, notifyEnd: cfg.notifyEnd });

  if (cfg.notifyEnd) {
    const ok = results.filter(r => r.success).length;
    const n = results.length;
    chrome.storage.local.get([LANG_KEY_BG], (data) => {
      const allowed = new Set([
        'en', 'es', 'pt', 'fr', 'de', 'it', 'ru', 'nl', 'pl', 'tr',
        'hi', 'tl', 'ur', 'bn', 'id', 'ha', 'ar', 'vi', 'ro'
      ]);
      let lang = data[LANG_KEY_BG] || 'en';
      if (!allowed.has(String(lang).toLowerCase())) lang = 'en';
      const msg = notificationFinishMessage(lang, ok, n);
      chrome.notifications?.create({
        type: 'basic', iconUrl: 'icons/icon48.png',
        title: 'Irishka Group Master by SBS',
        message: msg
      });
    });
  }
}

function getOrCreateWorkerTab(config) {
  return new Promise((resolve, reject) => {
    const url = (config.groups && config.groups[0] && config.groups[0].url) ? config.groups[0].url : 'https://www.facebook.com/groups/';
    // Igual que backup: visible salvo "modo silencioso" (bgTabsEnabled = pestañas en segundo plano).
    const active = config.bgTabsEnabled === false;
    chrome.tabs.create({ url, active }, (tab) => {
      if (chrome.runtime.lastError) {
        return reject(new Error(chrome.runtime.lastError.message || 'tabs.create failed'));
      }
      if (!tab || !tab.id) return reject(new Error('No se pudo crear la pestaña worker'));
      waitTabComplete(tab.id, 20000).then(() => resolve(tab)).catch(() => resolve(tab));
    });
  });
}

async function focusWorkerWindow(tabId, cfg) {
  if (cfg && cfg.bgTabsEnabled) return;
  try {
    await chrome.tabs.update(tabId, { active: true });
    const t = await chrome.tabs.get(tabId);
    if (t.windowId != null) await chrome.windows.update(t.windowId, { focused: true });
  } catch (e) {}
}

/** Navega la pestaña worker; con modo silencioso no activa la pestaña ni roba el foco. */
function navigateWorker(tabId, url, cfg) {
  const silent = !!(cfg && cfg.bgTabsEnabled);
  return new Promise((resolve) => {
    chrome.tabs.update(tabId, { url, active: !silent }, () => {
      waitTabComplete(tabId, 20000).then(resolve).catch(resolve);
    });
  });
}

function waitTabComplete(tabId, maxMs) {
  return new Promise((resolve, reject) => {
    let done = false;
    const onUpd = (id, info) => {
      if (id === tabId && info.status === 'complete' && !done) {
        done = true;
        chrome.tabs.onUpdated.removeListener(onUpd);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(onUpd);
    setTimeout(() => {
      if (!done) {
        done = true;
        chrome.tabs.onUpdated.removeListener(onUpd);
        reject(new Error('tab load timeout'));
      }
    }, maxMs);
  });
}

function slimPosterConfigForDisk(cfg) {
  if (!cfg || typeof cfg !== 'object') return cfg;
  const c = { ...cfg };
  if (Array.isArray(c.posts)) {
    c.posts = c.posts.map((p) => ({
      ...p,
      images: (p.images || []).map((img) => ({
        name: img.name || '',
        type: img.type || 'image/jpeg'
      }))
    }));
  }
  if (Array.isArray(c.images)) {
    c.images = c.images.map((img) => ({
      name: img.name || '',
      type: img.type || 'image/jpeg'
    }));
  }
  return c;
}

function mergeLayerRowIntoPostImages(p, row) {
  if (!p || typeof p !== 'object') return p;
  const metaSlots = Array.isArray(p.images) ? p.images : [];
  const layerRow = Array.isArray(row) ? row : [];
  const n = Math.max(metaSlots.length, layerRow.length, 0);
  if (!n) return { ...p, images: [] };
  const out = [];
  for (let j = 0; j < n; j++) {
    const meta = metaSlots[j] || { name: '', type: 'image/jpeg' };
    const cell = layerRow[j];
    out.push({
      ...meta,
      dataUrl: (cell && cell.dataUrl) || meta.dataUrl || ''
    });
  }
  return { ...p, images: out };
}

async function hydratePosterImagesFromSession(config) {
  if (!config) return;
  try {
    let layers = null;
    if (typeof posterImageIdbLoadLayers === 'function') {
      try {
        const fromIdb = await posterImageIdbLoadLayers();
        if (fromIdb && Array.isArray(fromIdb) && fromIdb.length) layers = fromIdb;
      } catch (_) {}
    }
    let pack = null;
    if (!layers || !layers.length) {
      if (chrome.storage?.session) {
        try {
          const s = await chrome.storage.session.get([POSTER_SESSION_IMAGES_KEY]);
          const sp = s[POSTER_SESSION_IMAGES_KEY];
          if (sp && Array.isArray(sp.layers) && sp.layers.length) pack = sp;
        } catch (_) {}
      }
      if (!pack || !Array.isArray(pack.layers) || !pack.layers.length) {
        const d = await chrome.storage.local.get([POSTER_PERSISTED_IMAGES_KEY]);
        const lp = d[POSTER_PERSISTED_IMAGES_KEY];
        if (lp && Array.isArray(lp.layers) && lp.layers.length) pack = lp;
      }
      if (pack && Array.isArray(pack.layers) && pack.layers.length) layers = pack.layers;
    }
    if (!Array.isArray(layers) || !layers.length) return;
    pack = { layers };
    if (chrome.storage?.session && pack) {
      try {
        await chrome.storage.session.set({ [POSTER_SESSION_IMAGES_KEY]: pack });
      } catch (_) {}
    }
    if (Array.isArray(config.posts) && config.posts.length) {
      config.posts = config.posts.map((p, i) => mergeLayerRowIntoPostImages(p, layers[i]));
    }
    if (Array.isArray(config.images) && layers[0]) {
      const merged = mergeLayerRowIntoPostImages({ images: config.images }, layers[0]);
      config.images = merged.images;
    }
  } catch (e) {}
}

function clearPosterSessionStorage() {
  try {
    if (typeof posterImageIdbClear === 'function') {
      posterImageIdbClear().catch(() => {});
    }
  } catch (e) {}
  try {
    if (chrome.storage.session) {
      chrome.storage.session.remove([POSTER_SESSION_IMAGES_KEY, 'fartmily_pending_images']);
    }
  } catch (e) {}
  try {
    chrome.storage.local.remove([POSTER_PERSISTED_IMAGES_KEY]);
  } catch (e) {}
}

function setPendingImagesForInject(imagesToPass) {
  return new Promise((resolve) => {
    const done = () => resolve();
    // Backup: siempre local antes del inject; el page script lee igual que allí.
    // Si local falla por cuota, usar session como respaldo.
    chrome.storage.local.set({ fartmily_pending_images: imagesToPass }, () => {
      if (chrome.runtime.lastError) {
        if (chrome.storage?.session) {
          chrome.storage.session.set({ fartmily_pending_images: imagesToPass }, done);
        } else {
          done();
        }
        return;
      }
      if (chrome.storage?.session) {
        chrome.storage.session.remove(['fartmily_pending_images'], done);
      } else {
        done();
      }
    });
  });
}

function persistRunState() {
  try {
    if (!runState) return;
    // Store the current loop state so MV3 sleep doesn't break "resume".
    chrome.storage.local.set({ [RUNSTATE_KEY]: {
      config: slimPosterConfigForDisk(runState.config),
      results: runState.results,
      index: runState.index,
      postIndex: runState.postIndex,
      dailySuccessCount: runState.dailySuccessCount,
      dailyKey: runState.dailyKey,
      startedOnce: runState.startedOnce,
      plannedStartAt: runState.plannedStartAt || null,
      workerTabId: runState.workerTabId != null ? runState.workerTabId : null,
      resumeHint: runState.resumeHint || null,
      stopReason: runState.stopReason || null,
    }});
  } catch (e) {}
}

/**
 * Reanuda la cola guardada (p. ej. tras límite diario + alarma, o si la alarma no disparó con el PC apagado).
 */
async function resumePostingFromStoredRunState() {
  if (posterRunning) return { ok: false, error: 'already_running' };
  const d = await chrome.storage.local.get([RUNSTATE_KEY, 'posterRunning']);
  if (d.posterRunning) {
    // After extension reload/update, this flag can remain true even though worker loop died.
    await chrome.storage.local.set({ posterRunning: false });
  }
  const saved = d[RUNSTATE_KEY];
  if (!saved || !saved.config) return { ok: false, error: 'nothing_to_resume' };

  chrome.alarms.clear('fartmily_resume');
  posterRunning = true;
  stopRequested = false;
  runState = { ...saved, stopReason: null };
  if (runState.postIndex === undefined) runState.postIndex = 0;
  if (runState.config?.dailyLimitEnabled) runState.startedOnce = true;
  delete runState.resumeHint;
  runState.plannedStartAt = null;
  await syncRunningConfigFromStorage(runState.config);
  await chrome.storage.local.set({ posterRunning: true });
  persistRunState();
  const numPosts = normalizePosts(runState.config).length;
  broadcastToApp({
    action: 'postRunStateResumed',
    groupsForProgress: groupsForProgressBroadcast(runState.config.groups || []),
    postIndex: runState.postIndex || 0,
    totalPosts: numPosts,
    loopInfinite: !!runState.config.loopInfinite,
  });
  await hydratePosterImagesFromSession(runState.config);
  runPostingLoop().catch(() => {});
  return { ok: true };
}

async function rehydratePosterImageStoresFromIdb() {
  try {
    let layers = null;
    if (typeof posterImageIdbLoadLayers === 'function') {
      try {
        layers = await posterImageIdbLoadLayers();
      } catch (_) {}
    }
    if (!layers || !layers.length) return;
    const pack = { layers };
    if (chrome.storage?.session) {
      try {
        await chrome.storage.session.set({ [POSTER_SESSION_IMAGES_KEY]: pack });
      } catch (_) {}
    }
    try {
      await chrome.storage.local.set({ [POSTER_PERSISTED_IMAGES_KEY]: pack });
    } catch (_) {}
  } catch (_) {}
}

async function recoverPostingAfterExtensionReload() {
  if (posterRunning) return;
  const d = await chrome.storage.local.get([RUNSTATE_KEY, 'posterRunning']);
  const saved = d[RUNSTATE_KEY];
  if (!saved || !saved.config) {
    if (d.posterRunning) await chrome.storage.local.set({ posterRunning: false });
    return;
  }

  await rehydratePosterImageStoresFromIdb();

  const hint = String(saved.resumeHint || '');
  const futureAt = typeof saved.plannedStartAt === 'number' && saved.plannedStartAt > Date.now();

  if (futureAt && (hint === 'scheduled_start' || hint === 'daily_limit')) {
    const label = hint === 'daily_limit' ? 'Pausa diaria · reanuda programado' : 'Scheduled posting';
    scheduleResume(saved.plannedStartAt, label);
    posterRunning = false;
    await chrome.storage.local.set({ posterRunning: false });
    return;
  }

  if (hint === 'user_pause' || hint === 'post_failure_pause') {
    posterRunning = false;
    await chrome.storage.local.set({ posterRunning: false });
    return;
  }

  if (hint === 'scheduled_start' || hint === 'daily_limit') {
    await resumePostingFromStoredRunState();
    return;
  }

  const midRun =
    !!d.posterRunning ||
    (Number(saved.index) || 0) > 0 ||
    (Array.isArray(saved.results) && saved.results.length > 0);
  if (midRun) {
    await resumePostingFromStoredRunState();
  } else if (d.posterRunning) {
    await chrome.storage.local.set({ posterRunning: false });
  }
}

function resetDailyCounterIfNeeded() {
  if (!runState) return;
  const nowKey = dayKey(Date.now());
  if (runState.dailyKey !== nowKey) {
    runState.dailyKey = nowKey;
    runState.dailySuccessCount = 0;
  }
}

/** Mínimo 5 minutos (300 s) entre grupos, aunque venga config antigua o variación alta. */
const MIN_WAIT_SECONDS = 300;

function computeWaitSeconds(config) {
  const jitter = Math.floor(Math.random() * (config.timerVariation * 2 + 1)) - config.timerVariation;
  const base = Number(config.timerSeconds) || MIN_WAIT_SECONDS;
  return Math.max(MIN_WAIT_SECONDS, base + jitter);
}

function computeStartAt(startDay, hhmm) {
  const now = new Date();
  const [hh, mm] = parseHHMM(hhmm);
  const base = new Date(now);
  base.setHours(hh, mm, 0, 0);
  if (startDay === 'tomorrow') {
    base.setDate(base.getDate() + 1);
    return base.getTime();
  }
  if (base.getTime() < now.getTime()) base.setDate(base.getDate() + 1);
  return base.getTime();
}

function computeNextDailyResume(hhmm) {
  const now = new Date();
  const [hh, mm] = parseHHMM(hhmm);
  const d = new Date(now);
  d.setDate(d.getDate() + 1);
  d.setHours(hh, mm, 0, 0);
  return d.getTime();
}

function parseHHMM(v) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(v || '');
  if (!m) return [9, 0];
  return [Math.min(23, Math.max(0, Number(m[1]))), Math.min(59, Math.max(0, Number(m[2])))];
}

function dayKey(ts) {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return y + '-' + m + '-' + day;
}

/** Próximo timestamp local: mañana (o pasado mañana si ya pasó hoy) a hh:mm. */
function computeNextJoinResumeMs(hhmm) {
  const [hh, mm] = parseHHMM(hhmm);
  const now = Date.now();
  for (let add = 1; add <= 3; add++) {
    const d = new Date(now);
    d.setDate(d.getDate() + add);
    d.setHours(hh, mm, 0, 0);
    if (d.getTime() > now + 30_000) return d.getTime();
  }
  return now + 86_400_000;
}

/** Inyectado en pestaña de grupo: intenta pulsar Unirse / Join. */
async function joinGroupInPageInjected() {
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const txt = (el) => ((el.textContent || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
  const visible = () =>
    Array.from(document.querySelectorAll('[role="button"],button,a[role="button"]')).filter((el) => el.offsetParent);
  const joinHints = [
    'join group', 'join', 'unirte al grupo', 'unirse al grupo', 'unirse', 'solicitar unirse',
    'request to join', 'ask to join', 'participar', 'beitreten', 'rejoindre le groupe', 'rejoindre'
  ];
  const memberHints = ['you\'re a member', 'eres miembro', 'miembro del grupo', 'member of this group', 'abandonar'];
  function looksMember(btn) {
    const t = txt(btn);
    return memberHints.some((h) => t.includes(h));
  }
  function pickJoin() {
    for (const el of visible()) {
      if (looksMember(el)) continue;
      const t = txt(el);
      if (joinHints.some((h) => t.includes(h))) return el;
    }
    return null;
  }
  for (let attempt = 0; attempt < 18; attempt++) {
    const j = pickJoin();
    if (j) {
      j.scrollIntoView({ block: 'center', inline: 'center' });
      j.click();
      await wait(1400);
      const dialogs = Array.from(document.querySelectorAll('[role="dialog"]')).filter((d) => d.offsetParent);
      for (const dlg of dialogs) {
        const btns = Array.from(dlg.querySelectorAll('[role="button"],button')).filter((b) => b.offsetParent);
        const confirm = btns.find((b) => {
          const t = txt(b);
          return joinHints.some((h) => t.includes(h)) || t.includes('confirm') || t.includes('solicitar') || t.includes('request');
        });
        if (confirm) {
          confirm.click();
          await wait(1200);
        }
      }
      await wait(800);
      return { joined: true };
    }
    await wait(550);
  }
  return { joined: false, reason: 'no_join_button' };
}

async function beginJoinQueueFromMessage(msg) {
  const urls = Array.isArray(msg.urls) ? msg.urls.map((u) => String(u || '').trim()).filter(Boolean) : [];
  if (!urls.length) return { ok: false, error: 'no_urls' };
  const dailyMax = Math.max(1, Math.min(500, Number(msg.dailyMax) || 5));
  const resumeHhmm = String(msg.resumeHhmm || '07:00').trim() || '07:00';
  const st = {
    active: true,
    urls,
    cursor: 0,
    joinedToday: 0,
    dayKey: dayKey(Date.now()),
    dailyMax,
    resumeHhmm
  };
  await chrome.storage.local.set({ [JOIN_QUEUE_KEY]: st });
  chrome.alarms.clear('irishka_join_resume');
  await runJoinQueueChunk();
  return { ok: true };
}

async function runJoinQueueChunk() {
  const d = await chrome.storage.local.get([JOIN_QUEUE_KEY]);
  let st = d[JOIN_QUEUE_KEY];
  if (!st || !st.active || !Array.isArray(st.urls) || !st.urls.length) return;
  const dk = dayKey(Date.now());
  if (st.dayKey !== dk) {
    st.dayKey = dk;
    st.joinedToday = 0;
  }
  const dailyMax = Math.max(1, Number(st.dailyMax) || 5);
  let idx = Math.max(0, Number(st.cursor) || 0);
  /** joinedToday = join attempts processed today (each opened group tab), capped by dailyMax. */
  while (idx < st.urls.length) {
    const dkNow = dayKey(Date.now());
    if (st.dayKey !== dkNow) {
      st.dayKey = dkNow;
      st.joinedToday = 0;
    }
    const used = Number(st.joinedToday) || 0;
    if (used >= dailyMax) break;
    const url = st.urls[idx];
    let tab = null;
    try {
      tab = await new Promise((resolve, reject) => {
        chrome.tabs.create({ url, active: false }, (t) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else resolve(t);
        });
      });
      await waitTabComplete(tab.id, 28000).catch(() => {});
      const inj = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: joinGroupInPageInjected
      });
      const joined = !!(inj && inj[0] && inj[0].result && inj[0].result.joined);
      st.joinedToday = used + 1;
      idx++;
      st.cursor = idx;
      await chrome.storage.local.set({ [JOIN_QUEUE_KEY]: st });
      broadcastToApp({
        action: 'joinQueueProgress',
        joinedTotal: idx,
        listTotal: st.urls.length,
        joinedToday: st.joinedToday,
        dailyMax,
        lastUrl: url,
        lastOk: joined
      });
    } catch (_) {
      st.joinedToday = used + 1;
      idx++;
      st.cursor = idx;
      await chrome.storage.local.set({ [JOIN_QUEUE_KEY]: st });
    } finally {
      try {
        if (tab && tab.id) chrome.tabs.remove(tab.id);
      } catch (_) {}
    }
    await sleep(3500);
  }
  st = (await chrome.storage.local.get([JOIN_QUEUE_KEY]))[JOIN_QUEUE_KEY];
  if (!st || !st.active) return;
  if ((st.cursor || 0) >= st.urls.length) {
    st.active = false;
    await chrome.storage.local.set({ [JOIN_QUEUE_KEY]: st });
    chrome.alarms.clear('irishka_join_resume');
    broadcastToApp({ action: 'joinQueueFinished', total: st.urls.length });
    return;
  }
  const when = computeNextJoinResumeMs(st.resumeHhmm || '07:00');
  chrome.alarms.clear('irishka_join_resume');
  chrome.alarms.create('irishka_join_resume', { when });
  broadcastToApp({
    action: 'joinQueueScheduled',
    when,
    nextIndex: st.cursor,
    listTotal: st.urls.length,
    joinedToday: st.joinedToday,
    dailyMax: st.dailyMax
  });
}

function scheduleResume(whenMs, reason) {
  chrome.alarms.clear('fartmily_resume');
  chrome.alarms.create('fartmily_resume', { when: whenMs });
  const d = new Date(whenMs);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const msg = reason + ' · reanuda ' + d.toLocaleDateString() + ' ' + hh + ':' + mm;
  broadcastToApp({ action: 'plannerStatus', message: msg });
}

async function schedulePostingAtFromApp(atMs) {
  const when = Number(atMs);
  if (!Number.isFinite(when) || when <= Date.now()) {
    return { ok: false, error: 'bad_time' };
  }
  if (posterRunning) return { ok: false, error: 'already_running' };
  const stored = await chrome.storage.local.get(['posterConfig']);
  const base = stored.posterConfig && typeof stored.posterConfig === 'object' ? { ...stored.posterConfig } : {};
  const config = { ...base };
  if (!Array.isArray(config.groups) || !config.groups.length) {
    return { ok: false, error: 'no_groups' };
  }
  await hydratePosterImagesFromSession(config);
  const posts = normalizePosts(config);
  if (!posts.length || !posts.some((p) => String(p.text || '').trim())) {
    return { ok: false, error: 'no_posts' };
  }
  if (isCommunityFreeBuildBg() && config.communityProfileFirst !== false) {
    const hasSlot = (config.groups || []).some((g) => g && g.isProfileTimelineSlot);
    if (!hasSlot) {
      config.groups = [makeProfileTimelineSlotBg(), ...config.groups];
    }
  }
  posterRunning = false;
  stopRequested = false;
  chrome.alarms.clear('fartmily_resume');
  const now = Date.now();
  runState = {
    config,
    results: [],
    index: 0,
    postIndex: 0,
    dailySuccessCount: 0,
    dailyKey: dayKey(now),
    startedOnce: false,
    plannedStartAt: when,
    resumeHint: 'scheduled_start',
    stopReason: null,
    workerTabId: null
  };
  await chrome.storage.local.set({ posterRunning: false, posterResults: [] });
  persistRunState();
  scheduleResume(when, 'Scheduled posting');
  return { ok: true };
}

async function cancelScheduledPostingFromApp() {
  const d = await chrome.storage.local.get([RUNSTATE_KEY]);
  const saved = d[RUNSTATE_KEY];
  if (!saved || saved.resumeHint !== 'scheduled_start') {
    return { ok: false, error: 'nothing_to_cancel' };
  }
  chrome.alarms.clear('fartmily_resume');
  await chrome.storage.local.remove(RUNSTATE_KEY);
  runState = null;
  broadcastToApp({ action: 'plannerStatus', message: '' });
  return { ok: true };
}

async function setPosterLoopInfiniteFromApp(loopInfinite) {
  const ok = await ensureRunStateForConfigPatch();
  if (!ok || !runState?.config) return { ok: false, error: 'not_running' };
  runState.config.loopInfinite = !!loopInfinite;
  const d = await chrome.storage.local.get(['posterConfig']);
  const pc = d.posterConfig && typeof d.posterConfig === 'object' ? { ...d.posterConfig } : {};
  pc.loopInfinite = !!loopInfinite;
  await chrome.storage.local.set({ posterConfig: pc });
  persistRunState();
  broadcastToApp({ action: 'posterLoopModeChanged', loopInfinite: !!loopInfinite });
  return { ok: true };
}

async function requestSkipCurrentPosterPost() {
  if (!runState || !posterRunning) return { ok: false, error: 'not_running' };
  runState.skipCurrentPostSweep = true;
  return { ok: true };
}

async function appendPostToRunningLoopFromMessage(post) {
  if (!runState || !posterRunning || !runState.config) return { ok: false, error: 'not_running' };
  const p = post && typeof post === 'object' ? post : null;
  if (!p || !String(p.text || '').trim()) return { ok: false, error: 'bad_post' };
  const images = (Array.isArray(p.images) ? p.images : []).slice(0, MAX_POST_IMAGES).map((img) => ({
    dataUrl: String(img?.dataUrl || ''),
    name: String(img?.name || ''),
    type: String(img?.type || 'image/jpeg')
  }));
  const row = { text: String(p.text || ''), images };
  if (!Array.isArray(runState.config.posts)) runState.config.posts = [];
  runState.config.posts.push(row);
  const d = await chrome.storage.local.get(['posterConfig']);
  const prev = d.posterConfig && typeof d.posterConfig === 'object' ? d.posterConfig : {};
  const merged = {
    ...prev,
    ...runState.config,
    posts: [...(Array.isArray(runState.config.posts) ? runState.config.posts : [])]
  };
  await chrome.storage.local.set({ posterConfig: merged });
  persistRunState();
  broadcastToApp({
    action: 'runningPostsQueueChanged',
    totalPosts: runState.config.posts.length
  });
  return { ok: true };
}

function openOrNavigateTab(url, opts) {
  const options = opts || {};
  const active = options.active !== false;
  const reuse = options.reuse !== false;
  return new Promise((resolve) => {
    const appUrl = chrome.runtime.getURL('app.html');
    chrome.tabs.query({}, (allTabs) => {
      const fbTab = reuse ? allTabs.find(t =>
        t.url && !t.url.startsWith(appUrl) &&
        (t.url.includes('facebook.com') || t.url.includes('web.facebook.com'))
      ) : null;
      const waitLoad = (tab) => {
        let done = false;
        const listener = (tabId, info) => {
          if (tabId === tab.id && info.status === 'complete' && !done) {
            done = true;
            chrome.tabs.onUpdated.removeListener(listener);
            resolve(tab);
          }
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(() => {
          if (!done) { done = true; chrome.tabs.onUpdated.removeListener(listener); resolve(tab); }
        }, 15000);
      };
      if (fbTab) {
        chrome.tabs.update(fbTab.id, { url, active }, waitLoad);
      } else {
        chrome.tabs.create({ url, active }, waitLoad);
      }
    });
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function broadcastToApp(msg) { chrome.runtime.sendMessage(msg).catch(() => {}); }

function withTimeout(promise, ms, label) {
  let t = null;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      t = setTimeout(() => reject(new Error(label || 'Timeout')), ms);
    })
  ]).finally(() => {
    if (t) clearTimeout(t);
  });
}

// Injected into Facebook page (args: text, inlineImages[], pauseFlag, expectedImageCount)
async function fbPostInPage(text, inlineImages, pauseBeforePublish, expectedImageCount) {
  const log = [];
  const pauseBeforePublishEffective = !!pauseBeforePublish; // Respeta flag pasado desde background.
  const W = (ms) => new Promise(r => setTimeout(r, ms));
  const L = (m) => {
    log.push(String(m));
    console.log("[Fartmily]", m);
  };
  L("[Inject] T=" + new Date().toISOString());
  L("[Inject] URL=" + String(location.href || "").slice(0, 220));
  L("[Inject] UA móvil=" + /Mobile|Android|iPhone/i.test(navigator.userAgent || ""));
  /** FB usa mucho position:fixed → offsetParent es null y antes ignorábamos el compositor. */
  function isLikelyVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    try {
      const st = window.getComputedStyle(el);
      if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      if (r.bottom < -80 || r.top > window.innerHeight + 120) return false;
      return true;
    } catch (e) {
      return false;
    }
  }
  function querySelectorAllDeep(sel) {
    const out = [];
    const seen = new Set();
    function walk(root) {
      if (!root || seen.has(root)) return;
      seen.add(root);
      try {
        root.querySelectorAll(sel).forEach((e) => out.push(e));
        root.querySelectorAll("*").forEach((el) => {
          if (el.shadowRoot) walk(el.shadowRoot);
        });
      } catch (e) {}
    }
    walk(document);
    return out;
  }
  function forEachShadowRoot(callback) {
    const seen = new Set();
    function walk(root) {
      if (!root || seen.has(root)) return;
      seen.add(root);
      try {
        callback(root);
        root.querySelectorAll("*").forEach((el) => {
          if (el.shadowRoot) walk(el.shadowRoot);
        });
      } catch (e) {}
    }
    walk(document);
  }
  let images = Array.isArray(inlineImages)
    ? inlineImages.filter((i) => i && i.dataUrl).slice(0, 3)
    : [];
  const needFromStorage = (Number(expectedImageCount) || 0) > 0 && images.length === 0;
  if (needFromStorage) {
    L("[Inject] Sin imágenes en args; leyendo fartmily_pending_images (local → session)…");
    try {
      if (typeof chrome !== "undefined" && chrome.storage) {
        const stored = await new Promise((resolve, reject) => {
          const finish = (arr) => resolve(Array.isArray(arr) ? arr.slice(0, 3) : []);
          try {
            chrome.storage.local.get("fartmily_pending_images", (r) => {
              const err = chrome.runtime && chrome.runtime.lastError;
              if (!err && r && Array.isArray(r.fartmily_pending_images) && r.fartmily_pending_images.length) {
                return finish(r.fartmily_pending_images);
              }
              if (chrome.storage.session) {
                chrome.storage.session.get("fartmily_pending_images", (r2) => {
                  const err2 = chrome.runtime && chrome.runtime.lastError;
                  if (err2) reject(new Error(err2.message || "storage"));
                  else finish((r2 && r2.fartmily_pending_images) || []);
                });
              } else {
                finish((!err && r && r.fartmily_pending_images) || []);
              }
            });
          } catch (e) {
            reject(e);
          }
        });
        images = stored;
        L("[Inject] Storage imágenes: " + images.length);
      } else {
        L("[Inject] chrome.storage no disponible (mundo aislado sin API?)");
      }
    } catch (e) {
      L("[Inject] Error storage: " + (e.message || e));
    }
  } else {
    L("[Inject] Imágenes en args: " + images.length);
  }

  const humanDelay = () => Math.floor(Math.random() * 40) + 20;
  const textForPost = text;
  const expectedCompactLen = String(textForPost || "").replace(/\s/g, "").length;

  async function openComposer() {
    const keywords = [
      "escribe algo", "escribe un", "escribe", "en que estas pensando", "en qué estás pensando",
      "crea una publicacion", "crear publicacion", "crear publicación", "publicación", "publicar",
      "comenzar publicacion", "añade una publicación", "añade una publicacion", "comparte con el grupo",
      "create a post", "create post", "new post", "write something", "what's on your mind", "what is on your mind",
      "whats on your mind", "something on your mind", "on your mind", "start a discussion", "start discussion",
      "add a post", "share with the group", "write here", "new discussion", "nueva discusion", "publica", "postear",
      "créer une publication", "créer publication", "publier", "écrire quelque chose", "schreib etwas",
      "beitrag erstellen", "nuovo post", "crea post", "comporre", "напишите", "напиши что", "добавить пост",
      "bir şey yaz", "gönderi oluştur", "iets delen", "deel iets", "napisz coś", "utwórz post"
    ];

    const placeholderHint =
      /write|escribe|mind|pensando|something|publica|publicar|\bpost\b|postear|compart|share|discussion|discusi|anuncia|announce|thoughts|piensa|delen|deel|publier|beitrag|publicação/i;

    const testIdHint = /composer|compose|creation|create.?post|new.?post|feed.?story|status.?composer|open.?composer|story.?box|composer.?entry|inline.?composer|mdoc/i;

    const txtOf = (el) => (
      (el?.textContent || "") + " " +
      (el?.getAttribute?.("aria-label") || "") + " " +
      (el?.getAttribute?.("aria-placeholder") || "") + " " +
      (el?.getAttribute?.("placeholder") || "") + " " +
      (el?.getAttribute?.("title") || "")
    ).toLowerCase();

    const isSearchLike = (s) => {
      const x = (s || "").toLowerCase();
      return x.includes("search") || x.includes("buscar") || x.includes("pesquisar") || x.includes("recherch");
    };

    /** Evita abrir flujo Reel / Historia / Stories al buscar el compositor de publicación en perfil. */
    const isReelStoryChrome = (el) => {
      try {
        const h = (el.getAttribute?.("href") || "").toLowerCase();
        if (h && (h.includes("mdoc_stories") || h.includes("/stories/") || /\/reels?\//i.test(h) || h.includes("/reel?"))) return true;
        const al = (el.getAttribute?.("aria-label") || "").trim().toLowerCase();
        if (al) {
          if (/^(crear|create)\s+reel\b/.test(al)) return true;
          if (al === "reel" || /^reel\s*$/i.test(al)) return true;
          if (/\breel\b/.test(al) && !/\bpublic|post|publica|publicación|write|mind|pensando|beitrag|publier\b/i.test(al)) return true;
        }
        const tx = (el.textContent || "").trim().toLowerCase();
        if (tx.length > 0 && tx.length <= 28 && /^(reel|crear reel|create reel|historia|story)$/i.test(tx)) return true;
      } catch (e) {}
      return false;
    };

    const isLikelyOwnProfileTimelineUrl = () => {
      try {
        const u = new URL(location.href);
        const p = (u.pathname || "").replace(/\/+$/, "").toLowerCase() || "/";
        if (p === "/me" || p.startsWith("/me/")) return true;
        if (p === "/profile.php" || p.startsWith("/profile.php")) return true;
        const seg = p.split("/").filter(Boolean);
        if (seg.length === 1) {
          const r = /^(groups|reel|reels|watch|marketplace|events|gaming|ads|pages|notifications|messages|settings|login|account|help|privacy|policies|share|dialog|photo|videos|friends|saved|jobs|docs)$/i;
          if (!r.test(seg[0])) return true;
        }
      } catch (e) {}
      return false;
    };

    const clickVisible = async (el, tag) => {
      if (!el || !isLikelyVisible(el) || isReelStoryChrome(el)) return false;
      try {
        el.scrollIntoView({ block: "center", inline: "center" });
      } catch (e) {}
      L(tag);
      try {
        el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
        el.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
      } catch (e) {}
      el.click();
      await W(700);
      return true;
    };

    const mainEl = document.querySelector('[role="main"]');

    const textNodeHints = [
      "what's on your mind", "whats on your mind", "write something", "write here",
      "crea una publicación", "crear publicación", "escribe algo", "en qué estás pensando",
      "comparte con el grupo", "publicar en el grupo", "add a post", "create post",
      "start a discussion", "publier", "écrire", "beitrag", "nuovo post", "напишите"
    ];

    function findClickableFromTextNodes(root) {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
      const seenEls = new Set();
      let n;
      while ((n = walker.nextNode())) {
        const s = (n.textContent || "").trim().toLowerCase().replace(/\s+/g, " ");
        if (s.length < 8 || s.length > 200) continue;
        if (!textNodeHints.some((h) => s.includes(h))) continue;
        let el = n.parentElement;
        for (let d = 0; d < 14 && el; d++) {
          if (seenEls.has(el)) break;
          seenEls.add(el);
          const role = (el.getAttribute && el.getAttribute("role")) || "";
          const tab = el.getAttribute && el.getAttribute("tabindex");
          if (role === "button" || role === "link" || el.tagName === "A" || el.tagName === "BUTTON") {
            if (isLikelyVisible(el) && !isReelStoryChrome(el)) return el;
          }
          if (el.tagName === "DIV" && tab === "0" && isLikelyVisible(el) && (el.textContent || "").trim().length < 200) {
            if (!isReelStoryChrome(el)) return el;
          }
          el = el.parentElement;
        }
      }
      return null;
    }

    const tryOpenOnce = async () => {
      const main = mainEl || document.body;
      const feedRoot = document.querySelector('[role="feed"]') || main;

      // Perfil propio: priorizar CTA de publicación en línea de tiempo (no Reel / Historia).
      if (isLikelyOwnProfileTimelineUrl()) {
        const mindHints = [
          "what's on your mind", "whats on your mind", "write something", "write here",
          "en qué estás pensando", "en que estas pensando", "qué estás pensando", "que estas pensando",
          "crea una publicación", "crear publicación", "crear una publicacion", "crea una publicacion",
          "add a post", "create post", "start a discussion", "comparte con el grupo"
        ];
        const profCandidates = querySelectorAllDeep('[role="button"],div[role="button"],[role="textbox"],a[href*="composer"]');
        for (const el of profCandidates) {
          if (!isLikelyVisible(el)) continue;
          const t = txtOf(el);
          if (!mindHints.some((h) => t.includes(h))) continue;
          if (await clickVisible(el, "Perfil timeline CTA: " + t.trim().slice(0, 50))) return true;
        }
      }

      // 0) Texto visible en el DOM (y shadow) → subir al botón contenedor.
      let hit = null;
      forEachShadowRoot((root) => {
        if (hit) return;
        try {
          hit = findClickableFromTextNodes(root);
        } catch (e) {}
      });
      if (hit && (await clickVisible(hit, "Compositor por texto visible: " + (hit.textContent || "").trim().slice(0, 50)))) return true;

      // A) data-testid en documento + shadow.
      for (const el of querySelectorAllDeep("[data-testid]")) {
        if (!isLikelyVisible(el)) continue;
        const tid = String(el.getAttribute("data-testid") || "");
        if (!testIdHint.test(tid)) continue;
        if (/comment|search|messenger|marketplace|notification|nav|sidebar|header|menu/i.test(tid)) continue;
        if (/reel|mdoc_story|story_tray|stories_tray|broadcast|live_producer/i.test(tid)) continue;
        if (await clickVisible(el, "Compositor data-testid: " + tid.slice(0, 80))) return true;
      }

      // B) Enlaces al compositor de publicación (sin /stories/ ni mdoc_stories → abrían Reel/Historia).
      for (const a of querySelectorAllDeep('a[href*="composer"], a[href*="quick_composer"]')) {
        if (!isLikelyVisible(a)) continue;
        const h = (a.getAttribute("href") || "").toLowerCase();
        if (h.includes("comment") || h.includes("photo.php")) continue;
        if (await clickVisible(a, "Compositor enlace: " + h.slice(0, 60))) return true;
      }

      // C) role=textbox con placeholder.
      const phBoxes = Array.from(
        querySelectorAllDeep('[role="textbox"][aria-placeholder], [role="textbox"][aria-label], div[role="textbox"]')
      ).filter((el) => isLikelyVisible(el));
      for (const el of phBoxes) {
        const ph = ((el.getAttribute("aria-placeholder") || "") + " " + (el.getAttribute("aria-label") || "")).trim();
        if (!ph || ph.length < 3) continue;
        if (isSearchLike(ph)) continue;
        if (!placeholderHint.test(ph)) continue;
        if (await clickVisible(el, "Compositor textbox aria: " + ph.slice(0, 60))) return true;
      }

      // D) aria-label con keyword.
      for (const el of querySelectorAllDeep("[aria-label]")) {
        if (!isLikelyVisible(el)) continue;
        const al = (el.getAttribute("aria-label") || "").toLowerCase();
        if (!al || isSearchLike(al)) continue;
        if (!keywords.some((k) => al.includes(k))) continue;
        const role = (el.getAttribute("role") || "").toLowerCase();
        if (role !== "button" && role !== "link" && role !== "textbox" && el.tagName !== "A") {
          const btn = el.closest('[role="button"],[role="link"],a,button');
          if (btn && isLikelyVisible(btn) && (await clickVisible(btn, "Compositor aria-label→closest: " + al.slice(0, 50)))) return true;
          continue;
        }
        if (await clickVisible(el, "Compositor aria-label: " + al.slice(0, 50))) return true;
      }

      // E) Botones en feed / main.
      const candidates = Array.from(feedRoot.querySelectorAll('[role="button"],button,[role="link"],a,[contenteditable="true"]'));
      for (const b of candidates) {
        if (!isLikelyVisible(b)) continue;
        const t = txtOf(b);
        if (isSearchLike(t)) continue;
        if (!keywords.some((k) => t.includes(k))) continue;
        const rect = b.getBoundingClientRect();
        if (rect.width < 40 || rect.height < 16) continue;
        if (await clickVisible(b, "Compositor boton texto: " + t.trim().slice(0, 50))) return true;
      }

      // F) Heurística feed (fixed/sticky ok).
      const feedButtons = Array.from(feedRoot.querySelectorAll('[role="button"][tabindex="0"], div[role="button"]')).filter((el) =>
        isLikelyVisible(el)
      );
      feedButtons.sort((a, b) => {
        const ra = a.getBoundingClientRect();
        const rb = b.getBoundingClientRect();
        return ra.top - rb.top;
      });
      for (const b of feedButtons.slice(0, 18)) {
        const inner = (b.textContent || "").trim();
        if (inner.length > 120) continue;
        if (inner.length < 2 && !(b.getAttribute("aria-label") || "").trim()) continue;
        const combined = txtOf(b);
        if (isSearchLike(combined)) continue;
        const rect = b.getBoundingClientRect();
        if (rect.top > 620) continue;
        if (placeholderHint.test(combined) || keywords.some((k) => combined.includes(k))) {
          if (await clickVisible(b, "Compositor heuristica feed: " + inner.slice(0, 40))) return true;
        }
      }

      // G) Ray casting vertical en el centro del feed (capas superpuestas).
      const cx = Math.floor(Math.min(window.innerWidth - 24, Math.max(24, window.innerWidth * 0.5)));
      for (let y = 140; y < Math.min(560, window.innerHeight - 100); y += 32) {
        try {
          const stack = document.elementsFromPoint(cx, y);
          for (const el of stack) {
            if (!(el instanceof Element)) continue;
            if (el.closest('[role="dialog"]')) break;
            if (el.closest("nav") || el.closest('[role="navigation"]')) continue;
            const role = el.getAttribute("role");
            const tag = el.tagName;
            if (role === "button" || role === "textbox" || tag === "BUTTON") {
              if (isLikelyVisible(el) && (await clickVisible(el, "Compositor elementsFromPoint " + cx + "," + y + " " + (role || tag)))) return true;
              break;
            }
          }
        } catch (e5) {}
      }

      return false;
    };

    try {
      window.scrollTo(0, 0);
      if (mainEl) try { mainEl.scrollTop = 0; } catch (e) {}
    } catch (e) {}

    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) {
        L("Compositor reintento " + (attempt + 1));
        try {
          window.scrollBy(0, -400);
          await W(500);
          if (mainEl) mainEl.scrollTop = Math.max(0, mainEl.scrollTop - 300);
        } catch (e3) {}
      }
      if (await tryOpenOnce()) return true;
      await W(800);
    }

    try {
      const nTid = querySelectorAllDeep("[data-testid]").length;
      const nLab = querySelectorAllDeep("[aria-label]").length;
      L("Diagnostico final: URL=" + String(location.href || "").slice(0, 120));
      L("Diagnostico final: data-testid=" + nTid + " aria-label=" + nLab + " role_main=" + !!document.querySelector('[role="main"]'));
    } catch (e4) {}

    return false;
  }

  async function getEditor(maxMs) {
    function pickBestEditor(scope) {
      const candidates = Array.from((scope || document).querySelectorAll('[contenteditable="true"], [role="textbox"]'))
        .filter((el) => el && isLikelyVisible(el));
      if (!candidates.length) return null;
      const scored = candidates.map(el => {
        const aria = (el.getAttribute("aria-label") || "").toLowerCase();
        const role = (el.getAttribute("role") || "").toLowerCase();
        const multiline = (el.getAttribute("aria-multiline") || "").toLowerCase() === "true";
        const cls = (el.className || "").toString().toLowerCase();
        let score = 0;
        if (role === "textbox") score += 4;
        if (multiline) score += 4;
        if (aria.includes("escribe") || aria.includes("write") || aria.includes("public")) score += 3;
        if (aria.includes("comment") || aria.includes("coment")) score -= 6;
        if (aria.includes("search") || aria.includes("buscar")) score -= 8;
        if (cls.includes("lexical")) score += 2;
        if (el.closest('[role="dialog"]')) score += 2;
        return { el, score };
      }).sort((a, b) => b.score - a.score);
      return scored[0]?.el || null;
    }

    const t0 = Date.now();
    while (Date.now() - t0 < maxMs) {
      await W(400);
      for (const dlg of document.querySelectorAll("[role=dialog]")) {
        const bestInDlg = pickBestEditor(dlg);
        if (bestInDlg) { L("Editor en dialogo"); return bestInDlg; }
      }
      const lex = document.querySelector("[data-lexical-editor=true]");
      if (lex && isLikelyVisible(lex)) { L("Lexical editor"); return lex; }
      const bestGlobal = pickBestEditor(document);
      if (bestGlobal) { L("Editor generico"); return bestGlobal; }
    }
    return null;
  }
  async function resolveActiveEditor(maxMs) {
    const ed = await getEditor(maxMs || 5000);
    if (!ed) return null;
    // Some FB flows replace the composer after media upload.
    // Ensure we always type in the latest visible editor node.
    if (!document.body.contains(ed) || !isLikelyVisible(ed)) {
      return await getEditor(3000);
    }
    return ed;
  }

  async function typeText(editor, txt) {
    const raw = String(txt ?? "");
    const firstLine = (raw.split("\n")[0] || "").trim();
    const lineCount = raw.split("\n").length;
    L("typeText(start): " + raw.length + " chars, " + lineCount + " lineas");

    function getEditorText() {
      return String(editor.innerText || editor.textContent || "").trim();
    }

    function selectEditorContents() {
      const sel = window.getSelection();
      if (!sel) return false;
      const r = document.createRange();
      r.selectNodeContents(editor);
      sel.removeAllRanges();
      sel.addRange(r);
      return true;
    }

    function clearEditor() {
      editor.focus();
      try { selectEditorContents(); document.execCommand("delete", false, null); } catch (e) {}
      try { editor.textContent = ""; } catch (e) {}
      try { editor.innerHTML = ""; } catch (e) {}
    }

    function escapeHtml(s) {
      return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    }

    function isOkText(text) {
      if (!text || text.length < 1) return false;
      if (firstLine && !text.includes(firstLine)) return false;
      if (firstLine) {
        const occ = text.split(firstLine).length - 1;
        L("Primera linea occurrences: " + occ);
        if (occ > 1) return false;
      }
      return true;
    }

    // Method 1: synthetic paste (preserve line breaks)
    clearEditor();
    await W(250);
    let dt = new DataTransfer();
    dt.setData("text/plain", raw);
    try {
      const ev = new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true });
      editor.focus();
      selectEditorContents();
      editor.dispatchEvent(ev);
      L("PasteEvent enviado");
    } catch (e) {
      L("PasteEvent falló");
    }
    await W(900);
    let got = getEditorText();
    L("Texto post-paste: " + got.length + " chars");
    if (isOkText(got)) return true;

    // Method 2: insertHTML with <br> (one shot)
    clearEditor();
    await W(250);
    const html = escapeHtml(raw).replace(/\n/g, "<br>");
    try {
      editor.focus();
      selectEditorContents();
      document.execCommand("insertHTML", false, html);
      L("insertHTML ejecutado");
    } catch (e) {
      L("insertHTML falló");
    }
    await W(900);
    got = getEditorText();
    L("Texto post-insertHTML: " + got.length + " chars");
    if (isOkText(got)) return true;

    // Method 3: insertText fallback
    clearEditor();
    await W(250);
    try {
      editor.focus();
      selectEditorContents();
      document.execCommand("insertText", false, raw);
      L("insertText ejecutado (fallback)");
    } catch (e) {
      L("insertText fallback falló");
    }
    await W(900);
    got = getEditorText();
    L("Texto post-insertText: " + got.length + " chars");
    return isOkText(got);
  }

  function hasMediaPreview(root) {
    const scope = root || document;
    return !!(
      scope.querySelector("img[src*='blob:']") ||
      scope.querySelector("img[src*='scontent']") ||
      scope.querySelector("img[src*='fbcdn']") ||
      scope.querySelector("[data-visualcompletion='media-vc-image']") ||
      scope.querySelector("[aria-label*='foto' i], [aria-label*='photo' i]") ||
      scope.querySelector('[data-testid*="photo"]') ||
      scope.querySelector('[data-testid*="media"]')
    );
  }

  async function waitForMediaPreview(root, maxMs) {
    const t0 = Date.now();
    while (Date.now() - t0 < maxMs) {
      if (hasMediaPreview(root) || hasMediaPreview(document)) return true;
      await W(500);
    }
    return false;
  }

  /** No usar el primer dialog del documento (cookies, otros modales): solo el del compositor. */
  function composerSearchRoot(editorEl) {
    if (editorEl && editorEl.closest) {
      const dlg = editorEl.closest('[role="dialog"]');
      if (dlg) return dlg;
      const main = editorEl.closest('[role="main"]');
      if (main) return main;
    }
    return document;
  }

  function findImageFileInputDeep() {
    const list = querySelectorAllDeep('input[type=file]');
    for (const inp of list) {
      try {
        const acc = (inp.getAttribute('accept') || '').toLowerCase();
        if (acc && !acc.includes('image') && !acc.includes('*')) continue;
        return inp;
      } catch (e) {}
    }
    return null;
  }

  function getInputReactOnChange(fi) {
    if (!fi) return null;
    const pk = Object.keys(fi).find((k) => k.startsWith('__reactProps'));
    if (pk) {
      const p = fi[pk];
      if (p && typeof p.onChange === 'function') return p.onChange;
    }
    const fk = Object.keys(fi).find((k) => k.startsWith('__reactFiber'));
    if (fk) {
      let fiber = fi[fk];
      for (let d = 0; d < 45 && fiber; d++) {
        const mp = fiber.memoizedProps;
        if (mp && typeof mp.onChange === 'function') return mp.onChange;
        fiber = fiber.return;
      }
    }
    return null;
  }

  // Upload image(s): click photo button, set FileList, trigger React/native events
  async function uploadImage(imgs, editorEl) {
    if (!imgs || !imgs.length) return false;
    const root = composerSearchRoot(editorEl);

    // Build blobs/files from base64
    const files = [];
    for (const img of imgs) {
      try {
        const blob = await fetch(img.dataUrl).then(r => r.blob());
        const file = new File([blob], img.name || "image.jpg", { type: blob.type || "image/jpeg" });
        files.push(file);
        L("Blob: " + (img.name || "image.jpg") + " " + blob.size + "b");
      } catch(e) {
        L("Error blob: " + e.message);
      }
    }
    if (!files.length) return false;

    // Click photo button to expand upload section
    L("Buscando boton Foto/Video...");
    const photoLabels = [
      "foto/video", "photo/video", "photo", "foto", "add photo", "agregar foto",
      "añade fotos", "añade foto", "add photos", "media", "imagen", "image"
    ];
    let photoBtn = null;
    for (const lbl of photoLabels) {
      photoBtn = root.querySelector("[aria-label*='" + lbl + "' i]");
      if (photoBtn && photoBtn.offsetParent) { L("Boton foto: " + lbl); break; }
    }
    if (!photoBtn) {
      for (const btn of root.querySelectorAll("[role=button],button")) {
        const t = (btn.getAttribute("aria-label") || btn.title || btn.textContent || "").toLowerCase();
        if ((t.includes("photo") || t.includes("foto")) && btn.offsetParent) {
          photoBtn = btn; L("Boton foto texto: " + t.slice(0, 30)); break;
        }
      }
    }
    if (!photoBtn) { L("Boton foto no encontrado"); return false; }

    L("Clic en boton foto...");
    photoBtn.click();
    await W(800);

    let fi = root.querySelector("input[type=file][accept*='image']")
      || root.querySelector("input[type=file]")
      || findImageFileInputDeep();
    for (let wait = 0; !fi && wait < 12; wait++) {
      await W(400);
      fi = root.querySelector("input[type=file][accept*='image']")
        || root.querySelector("input[type=file]")
        || findImageFileInputDeep();
    }
    if (!fi) { L("input[type=file] no encontrado"); return false; }
    L("input[type=file] encontrado");

    // Try all known ways to trigger React's file handler
    const dt = new DataTransfer();
    files.forEach(f => dt.items.add(f));

    // Method 1: Override via prototype setter
    try {
      const nativeDesc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "files");
      if (nativeDesc && nativeDesc.set) {
        nativeDesc.set.call(fi, dt.files);
      }
    } catch(e) {}

    // Method 2: defineProperty
    try {
      Object.defineProperty(fi, "files", { value: dt.files, configurable: true, writable: true });
    } catch(e) {}

    const syntheticEvent = {
      target: fi,
      currentTarget: fi,
      nativeEvent: new Event("change", { bubbles: true }),
      bubbles: true,
      cancelable: false,
      defaultPrevented: false,
      preventDefault: () => {},
      stopPropagation: () => {},
      persist: () => {},
      isPersistent: () => true,
    };

    // Method 3: React onChange (__reactProps o __reactFiber)
    const onCh = getInputReactOnChange(fi);
    if (onCh) {
      L("React onChange encontrado, invocando…");
      try {
        onCh(syntheticEvent);
      } catch (e) {
        L("onChange error: " + (e && e.message));
      }
      if (await waitForMediaPreview(root, 12000)) {
        L("IMAGEN CARGADA via React onChange!");
        return true;
      }
      L("React onChange llamado, sin preview aún");
    } else {
      L("No se encontro onChange en input (props/fiber)");
    }

    // Method 4: fire all events as last attempt
    fi.dispatchEvent(new Event("input",  { bubbles: true }));
    fi.dispatchEvent(new Event("change", { bubbles: true }));
    if (await waitForMediaPreview(root, 12000)) { L("Imagen via events!"); return true; }

    L("No se detecto preview de imagen");
    return false;
  }

  async function findPostBtn(maxMs) {
    const words = ["post", "publicar", "postar", "compartir", "share", "publish", "enviar"];
    const t0 = Date.now();
    while (Date.now() - t0 < maxMs) {
      await W(500);
      for (const dlg of document.querySelectorAll("[role=dialog]")) {
        for (const btn of dlg.querySelectorAll("button,[role=button]")) {
          if (!btn.offsetParent || btn.disabled || btn.getAttribute("aria-disabled") === "true") continue;
          const t = (btn.textContent || btn.getAttribute("aria-label") || "").trim().toLowerCase();
          if (words.includes(t)) { L("Boton publicar: " + t); return btn; }
        }
      }
      for (const btn of document.querySelectorAll("button,[role=button]")) {
        if (!btn.offsetParent || btn.disabled || btn.getAttribute("aria-disabled") === "true") continue;
        const t = (btn.textContent || btn.getAttribute("aria-label") || "").trim().toLowerCase();
        if (words.includes(t)) { L("Boton publicar global: " + t); return btn; }
      }
    }
    return null;
  }

  async function waitClose(el, maxMs) {
    const t0 = Date.now();
    while (Date.now() - t0 < maxMs) {
      await W(600);
      if (!document.body.contains(el)) { L("Dialogo cerrado"); return true; }
      if (!el.offsetParent)            { L("Editor oculto");   return true; }
      if (!(el.textContent || "").trim()) { L("Editor vacio"); return true; }
    }
    return false;
  }
  async function waitPublishSuccess(editorEl, postBtn, maxMs) {
    const t0 = Date.now();
    const successHints = [
      'post published', 'your post is now', 'shared to group', 'posted',
      'publicado', 'publicación', 'publicacion', 'se ha publicado', 'compartido'
    ];
    const errorHints = [
      'try again', 'something went wrong', 'couldn’t post', "couldn't post",
      'no se pudo', 'error al publicar'
    ];
    while (Date.now() - t0 < maxMs) {
      await W(500);
      // Primary signal: editor/dialog closes or hides.
      if (!document.body.contains(editorEl) || !editorEl.offsetParent) return { ok: true, why: 'editor-closed' };

      const body = (document.body?.innerText || '').toLowerCase();
      if (successHints.some(h => body.includes(h))) return { ok: true, why: 'success-hint' };
      if (errorHints.some(h => body.includes(h))) return { ok: false, why: 'error-hint' };

      // Secondary signal: publish button becomes unavailable after click.
      if (postBtn) {
        const gone = !document.body.contains(postBtn) || !postBtn.offsetParent;
        const disabled = postBtn.disabled || postBtn.getAttribute('aria-disabled') === 'true';
        if (gone || disabled) return { ok: true, why: 'button-gone-disabled' };
      }
    }
    return { ok: false, why: 'timeout' };
  }

  // Main flow
  try {
    await W(2500);
    L("Iniciando... imagenes=" + images.length + " texto=" + text.length + " chars");

    L("Paso 1: abriendo compositor");
    const opened = await openComposer();
    if (!opened) return { success: false, error: "No se encontro el compositor", log };
    await W(4000);

    L("Paso 2: buscando editor");
    let editor = await resolveActiveEditor(8000);
    if (!editor) return { success: false, error: "No se encontro el editor", log };

    // Upload image FIRST via photo button
    if (images && images.length > 0) {
      L("Paso 3: subiendo imagen...");
      const imgOk = await uploadImage(images, editor);
      L("Imagen: " + (imgOk ? "ok" : "fallo"));
      if (!imgOk) return { success: false, error: "No se pudo cargar la imagen en Facebook", log };
      await W(2000);
      editor = await resolveActiveEditor(7000);
      if (!editor) return { success: false, error: "No se encontro editor luego de cargar imagen", log };
      editor.focus();
      await W(500);
    }

    // Type text — single pass, no retries that could duplicate content
    L("Paso 4: escribiendo texto");
    editor = await resolveActiveEditor(5000) || editor;
    L("Editor: role=" + (editor.getAttribute("role") || "") + " multiline=" + (editor.getAttribute("aria-multiline") || ""));
    await typeText(editor, textForPost);
    await W(800);

    // Safety: if Facebook/Lexical duplicated the text multiple times,
    // stop here (don't even search/click the publish button).
    try {
      const firstLine = (textForPost.split("\n")[0] || "").trim();
      const got = String(editor.innerText || editor.textContent || "");
      const gotTrim = got.trim();

      if (!gotTrim || gotTrim.length < 3) {
        L("PAUSA: texto no escrito en el editor, detenido antes de publicar");
        return {
          success: false,
          pausedBeforePublish: true,
          error: "Texto no escrito en el editor",
          log
        };
      }

      const gotCompactLen = got.replace(/\s/g, "").length;
      if (expectedCompactLen && gotCompactLen > expectedCompactLen * 1.4) {
        L("PAUSA: tamaño anormal en el editor (got=" + gotCompactLen + " exp=" + expectedCompactLen + "), detenido antes de publicar");
        return {
          success: false,
          pausedBeforePublish: true,
          error: "Duplicacion/tamano anormal en el editor",
          log
        };
      }

      if (firstLine) {
        if (!got.includes(firstLine)) {
          L("PAUSA: texto no coincide (primera linea no encontrada), detenido antes de publicar");
          return {
            success: false,
            pausedBeforePublish: true,
            error: "Texto no coincide en el editor (primera linea)",
            log
          };
        }
        const occ = got.split(firstLine).length - 1;
        if (occ > 1) {
          L("PAUSA: duplicacion detectada en el editor (occ=" + occ + "), detenido antes de publicar");
          return {
            success: false,
            pausedBeforePublish: true,
            error: "Duplicacion detectada en el editor (occ=" + occ + ")",
            log
          };
        }
      }
    } catch (e) {}

    L("Paso 5: buscando Publicar");
    const postBtn = await findPostBtn(8000);
    if (!postBtn) return { success: false, error: "No se encontro boton Publicar", log };

    if (pauseBeforePublishEffective) {
      L("PAUSA DE SEGURIDAD: listo para publicar, detenido antes del click");
      // Hard block any publish click that might be triggered elsewhere.
      try {
        postBtn.addEventListener('click', (e) => {
          try { e.preventDefault(); } catch (err) {}
          try { e.stopImmediatePropagation(); } catch (err) {}
          try { e.stopPropagation(); } catch (err) {}
          L("Bloqueado click en Publicar (safety)");
        }, true);
      } catch (e) {}
      return { success: false, pausedBeforePublish: true, error: "Pausa de seguridad antes de publicar", log };
    }

    L("Paso 6: publicando...");
    postBtn.click();

    const firstTry = await waitPublishSuccess(editor, postBtn, 16000);
    if (!firstTry.ok) {
      postBtn.click();
      const secondTry = await waitPublishSuccess(editor, postBtn, 8000);
      if (!secondTry.ok) return { success: false, error: "Post incierto", log };
    }

    L("Post publicado!");
    return { success: true, log };

  } catch(e) {
    L("ERROR: " + e.message);
    return { success: false, error: e.message, log };
  }
}

// --- LAN bridge (MatchMaker / otros → cola → pestaña Mensaje) ---
const IRISHKA_BRIDGE_CFG_KEY = 'irishkaBridgeConfig';
const IRISHKA_BRIDGE_PENDING_KEY = 'irishkaBridgePendingCompose';

function decodeBridgeUtf8Base64Maybe(input) {
  const s = String(input || '').trim();
  if (!s || !/^[A-Za-z0-9+/=_-]+$/.test(s) || s.length < 16) return '';
  try {
    const normalized = s.replace(/-/g, '+').replace(/_/g, '/');
    const padded = normalized + '='.repeat((4 - (normalized.length % 4 || 4)) % 4);
    const raw = atob(padded);
    const bytes = Uint8Array.from(raw, (ch) => ch.charCodeAt(0));
    const out = new TextDecoder('utf-8', { fatal: false }).decode(bytes).trim();
    return out;
  } catch {
    return '';
  }
}

function normalizeBridgeText(raw) {
  const text = String(raw || '');
  const trimmed = text.trim();
  if (!trimmed) return '';
  const b64Decoded = decodeBridgeUtf8Base64Maybe(trimmed);
  if (b64Decoded) return b64Decoded;
  if (/%[0-9a-fA-F]{2}/.test(trimmed)) {
    try {
      return decodeURIComponent(trimmed.replace(/\+/g, '%20')).trim();
    } catch {}
  }
  return trimmed;
}

function parseBridgeEnvelope(raw) {
  const txt = String(raw || '').trim();
  if (!txt) return null;
  let base64Payload = '';
  if (txt.startsWith('MM_PAYLOAD::')) {
    base64Payload = txt.slice('MM_PAYLOAD::'.length).trim();
  } else if (txt.startsWith('MM_POST::')) {
    base64Payload = txt.slice('MM_POST::'.length).trim();
  } else if (txt.startsWith('{') && txt.endsWith('}')) {
    try { return JSON.parse(txt); } catch { return null; }
  }
  if (!base64Payload) return null;
  const jsonText = decodeBridgeUtf8Base64Maybe(base64Payload);
  if (!jsonText) return null;
  try {
    return JSON.parse(jsonText);
  } catch {
    return null;
  }
}

function dataUrlFromBridgeImage(raw, mimeHint, nameHint) {
  if (raw == null) return null;
  if (typeof raw !== 'string' && typeof raw !== 'number') return null;
  const val = String(raw).trim();
  if (!val) return null;
  if (val.startsWith('data:image/')) {
    return { dataUrl: val, name: String(nameHint || 'bridge-image.jpg'), type: String(mimeHint || '') || 'image/jpeg' };
  }
  const cleaned = val.replace(/\s+/g, '');
  if (!/^[A-Za-z0-9+/=_-]+$/.test(cleaned)) return null;
  const mime = String(mimeHint || 'image/jpeg').trim() || 'image/jpeg';
  return {
    dataUrl: `data:${mime};base64,${cleaned}`,
    name: String(nameHint || 'bridge-image.jpg'),
    type: mime
  };
}

function normalizeBridgeComposePayload(data) {
  const envFromString = typeof data === 'string' ? parseBridgeEnvelope(data) : null;
  const baseObj = (envFromString && typeof envFromString === 'object') ? envFromString : data;
  if (!baseObj || typeof baseObj !== 'object') return { text: '', images: [] };
  const envInText = parseBridgeEnvelope(
    baseObj.text ?? baseObj.message ?? baseObj.caption ?? baseObj.postText ?? baseObj.body ?? ''
  );
  const dataObj = (envInText && typeof envInText === 'object') ? envInText : baseObj;
  const text = normalizeBridgeText(
    dataObj.text ?? dataObj.message ?? dataObj.caption ?? dataObj.postText ?? dataObj.body ?? ''
  );
  const bucket = [];
  if (Array.isArray(dataObj.images)) bucket.push(...dataObj.images);
  if (Array.isArray(dataObj.imageList)) bucket.push(...dataObj.imageList);
  if (dataObj.image != null) bucket.push(dataObj.image);
  if (dataObj.imageDataUrl != null) bucket.push(dataObj.imageDataUrl);
  if (dataObj.imageData != null) bucket.push(dataObj.imageData);
  if (dataObj.imageBase64 != null) bucket.push(dataObj.imageBase64);
  if (dataObj.image_data != null) bucket.push(dataObj.image_data);
  const images = bucket
    .map((img, i) => {
      if (img && typeof img === 'object') {
        return dataUrlFromBridgeImage(
          img.dataUrl ?? img.base64 ?? img.imageBase64 ?? img.data ?? '',
          img.type ?? img.mimeType ?? dataObj.imageMimeType ?? dataObj.imageType,
          img.name || `bridge-image-${i + 1}.jpg`
        );
      }
      return dataUrlFromBridgeImage(img, dataObj.imageMimeType ?? dataObj.imageType, `bridge-image-${i + 1}.jpg`);
    })
    .filter(Boolean)
    .slice(0, 3);
  const mode = String(dataObj.mode || '').trim();
  const postId = String(dataObj.postId || dataObj.id || '').trim();
  return { text, images, mode, postId };
}

async function pollIrishkaBridgeOnce() {
  if (!isCommunityFreeBuildBg()) return;
  const d = await chrome.storage.local.get([IRISHKA_BRIDGE_CFG_KEY]);
  const cfg = d[IRISHKA_BRIDGE_CFG_KEY];
  if (!cfg || !cfg.enabled) return;
  const base = String(cfg.baseUrl || '')
    .trim()
    .replace(/\/$/, '');
  const dev = String(cfg.deviceId || '').trim();
  if (!base || !dev) return;
  const q = encodeURIComponent(dev);
  const url = `${base}/poll?deviceId=${q}`;
  const headers = {};
  const sec = String(cfg.sharedSecret || '').trim();
  if (sec) headers.Authorization = `Bearer ${sec}`;
  let res;
  try {
    res = await fetch(url, { method: 'GET', headers, cache: 'no-store' });
  } catch {
    return;
  }
  if (res.status === 204) return;
  if (!res.ok) return;
  let data;
  try {
    data = await res.json();
  } catch {
    return;
  }
  const compose = normalizeBridgeComposePayload(data);
  if (!compose.text && !compose.images.length) return;
  await chrome.storage.local.set({
    [IRISHKA_BRIDGE_PENDING_KEY]: { ...compose, receivedAt: Date.now() },
  });
  broadcastToApp({ action: 'bridgeIncomingCompose', ...compose });
  try {
    const appUrl = chrome.runtime.getURL('app.html');
    const tabs = await chrome.tabs.query({ url: appUrl });
    if (tabs[0]?.id) {
      await chrome.tabs.update(tabs[0].id, { active: true });
      if (tabs[0].windowId != null) {
        await chrome.windows.update(tabs[0].windowId, { focused: true });
      }
    }
  } catch {}
}

async function scheduleIrishkaBridgeAlarm() {
  await chrome.alarms.clear('irishka_bridge_poll');
  if (!isCommunityFreeBuildBg()) return;
  const d = await chrome.storage.local.get([IRISHKA_BRIDGE_CFG_KEY]);
  const cfg = d[IRISHKA_BRIDGE_CFG_KEY];
  if (!cfg || !cfg.enabled) return;
  const base = String(cfg.baseUrl || '').trim();
  const dev = String(cfg.deviceId || '').trim();
  if (!base || !dev) return;
  chrome.alarms.create('irishka_bridge_poll', { periodInMinutes: 1 });
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes[IRISHKA_BRIDGE_CFG_KEY]) return;
  scheduleIrishkaBridgeAlarm().catch(() => {});
});

scheduleIrishkaBridgeAlarm().catch(() => {});
