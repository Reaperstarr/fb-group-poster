/** Image payloads: session (rápido), chrome.storage.local (respaldo), IndexedDB (grande / sobrevive update). */
var POSTER_SESSION_IMAGES_KEY = 'fartmily_poster_session_images';
/** Durable fallback used to survive extension reload/update. */
var POSTER_PERSISTED_IMAGES_KEY = 'fartmily_poster_persisted_images';

function buildLayersFromPosterConfig(config) {
  if (Array.isArray(config.posts) && config.posts.length) {
    return config.posts.map(function (p) {
      return (p.images || []).map(function (img) {
        return {
          dataUrl: img.dataUrl || '',
          name: img.name || '',
          type: img.type || 'image/jpeg'
        };
      });
    });
  }
  return [
    (config.images || []).map(function (img) {
      return {
        dataUrl: img.dataUrl || '',
        name: img.name || '',
        type: img.type || 'image/jpeg'
      };
    })
  ];
}

function buildSlimPosterConfig(config) {
  var c = {};
  for (var k in config) {
    if (Object.prototype.hasOwnProperty.call(config, k)) c[k] = config[k];
  }
  if (Array.isArray(c.posts)) {
    c.posts = c.posts.map(function (p) {
      var q = {};
      for (var pk in p) {
        if (Object.prototype.hasOwnProperty.call(p, pk)) q[pk] = p[pk];
      }
      q.images = (p.images || []).map(function (img) {
        return {
          name: img.name || '',
          type: img.type || 'image/jpeg'
        };
      });
      return q;
    });
  }
  if (Array.isArray(c.images)) {
    c.images = c.images.map(function (img) {
      return {
        name: img.name || '',
        type: img.type || 'image/jpeg'
      };
    });
  }
  return c;
}

/**
 * Guarda capas: IndexedDB primero (no cuenta contra cuota de storage.local por payload único),
 * luego chrome.storage.local + session. ok si IDB o local guardaron píxeles.
 */
function writePosterImagesSessionThenSlim(config, cb) {
  var slim = buildSlimPosterConfig(config);
  var layers = buildLayersFromPosterConfig(config);
  var hasAnyImage = layers.some(function (row) {
    return row.some(function (x) {
      return String(x.dataUrl || '').length > 80;
    });
  });
  if (!hasAnyImage) {
    function afterRemove() {
      chrome.storage.local.remove([POSTER_PERSISTED_IMAGES_KEY], function () {
        cb({ ok: true, slim: slim });
      });
    }
    if (typeof posterImageIdbClear === 'function') {
      posterImageIdbClear().then(afterRemove).catch(afterRemove);
    } else {
      afterRemove();
    }
    return;
  }
  var durable = {};
  durable[POSTER_PERSISTED_IMAGES_KEY] = { layers: layers };

  function finishCb(idbOk, localOk, limErr) {
    var storageOk = !!(idbOk || localOk);
    if (!chrome.storage.session) {
      cb({
        ok: storageOk,
        slim: slim,
        idbOk: !!idbOk,
        localOk: !!localOk,
        sessionSynced: false,
        error: storageOk ? undefined : (limErr || 'image_persist_failed')
      });
      return;
    }
    var payload = {};
    payload[POSTER_SESSION_IMAGES_KEY] = { layers: layers };
    chrome.storage.session.set(payload, function () {
      var sErr = chrome.runtime.lastError;
      cb({
        ok: storageOk,
        slim: slim,
        idbOk: !!idbOk,
        localOk: !!localOk,
        sessionSynced: !sErr,
        sessionError: sErr ? sErr.message : undefined,
        error: storageOk ? undefined : (limErr || (sErr && sErr.message) || 'image_persist_failed')
      });
    });
  }

  function afterIdb(idbOk) {
    chrome.storage.local.set(durable, function () {
      var localOk = !chrome.runtime.lastError;
      var limErr = chrome.runtime.lastError ? chrome.runtime.lastError.message : '';
      finishCb(idbOk, localOk, limErr);
    });
  }

  if (typeof posterImageIdbSaveLayers === 'function') {
    posterImageIdbSaveLayers(layers)
      .then(function () {
        afterIdb(true);
      })
      .catch(function () {
        afterIdb(false);
      });
  } else {
    afterIdb(false);
  }
}
